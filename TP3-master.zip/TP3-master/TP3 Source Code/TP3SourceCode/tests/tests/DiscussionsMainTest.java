package tests;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.Database;

import guiStaffHome.ControllerStaffHome;
import guiCreatePost.ControllerCreatePost;
import entityClasses.Post;
import entityClasses.PostsCollection;

/**
 * 
 * <h2>This class tests the required functionality for the second phase of the team project using JUnit 5.</h2>
 * 
 * <p><b>As a student, I can post statements and questions and receive replies.</b></p>
 * <ul>
 * 	<li>createPost_TitleIsEmpty()</li>
 *  <li>createPost_BodyIsEmpty()</li>
 *  <li>createPost_TitleExceedsCharacterLimit()</li>
 *  <li>createPost_BodyExceedsCharacterLimit()</li>
 *  <li>createPost()</li>
 * </ul>
 * 
 * <p><b>As a student, I can post to different threads</b></p>
 * <ul>
 * 	<li>createPost()</li>
 * </ul>
 * 
 * <p><b>As a student, I can see a list of posts</b></p>
 * <ul>
 * 	<li>listAllPosts()</li>
 * </ul>
 * 
 * <p><b>As a student, I can see a list of my posts</b></p>
 * <ul>
 * 	<li>listMyPosts()</li>
 * </ul>
 * 
 * <p><b>As a student, I can delete one of my posts</b></p>
 * <ul>
 * 	<li>deletePost()</li>
 * </ul>
 * 
 * <p><b>As as student, I can search for posts with keywords</b></p>
 * <ul>
 * 	<li>searchPosts()</li>
 * </ul>
 * 
 */
public class DiscussionsMainTest {
	private static Database database = new Database();

	@BeforeAll
	private static void setupDatabaseConnection() throws SQLException {
		try {
			database.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a thread is made with no title.</p>
	 * 
	 * <p>Thread creation is required to allow a student to post to different threads, so this 
	 * indirectly helps satisfies "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test uses the validateThreadCreation()
	 * method (which is used by the doCreateThread() method) to validate if the input passes all input validation
	 * checks. If it does, validateThreadCreation() returns null. If it does not, validateThreadCreation()
	 * returns an error as a String object. The method then uses JUnit's assertEquals() method and compares
	 * the returned error message with what is expected. In this case, a thread is created with no title,
	 * so the validateThreadCreation() method is expected to return "Thread title cannot be empty".</p>
	 * 
	 */
	@Test
	public void createThread_TitleIsEmpty() {
		// Call the thread input validation method using no thread title.
		String error = ControllerStaffHome.threadInputValidation("", "This has an empty thread title", "smountee");
		
		// Verify that the error produced by validateThreadCreation() is what's expected.
		assertEquals("Thread title cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a thread is made with no body.</p>
	 * 
	 * <p>Thread creation is required to allow a student to post to different threads, so this 
	 * indirectly helps satisfies "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test uses the validateThreadCreation()
	 * method (which is used by the doCreateThread() method) to validate if the input passes all input validation
	 * checks. If it does, validateThreadCreation() returns null. If it does not, validateThreadCreation()
	 * returns an error as a String object. The method then uses JUnit's assertEquals() method and compares
	 * the returned error message with what is expected. In this case, a thread is created with no body,
	 * so the validateThreadCreation() method is expected to return "Thread body cannot be empty".</p>
	 * 
	 */
	@Test
	public void createThread_BodyIsEmpty() {
		// Call the thread input validation method using no thread body.
		String error = ControllerStaffHome.threadInputValidation("This has an empty thread body", "", "smountee");
		
		// Verify that the error produced by validateThreadCreation() is what's expected.
		assertEquals("Thread body cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a thread's title exceeds the character limit.</p>
	 * 
	 * <p>Thread creation is required to allow a student to post to different threads, so this 
	 * indirectly helps satisfies "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test uses the validateThreadCreation()
	 * method (which is used by the doCreateThread() method) to validate if the input passes all input validation
	 * checks. If it does, validateThreadCreation() returns null. If it does not, validateThreadCreation()
	 * returns an error as a String object. The method then uses JUnit's assertEquals() method and compares
	 * the returned error message with what is expected. In this case, a thread is created with a title that is too long,
	 * so the validateThreadCreation() method is expected to return "Thread title cannot exceed 200 characters".</p>
	 * 
	 */
	@Test
	public void createThread_TitleExceedsCharacterLimit() {
		// Call the thread input validation method using a title that exceeds the character limit.
		String title = "a".repeat(201);
		String error = ControllerStaffHome.threadInputValidation(title, "This thread title should be too long.", "smountee");
		
		// Verify that the error produced by validateThreadCreation() is what's expected.
		assertEquals("Thread title cannot exceed 200 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a thread's body exceeds the character limit.</p>
	 * 
	 * <p>Thread creation is required to allow a student to post to different threads, so this 
	 * indirectly helps satisfies "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test uses the validateThreadCreation()
	 * method (which is used by the doCreateThread() method) to validate if the input passes all input validation
	 * checks. If it does, validateThreadCreation() returns null. If it does not, validateThreadCreation()
	 * returns an error as a String object. The method then uses JUnit's assertEquals() method and compares
	 * the returned error message with what is expected. In this case, a thread is created with a body that is too long,
	 * so the validateThreadCreation() method is expected to return "Thread body cannot exceed 10,000 characters".</p>
	 * 
	 */
	@Test
	public void createThread_BodyExceedsCharacterLimit() {
		// Call the thread input validation method using a body that exceeds the character limit.
		String body = "a".repeat(10001);
		String error = ControllerStaffHome.threadInputValidation("This thread body should be too long", body, "smounteer");
		
		// Verify that the error produced by validateThreadCreation() is what's expected.
		assertEquals("Thread body cannot exceed 10,000 characters.", error);
		
	}
	
	/**
	 *
	 * <p>This tests that a thread is successfully created if it passes all validation checks.</p>
	 * 
	 * <p>Thread creation is required to allow a student to post to different threads, so this 
	 * indirectly helps satisfies "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test has two different checks.
	 * The first one verifies that the thread passes input validation, and the second one verifies that
	 * a thread is successfully created in the database (since thread creation starts in the database).
	 * If a thread passes input validation, validateThreadCreation() should return null, which assertNull()
	 * is used to verify. The database.createThread() method will throw an exception if any error has
	 * occured during thread creation in the database, which the assertDoesNotThrow() method verifies.</p>
	 * 
	 */
	@Test
	public void createThread() {
		// Call the thread input validation method using valid input.
		String error = ControllerStaffHome.threadInputValidation("Projects", "This is a thread that contains any posts related to class projects.", "smounteer");
		
		// validateThreadCreation() should return null since this tests gives valid input, so we assert that "error" is null.
		assertNull(error);
		
		// Verify that the createThread() method for the database does not throw any errors.
		assertDoesNotThrow(() -> {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
		});
		
		// Reset the database for future tests.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a post is made with no title.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: "As a student, I can post statements and questions and receive replies.".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test calls the validatePostCreation()
	 * method (which is used when an attempt to create a new post happens), and either returns an error message
	 * as a String object if it doesn't pass input validation, or null if it does. JUnit's assertEquals() method
	 * is then called to compare the actual output of validatePostCreation() with the expected error message for this
	 * test.</p>
	 * 
	 */
	@Test
	public void createPost_TitleIsEmpty() {
		// Validate the input with validatePostCreation() using an empty title.
		String error = ControllerCreatePost.validatePostCreation(0, "", "This has an empty post title", "smountee");
		
		// Verify that the error produced by validatePostCreation() is what's expected.
		assertEquals("Post title cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a post is made with no body.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: "As a student, I can post statements and questions and receive replies.".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test calls the validatePostCreation()
	 * method (which is used when an attempt to create a new post happens), and either returns an error message
	 * as a String object if it doesn't pass input validation, or null if it does. JUnit's assertEquals() method
	 * is then called to compare the actual output of validatePostCreation() with the expected error message for this
	 * test.</p>
	 * 
	 */
	@Test
	public void createPost_BodyIsEmpty() {
		// Validate the input with validatePostCreation() using an empty body.
		String error = ControllerCreatePost.validatePostCreation(0, "This has an empty post body", "", "smountee");
		
		// Verify that the error produced by validatePostCreation() is what's expected.
		assertEquals("Post body cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a posts's title exceeds the character limit.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: "As a student, I can post statements and questions and receive replies.".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test calls the validatePostCreation()
	 * method (which is used when an attempt to create a new post happens), and either returns an error message
	 * as a String object if it doesn't pass input validation, or null if it does. JUnit's assertEquals() method
	 * is then called to compare the actual output of validatePostCreation() with the expected error message for this
	 * test.</p>
	 * 
	 */
	@Test
	public void createPost_TitleExceedsCharacterLimit() {
		// Validate the input with validatePostCreation() using a title that exceeds the character limit.
		String title = "a".repeat(201);
		String error = ControllerCreatePost.validatePostCreation(0, title, "This post title should be too long", "smountee");
		
		// Verify that the error produced by validatePostCreation() is what's expected.
		assertEquals("Post title cannot exceed 200 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a correct error is thrown when a post's body exceeds the character limit.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: "As a student, I can post statements and questions and receive replies.".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test calls the validatePostCreation()
	 * method (which is used when an attempt to create a new post happens), and either returns an error message
	 * as a String object if it doesn't pass input validation, or null if it does. JUnit's assertEquals() method
	 * is then called to compare the actual output of validatePostCreation() with the expected error message for this
	 * test.</p>
	 * 
	 */
	@Test
	public void createPost_BodyExceedsCharacterLimit() {
		// Validate the input with validatePostCreation() using a body that exceeds the character limit.
		String body = "a".repeat(10001);
		String error = ControllerCreatePost.validatePostCreation(0, "This post body should be too long", body, "smountee");
		
		// Verify that the error produced by validatePostCreation() is what's expected.
		assertEquals("Post body cannot exceed 10,000 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that a post is successfully created if it passes all validation checks.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: "As a student, I can post statements and questions and receive replies." and
	 * "As a student, I can post to different threads".</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test combines both input validation
	 * and actual post creation to verify that a post can successfully be created if all input is valid. It
	 * first tests input validation by combining validatePostCreation() and assertNull() (since validatePostCreation()
	 * should return null if the post is valid). It then uses assertDoesNotThrow() to verify that the database method
	 * create() post does not throw an error, thus validating that a post was successfully created. By creating two
	 * different threads, and two different posts, this test also validates that students can post to different threads.</p>
	 * 
	 */
	@Test
	public void createPost() {
		// Reset the database.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
			database.createThread("Homework", "This is a thread that contains any posts related to homework", "smountee");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		String error = ControllerCreatePost.validatePostCreation(1, "TP2 Question", "When is the soft deadline due for TP2?", "smountee");
		String error2 = ControllerCreatePost.validatePostCreation(2, "HW3 Question", "I am unsure about deliverable 1's requirements...", "smountee");
		assertNull(error);
		assertNull(error2);
		
		assertDoesNotThrow(() -> {
			database.createPost(1, null, "smountee", "TP2 Question", "When is the soft deadline due for TP2?");
			database.createPost(2, null, "smountee", "HW3 Question", "I am unsure about deliverable 1's requirements...");
		});
	}
	
	/**
	 * 
	 * <p>This tests that the system correctly retrieves all of the posts in the database, allowing them to be shown to the user</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: As a student, I can see a list of posts</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test validates that the getPosts()
	 * method works correctly by using an expectedPosts list and an actualPosts list. expectedPosts is initialized
	 * first, and actualPosts is initialized by calling the getPosts() method after actually creating posts
	 * and adding them to the database. This test then uses assertEquals() in a few different ways to verify
	 * that the posts are retrieved as expected.</p>
	 * 
	 */
	@Test
	public void listAllPosts() {
		// Reset the database.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// expectedPosts is a list of Post objects used to compare against the results of PostsCollection.getPosts();
		List<Post> expectedPosts = new ArrayList<>();
		expectedPosts.add(new Post(1, 1, "smountee", "TP1 Question", "When will TP1 grades be out?", false, 0, false));
		expectedPosts.add(new Post(2, 1, "smountee", "TP2", "When is the soft deadline for TP2?", false, 0, false));
		expectedPosts.add(new Post(3, 1, "smountee", "TP3", "How long before finals will TP3 be due?", false, 0, false));
		
		// A "Projects" thread is created, and three posts are added to that thread in the database
		try {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
			database.createPost(1, null, "smountee", "TP1 Question", "When will TP1 grades be out?");
			database.createPost(1, null, "smountee", "TP2", "When is the soft deadline for TP2?");
			database.createPost(1, null, "smountee", "TP3", "How long before finals will TP3 be due?");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// A PostsCollection object is created, which is used to link to the database and retrieve all the posts in the system.
		PostsCollection postStore = new PostsCollection(database, "smountee");
		List<Post> actualPosts = postStore.getPosts();
		
		// Verify that there are the expected amount of posts returned from getPosts()
		assertEquals(expectedPosts.size(), actualPosts.size());
		
		// Verify that all the content of the actual posts returned from
		// getposts() match with what is in the expected posts array.
		for (int i = 0; i < actualPosts.size(); i++) {
			assertEquals(expectedPosts.get(i).getPostID(), actualPosts.get(i).getPostID());
			assertEquals(expectedPosts.get(i).getThreadID(), actualPosts.get(i).getThreadID());
			assertEquals(expectedPosts.get(i).getTitle(), actualPosts.get(i).getTitle());
			assertEquals(expectedPosts.get(i).getContent(), actualPosts.get(i).getContent());
		}
	}
	
	/**
	 * 
	 * <p>This tests that the system correctly retrieves all of the logged in users posts from the database, allowing them to be shown to the user.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: As a student, I can see a list of my posts.</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test validates that the getMyPosts()
	 * method works correctly by using an expectedPosts list and an myActualPosts list. expectedPosts is initialized
	 * first, and myActualPosts is initialized by calling the getMyPosts() method after actually creating posts
	 * and adding them to the database. This test then uses assertEquals() in a few different ways to verify
	 * that the specified user's posts are retrieved as expected.</p>
	 * 
	 */
	@Test
	public void listMyPosts() {
		// Reset the database.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// expectedPosts is a list of Post objects used to compare against the results of PostsCollection.getPosts();
		List<Post> expectedPosts = new ArrayList<>();
		expectedPosts.add(new Post(1, 1, "smountee", "TP1 Question", "When will TP1 grades be out?", false, 0, false));
		expectedPosts.add(new Post(2, 1, "smountee", "TP2", "When is the soft deadline for TP2?", false, 0, false));
		
		// A "Projects" thread is created, and three posts are added to that thread in the database
		// 2 posts are by one author, smountee, and the other is by student1.
		try {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
			database.createPost(1, null, "smountee", "TP1 Question", "When will TP1 grades be out?");
			database.createPost(1, null, "smountee", "TP2", "When is the soft deadline for TP2?");
			database.createPost(1, null, "student1", "TP3", "How long before finals will TP3 be due?");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		PostsCollection postStore = new PostsCollection(database, "smountee");
		// getMyPosts is called using the author name "smountee", which should result in two post
		// objects being returned since 2 of the 3 are authored by "smountee".
		List<Post> myActualPosts = postStore.getMyPosts("smountee");
		
		assertEquals(expectedPosts.size(), myActualPosts.size());
		
		// Verify that all the content of the actual posts returned from
		// getposts() match with what is in the expected posts array.
		for (int i = 0; i < myActualPosts.size(); i++) {
			assertEquals(expectedPosts.get(i).getPostID(), myActualPosts.get(i).getPostID());
			assertEquals(expectedPosts.get(i).getThreadID(), myActualPosts.get(i).getThreadID());
			assertEquals(expectedPosts.get(i).getTitle(), myActualPosts.get(i).getTitle());
			assertEquals(expectedPosts.get(i).getContent(), myActualPosts.get(i).getContent());
		}
	}
	
	/**
	 * 
	 * <p>This tests that the system correctly retrieves all of the posts searched for with a keyword from the database, allowing them to be shown to the user.</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: As as student, I can search for posts with keywords</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test validates that the searchPosts()
	 * method works correctly by using an expectedPosts list and an searchedPosts list. expectedPosts is initialized
	 * first, and searchedPosts is initialized by calling the searchPosts() method after actually creating posts
	 * and adding them to the database. This test then uses assertEquals() in a few different ways to verify
	 * that the posts are retrieved as expected.</p>
	 * 
	 */
	@Test
	public void searchPosts() {
		// Reset the database.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// expectedPosts is a list of Post objects used to compare against the results of PostsCollection.getPosts();
		List<Post> expectedPosts = new ArrayList<>();
		expectedPosts.add(new Post(3, 1, "smountee", "TP3", "How long before finals will TP3 be due?", false, 0, false));
		
		// Create a thread called "Projects" and 3 posts within that thread.
		try {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
			database.createPost(1, null, "smountee", "TP1 Question", "When will TP1 grades be out?");
			database.createPost(1, null, "smountee", "TP2", "When is the soft deadline for TP2?");
			database.createPost(1, null, "student1", "TP3", "How long before finals will TP3 be due?");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Initialize a PostsCollection object to store all posts from the database.
		PostsCollection postStore = new PostsCollection(database, "smountee");
		// Use the PostsCollection's searchPosts() method to search for all posts containing "TP3".
		List<Post> searchedPosts = postStore.searchPosts("TP3");
		
		// Verify that the actual posts stored contain the same number as the expected value.
		assertEquals(expectedPosts.size(), searchedPosts.size());
		
		// Verify that the expected posts match what is saved in the database.
		for (int i = 0; i < searchedPosts.size(); i++) {
			assertEquals(expectedPosts.get(i).getPostID(), searchedPosts.get(i).getPostID());
			assertEquals(expectedPosts.get(i).getThreadID(), searchedPosts.get(i).getThreadID());
			assertEquals(expectedPosts.get(i).getTitle(), searchedPosts.get(i).getTitle());
			assertEquals(expectedPosts.get(i).getContent(), searchedPosts.get(i).getContent());
		}
	}
	
	/**
	 * 
	 * <p>This test verifies that the application correctly can delete a post from the system</p>
	 * 
	 * <p><b>Satisifies Requirement</b>: As a student, I can delete one of my posts</p>
	 * 
	 * <p>By running DiscussionsMainTest.java as a JUnit test, the output of whether the test passes
	 * or not is indicated by either a green checkmark, or a red X. This test validates the the deletePost()
	 * method works correctly. Intially, 2 posts are created, and the test uses assertEquals() to verify
	 * that the actual number of posts in the system is 2. After, the deletePost() method is called,
	 * and another asserEquals() is used to verify that the system now only has 1 post in the system.</p>
	 * 
	 */
	@Test
	public void deletePost() {
		// Reset the database.
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// expectedPosts is a list of Post objects used to compare against the results of PostsCollection.getPosts();
		List<Post> expectedPosts = new ArrayList<>();
		expectedPosts.add(new Post(1, 1, "smountee", "TP3", "How long before finals will TP3 be due?", false, 0, false));
		expectedPosts.add(new Post(2, 1, "smountee", "Final Exam", "When is our final exam?", false, 0, false));
		
		// Create a thread called "Projects" and 2 posts within that thread.
		try {
			database.createThread("Projects", "This is a thread that contains any posts related to class projects.", "smountee");
			database.createPost(1, null, "smountee", "TP3", "How long before finals will TP3 be due?");
			database.createPost(1, null, "smountee", "Final Exam", "When is our final exam?");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Initialize a PostsCollection object to store all posts from the database.
		PostsCollection postStore = new PostsCollection(database, "smountee");
		// Use the PostsCollection's getPosts() method to return all posts in the system.
		List<Post> allPosts = postStore.getPosts();
		
		// Verify that the number of posts in the database match the expected value (2).
		assertEquals(expectedPosts.size(), allPosts.size());
		
		// Create a new expectedPosts list to compare after post deletion.
		List<Post> expectedPosts1 = new ArrayList<>();
		expectedPosts1.add(new Post(1, 1, "smountee", "TP3", "How long before finals will TP3 be due?", false, 0, false));
		
		// Delete a post from the database.
		try {
			database.deletePost(1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Refresh the PostsCollection object to reflect the deleted post.
		postStore.loadAll();
		allPosts = postStore.getPosts();
		
		// Verify that the number of posts in the database match after post deletion.
		assertEquals(expectedPosts1.size(), allPosts.size());
	}
}