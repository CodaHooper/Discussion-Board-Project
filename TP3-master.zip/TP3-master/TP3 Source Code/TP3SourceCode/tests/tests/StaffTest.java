package tests;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import database.Database;
import entityClasses.RequestsCollection;
import java.sql.SQLException;
import java.util.UUID;

/**
 * 
 * <h2>This class tests all of the new staff user stories that are implemented in phase 3 of the team project.</h2>
 * 
 * <p><b>User Stories Tested</b></p>
 * <ul>
 * 	<li>"As a staff member, I can create a set of parameters..."</li>
 *  <li>"As a staff member, I can read a set of parameters..."</li>
 *  <li>"As a staff member, I can update a set of parameters..."</li>
 *  <li>"As a staff member, I can delete a set of parameters..."</li>
 *  <li>"As a staff member, I can request admins to perform admin-specific actions..."</li>
 *  <li>"As a staff member, I can see a list of all closed or completed requests."</li>
 * </ul>
 * 
 */
public class StaffTest {
	/** <p>The database connection used for testing.</p> */
	public static Database database = new Database();

	/** <p>This method runs before all tests to ensure the connection to the database</p> */
	@BeforeAll
	public static void setupDatabaseConnection() throws SQLException {
		try {
			database.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a request's title is empty.</p>
	 * 
	 * <p>This method calls upon the requestInputValidation method inside of ControllerStaffHome.java
	 * passing in an empty title as one of the parameters. Using JUnit 5's assertEquals method, the
	 * actual returned error message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void requestInputValidation_EmptyTitle() {
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation("", "Description");
		
		assertEquals("Request title cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a request's description is empty.</p>
	 * 
	 * <p>This method calls upon the requestInputValidation method inside of ControllerStaffHome.java
	 * passing in an empty description as one of the parameters. Using JUnit 5's assertEquals method,
	 * the actual returned error message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void requestInputValidation_EmptyDescription() {
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation("Title", "");
		
		assertEquals("Request description cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a request's title exceeds the character limit.</p>
	 * 
	 * <p>This method calls upon the requestInputValidation method inside of ControllerStaffHome.java
	 * passing in an long title as one of the parameters. Using JUnit 5's assertEquals method,
	 * the actual returned error message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void requestInputValidation_TitleExceedsLimit() {
		String repeat = "a".repeat(201);
		
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation(repeat, "Description");
		
		assertEquals("Request title cannot exceed 200 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a request's description exceeds the character limit.</p>
	 * 
	 * <p>This method calls upon the requestInputValidation method inside of ControllerStaffHome.java
	 * passing in an long description as one of the parameters. Using JUnit 5's assertEquals method,
	 * the actual returned error message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void requestInputValidation_DescriptionExceedsLimit() {
		String repeat = "a".repeat(1001);
		
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation("Title", repeat);
		
		assertEquals("Request description cannot exceed 1000 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that no error message is returned when a request passes all input validation.</p>
	 * 
	 * <p>This method calls upon the requestInputValidation method inside of ControllerStaffHome.java
	 * passing in valid parameters. Using JUnit 5's assertNull method, we test that the requestInputValidation
	 * method returns null as expected (since no errors should be present).</p>
	 * 
	 */
	@Test
	public void requestInputValidation_Pass() {
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation("Title", "Description");
		
		assertNull(error);
	}
	
	/**
	 * 
	 * <p>This tests that a staff request can successfully be created and added to the database.</p>
	 * 
	 * <p>This method calls both the requestInputValidation, and createRequest methods. It uses JUnit 5's assertNull and
	 * assertDoesNotThrow methods to verify that the functions work as expected.</p>
	 * 
	 */
	@Test
	public void requestCreation_Database() {
		// Reset the database
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Call the input validation method for a staff request
		String error = guiStaffHome.ControllerStaffHome.requestInputValidation("Promote to Staff", "I need User1 to be promoted to a Staff member");
		
		// Verify that no errors were generated during input validation (meaning the input passed all checks)
		assertNull(error);
		
		// Verify that the database method createRequest does not throw any errors (meaning the object was successfully created in the database)
		assertDoesNotThrow(() -> {
			database.createRequest("smounteer", "Promote to Staff", "I need User1 to be promoted to a Staff member", UUID.randomUUID().toString());
		});
	}
	
	/**
	 * 
	 * <p>This tests that a staff request can successfully be created and added to the database,
	 * as well as the functionality of the database.retrievePendingRequests method.</p> 
	 * 
	 * <p>This method calls upon multiple different database and request methods to test the overall flow
	 * of creating a request, retrieving the request, and then accessing the retrieved requests fields.</p>
	 * 
	 */
	public void requestCreation_RetrievePending() {
		// Reset the database
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Initialize a RequestsCollection object to be used later
		RequestsCollection requests = null;
		
		// Verify that the following database method does not throw an exception
		assertDoesNotThrow(() -> {
			// Initialize a UUID
			UUID uuid = UUID.randomUUID();
			
			// Create and add the request to the database
			database.createRequest("smountee", "Invite new student", "I need Student1 invited to the system", uuid.toString());
		});
		
		// Retrieve the one and only request object in the system
		try {
			requests = database.retrievePendingRequests();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Verify that the number of "pending" requests is 1
		assertEquals(1, requests.getNumberOfActiveRequests());
		
		// Verify that the author of the one request is as expected.
		assertEquals("smountee", requests.ActiveRequests.get(0).getAuthor());
		
		// Verify that the title of the one request is as expected.
		assertEquals("Invite new student", requests.ActiveRequests.get(0).getTitle());
		
		// Verify that the description of the one request is as expected.
		assertEquals("I need Student1 invited to the system", requests.ActiveRequests.get(0).getDescription());
	}
	
	/**
	 * 
	 * <p>This tests that a staff request can successfully be created and added to the database,
	 * as well as the functionality of the database.retrieveCompletedRequests method.</p> 
	 * 
	 * <p>This method calls upon multiple different database and request methods to test the overall flow
	 * of creating a request, marking the request as "complete", retrieving the request, and then accessing 
	 * the retrieved requests fields.</p>
	 * 
	 */
	public void requestCreation_RetrieveInactive() {
		// Reset the database
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Initialize a RequestsCollection object to be used later
		RequestsCollection requests = null;
		
		// Verify that none of the following database methods throw exceptions
		assertDoesNotThrow(() -> {
			// Initialize two UUID's
			UUID uuid = UUID.randomUUID();
			UUID uuid2 = UUID.randomUUID();
			
			// Create and add two new requests to the database
			database.createRequest("smountee", "Invite new student", "I need Student1 invited to the system", uuid.toString());
			database.createRequest("smountee", "Promote student to staff", "I need Student2 to have the staff role", uuid2.toString());
			
			// Mark the first request as "complete"
			database.completeRequest(uuid.toString());
		});
		
		// Retrieve ONLY the "completed" requests (so this should only return 1 object, since the other is still "pending"
		try {
			requests = database.retrieveCompletedRequests();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Verify that the number of "completed" requests is 1
		assertEquals(1, requests.getNumberOfActiveRequests());
		
		// Verify that the author of the one request is as expected.
		assertEquals("smountee", requests.ActiveRequests.get(0).getAuthor());
		
		// Verify that the title of the one request is as expected.
		assertEquals("Invite new student", requests.ActiveRequests.get(0).getTitle());
		
		// Verify that the description of the one request is as expected.
		assertEquals("I need Student1 invited to the system", requests.ActiveRequests.get(0).getDescription());
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a parameter's title is empty.</p>
	 * 
	 * <p>This method calls upon the parameterInputValidation method inside of ControllerCriteriaManagement.java,
	 * passing in an empty title as a parameter. Using JUnit 5's assertEquals method, the actual returned error
	 * message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void parameterInputValidation_EmptyTitle() {
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation("", "Description");
	
		assertEquals("Evaluation parameter title cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a parameter's description is empty.</p>
	 * 
	 * <p>This method calls upon the parameterInputValidation method inside of ControllerCriteriaManagement.java,
	 * passing in an empty description as a parameter. Using JUnit 5's assertEquals method, the actual returned error
	 * message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void parameterInputValidation_EmptyDescription() {
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation("Title", "");
	
		assertEquals("Evaluation parameter description cannot be empty.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a parameter's title exceeds the character limit.</p>
	 * 
	 * <p>This method calls upon the parameterInputValidation method inside of ControllerCriteriaManagement.java,
	 * passing in a long title as a parameter. Using JUnit 5's assertEquals method, the actual returned error
	 * message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void parameterInputValidation_TitleExceedsLimit() {
		String repeat = "a".repeat(201);
		
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation(repeat, "Description");
	
		assertEquals("Evaluation parameter title cannot exceed 200 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that an error message is returned when a parameter's description exceeds the character limit.</p>
	 * 
	 * <p>This method calls upon the parameterInputValidation method inside of ControllerCriteriaManagement.java,
	 * passing in a long description as a parameter. Using JUnit 5's assertEquals method, the actual returned error
	 * message is compared against the expected error message.</p>
	 * 
	 */
	@Test
	public void parameterInputValidation_DescriptionExceedsLimit() {
		String repeat = "a".repeat(10001);
		
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation("Title", repeat);
	
		assertEquals("Evaluation parameter description cannot exceed 10,000 characters.", error);
	}
	
	/**
	 * 
	 * <p>This tests that no error message is returned when a parameter passes all input validation.</p>
	 * 
	 * <p>This method calls upon the parameterInputValidation method inside of ControllerCriteriaManagement.java,
	 * passing in valid parameters. Using JUnit 5's assertNull method, we test that the parameterInputValidation
	 * method returns null as expected (since no errors should be present).</p>
	 * 
	 */
	@Test
	public void parameterInputValidation_Pass() {
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation("Title", "Description");
	
		assertNull(error);
	}
	
	/**
	 * 
	 * <p>This tests that a parameter can successfully be created and added to the database.</p>
	 * 
	 * <p>This method calls both the parameterInputValidation, and createParameter methods. It uses JUnit 5's
	 * assertNull and assertDoesNotThrow methods to verify that the functions work as expected.</p>
	 * 
	 */
	@Test
	public void parameterCreation_Database() {
		// Reset the database
		try {
			database.resetDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		// Call input validation method for parameter creation
		String error = guiCriteriaManagement.ControllerCriteriaManagement.parameterInputValidation("Parameter 1", "Parameter Description");
		
		// Verify that the input generates no errors
		assertNull(error);
		
		// Verify that the database method does not throw any exceptions
		assertDoesNotThrow(() -> {
			database.createParameter("Parameter 1", "Parameter Description");
		});
	}
}