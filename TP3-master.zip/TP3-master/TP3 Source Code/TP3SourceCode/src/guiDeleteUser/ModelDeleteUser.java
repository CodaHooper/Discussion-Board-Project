package guiDeleteUser;

/*******
 * <p>
 * Title: ModelDeleteUser Class.
 * </p>
 * 
 * <p>
 * Description: The ModelDeleteUser Page Model. This class is not used as there
 * is no data manipulated by this MVC beyond accepting role information and
 * saving it in the database.
 * </p>
 * 
 */
public class ModelDeleteUser {

}