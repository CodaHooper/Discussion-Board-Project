package guiDeleteUser;

import java.util.Optional;

import guiAddRemoveRoles.ViewAddRemoveRoles;
import javafx.scene.control.ButtonType;

/*******
 * <p>
 * Title: ControllerDeleteUser Class.
 * </p>
 * 
 * <p>
 * Description: This class serves as the controller component within the MVC
 * structure for the Delete User feature. The controller provides methods for
 * confirming user deletion, preventing self-deletion, and navigating back to
 * the home page. It ensures that only authorized users can perform deletion
 * actions and that all related GUI elements are properly updated after any user
 * removal.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 * 
 */
public class ControllerDeleteUser {
	/**********
	 * <p>
	 * Method: repaintTheWindow()
	 * </p>
	 * 
	 * <p>
	 * Description: This method determines the current state of the window and then
	 * establishes the appropriate list of widgets in the Pane to show the proper
	 * set of current values.
	 * </p>
	 * 
	 */
	protected static void repaintTheWindow() {
		ViewDeleteUser.theRootPane.getChildren().clear();
		ViewDeleteUser.theRootPane.getChildren().addAll(ViewDeleteUser.label_PageTitle, ViewDeleteUser.line_Separator1,
				ViewDeleteUser.label_SelectUser, ViewDeleteUser.combobox_SelectUser, ViewDeleteUser.button_DeleteUser,
				ViewDeleteUser.line_Separator2, ViewDeleteUser.button_Return);

		ViewDeleteUser.theStage.setTitle("CSE 360 TP1 | Team 22");
		ViewDeleteUser.theStage.setScene(ViewDeleteUser.theDeleteUserScene);
		ViewDeleteUser.theStage.show();
	}

	/**********
	 * <p>
	 * Method: performReturn()
	 * </p>
	 * 
	 * <p>
	 * Description: This method returns the user (who must be an Admin as only
	 * admins are the only users who have access to this page) to the Admin Home
	 * page.
	 * </p>
	 * 
	 */
	protected static void performReturn() {
		guiAdminHome.ViewAdminHome.displayAdminHome(ViewAddRemoveRoles.theStage, ViewAddRemoveRoles.theUser);
	}

	/**********
	 * <p>
	 * Method: performDeleteUser()
	 * </p>
	 * 
	 * <p>
	 * Description: This method deletes a user from the system. It validates the
	 * inputs, elicits confirmation, and prevents the currently logged-in
	 * administrator from deleting their own account.
	 * </p>
	 * 
	 * <p>
	 * If the deletion is confirmed, this method removes the selected user from the
	 * database and updates the GUI reflect the change. Success and error alerts are
	 * shown to provide feedback to the user.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 */
	protected static void performDeleteUser() {
		ViewDeleteUser.theSelectedUser = (String) ViewDeleteUser.combobox_SelectUser.getValue();

		if (ViewDeleteUser.theUser.getUserName().equals(ViewDeleteUser.theSelectedUser)) {
			ViewDeleteUser.alert_SelfDelete.setTitle("Error");
			ViewDeleteUser.alert_SelfDelete.setContentText("You can't delete your own account!");
			ViewDeleteUser.alert_SelfDelete.showAndWait();
			return;
		} else {
			if (!ViewDeleteUser.theSelectedUser.equals("<Select a User>")) {
				ViewDeleteUser.alert_Confirmation.setTitle("Confirmation");
				ViewDeleteUser.alert_Confirmation.setHeaderText("Are you sure you want to remove this user?");
				ViewDeleteUser.alert_Confirmation.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO);

				Optional<ButtonType> answer = ViewDeleteUser.alert_Confirmation.showAndWait();

				if (answer.isPresent() && (answer.get() == ButtonType.YES)) {
					ViewDeleteUser.database.deleteUser(ViewDeleteUser.theSelectedUser);

					ViewDeleteUser.combobox_SelectUser.getItems().remove(ViewDeleteUser.theSelectedUser);

					ViewDeleteUser.alert_UserDeleted.setTitle("Success");
					ViewDeleteUser.alert_UserDeleted.setHeaderText("User successfully deleted");
					ViewDeleteUser.alert_UserDeleted.showAndWait();

					return;
				}
			}
		}
	}
}