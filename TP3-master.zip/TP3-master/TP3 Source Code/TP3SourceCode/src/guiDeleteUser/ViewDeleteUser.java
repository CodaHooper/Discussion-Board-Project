package guiDeleteUser;

import java.util.List;

import database.Database;
import entityClasses.User;
import guiAdminHome.ViewAdminHome;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

/**
 * <p>
 * Title: ViewDeleteUser Class
 * </p>
 * 
 * <p>
 * Description: The Java/FX-based page for removing a user from the system.
 * </p>
 *
 */
public class ViewDeleteUser {
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	protected static Label label_PageTitle = new Label("Delete a User");

	protected static Line line_Separator1 = new Line(20, 95, width - 20, 95);

	protected static Label label_SelectUser = new Label("Select a user to be removed:");
	protected static ComboBox<String> combobox_SelectUser = new ComboBox<String>();
	protected static Button button_DeleteUser = new Button("Delete User");

	protected static Line line_Separator2 = new Line(20, 525, width - 20, 525);

	protected static Button button_Return = new Button("Return");

	protected static Alert alert_Confirmation = new Alert(AlertType.CONFIRMATION);
	protected static Alert alert_UserDeleted = new Alert(AlertType.INFORMATION);
	protected static Alert alert_SelfDelete = new Alert(AlertType.ERROR);

	private static ViewDeleteUser theView;
	protected static Database database = applicationMain.DiscussionsMain.database;

	protected static Stage theStage;
	protected static Pane theRootPane;
	protected static User theUser;

	public static Scene theDeleteUserScene = null;
	protected static String theSelectedUser = "";

	/**********
	 * <p>
	 * Method: displayDeleteUser(Stage ps, User user)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is the single entry point from outside this package
	 * to cause the DeleteUser page to be displayed.
	 * 
	 * It first sets up very shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the elements that change
	 * based on the user and the system's current state. It then sets the Scene onto
	 * the stage, and makes it visible to the user.
	 * 
	 * @param ps   specifies the JavaFX Stage to be used for this GUI and it's
	 *             methods
	 * 
	 * @param user specifies the User whose roles will be updated
	 *
	 */
	public static void displayDeleteUser(Stage ps, User user) {
		theStage = ps;
		theUser = user;

		if (theView == null) {
			theView = new ViewDeleteUser();
		}

		ControllerDeleteUser.repaintTheWindow();
	}

	/**********
	 * <p>
	 * Method: ViewDeleteUser()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * <p>
	 * This is a singleton, so this is performed just one. Subsequent uses fill in
	 * the changeable fields using the displayDeleteUser method.
	 * </p>
	 * 
	 */
	public ViewDeleteUser() {
		theRootPane = new Pane();
		theDeleteUserScene = new Scene(theRootPane, width, height);

		theDeleteUserScene.getStylesheets().add(getClass().getResource("/css/guiDeleteUser.css").toExternalForm());

		setupLabelUI(label_PageTitle, width, Pos.CENTER, 0, 5);
		label_PageTitle.getStyleClass().add("title");

		setupLabelUI(label_SelectUser, 300, Pos.BASELINE_LEFT, 20, 130);
		label_SelectUser.getStyleClass().add("select-label");

		setupComboBoxUI(combobox_SelectUser, "Dialog", 16, 250, 280, 125);
		List<String> userList = database.getUserList();
		combobox_SelectUser.setItems(FXCollections.observableArrayList(userList));
		combobox_SelectUser.getSelectionModel().select(0);

		setupButtonUI(button_DeleteUser, 150, Pos.CENTER, 600, 125);
		button_DeleteUser.getStyleClass().add("delete-user-button");
		button_DeleteUser.setOnAction((event) -> {
			ControllerDeleteUser.performDeleteUser();
		});

		setupButtonUI(button_Return, 210, Pos.CENTER, 20, 540);
		button_Return.setOnAction((event) -> {
			ViewAdminHome.displayAdminHome(theStage, theUser);
		});
		button_Return.getStyleClass().add("return-button");

		line_Separator1.getStyleClass().add("line");
		line_Separator2.getStyleClass().add("line");
	}

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l The Label object to be initialized
	 * @param w The width of the Button
	 * @param p The alignment (e.g. left, centered, or right)
	 * @param x The location from the left edge (x axis)
	 * @param y The location from the top (y axis)
	 */

	private static void setupLabelUI(Label l, double w, Pos p, double x, double y) {
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b The Button object to be initialized
	 * @param w The width of the Button
	 * @param p The alignment (e.g. left, centered, or right)
	 * @param x The location from the left edge (x axis)
	 * @param y The location from the top (y axis)
	 */
	protected static void setupButtonUI(Button b, double w, Pos p, double x, double y) {
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a ComboBox
	 * 
	 * @param c  The ComboBox object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the ComboBox
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	protected static void setupComboBoxUI(ComboBox<String> c, String ff, double f, double w, double x, double y) {
		c.setStyle("-fx-font: " + f + " " + ff + ";");
		c.setMinWidth(w);
		c.setLayoutX(x);
		c.setLayoutY(y);
	}
}