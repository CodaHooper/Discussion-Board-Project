package guiUserUpdate;

import java.text.Normalizer;
import database.Database;

public class ModelUserUpdate {
	/*******
	 * <p>
	 * Title: ModelUserUpdate Class.
	 * </p>
	 * 
	 * <p>
	 * Description: The Update Account Settings Page Model. This class provides
	 * validation logic for the Update Account Settings Page. It checks and
	 * validates usernames, passwords, first names, middle names, last names,
	 * preferred first names, and emails against the username, password, name, and
	 * email finite state machines located in the "TP1 Design Documents" folder.
	 * Returns messages for the GUI.
	 * </p>
	 * 
	 * @author Nikhil Ugra
	 * 
	 * @version 1.00 2025-09-15 Initial version
	 * 
	 */

	// This enables access to the application's database
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********************************************************************************************
	 * 
	 * Result attributes to be used for GUI applications where a detailed error
	 * message and a pointer to the character of the error will enhance the user
	 * experience.
	 * 
	 */
	private static int state = 0; // The current state value
	private static int nextState = 0; // The next state value
	private static boolean finalState = false; // Is this state a final state?
	private static String inputLine = ""; // The input line
	private static char currentChar; // The current character in the line
	private static int currentCharNdx; // The index of the current character
	private static boolean running; // The flag that specifies if the FSM is
									// running
	// Private method to display the current state of the Username FSM as part of an
	// execution trace

	private static void displayDebuggingInfoUserFSM() {

		if (currentCharNdx >= inputLine.length())
			// display the line with the current state numbers aligned
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "None");
		else
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "  " + currentChar + " "
					+ ((nextState > 99) ? "" : (nextState > 9) || (nextState == -1) ? "   " : "    ") + nextState
					+ "     " + userNameSize);
	}

	// Private method to move to the next character within the limits of the input
	// line
	private static void moveToNextCharacter() {
		currentCharNdx++;
		if (currentCharNdx < inputLine.length())
			currentChar = inputLine.charAt(currentCharNdx);
		else {
			currentChar = ' ';
			running = false;
		}
	}

	/*********************************************************************************************
	 * 
	 * Attributes used by the UserName Finite State Machine to inform the user about
	 * what was and was not valid and point to the character of the error. This will
	 * enhance the user experience.
	 * 
	 */

	public static String userNameRecognizerErrorMessage = ""; // The error message text
	public static String userNameRecognizerInput = ""; // The input being processed
	public static int userNameRecognizerIndexofError = -1; // The index of error location
	private static int userNameSize = 0; // An input length may not be less than 4 characters or exceed 16 characters

	/**********
	 * This method is a mechanical transformation of a Finite State Machine diagram
	 * into a Java method.
	 * 
	 * @param input The input string for the Finite State Machine
	 * @return An output string that is empty if every things is okay or it is a
	 *         String with a helpful description of the error
	 */

	public static String checkForValidUserName(String input) {
		// Check to ensure that there is input to process
		if (input.length() <= 0) {
			userNameRecognizerIndexofError = 0; // Error at first character;
			return "\nThe input is empty";
		}

		// The local variables used to perform the Finite State Machine simulation
		state = 0; // This is the FSM state number
		inputLine = input; // Save the reference to the input line as a global
		currentCharNdx = 0; // The index of the current character
		currentChar = input.charAt(0); // The current character from above indexed position

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state

		userNameRecognizerInput = input; // Save a copy of the input
		running = true; // Start the loop
		nextState = -1; // There is no next state
		System.out.println("\nCurrent Final Input  Next  Date\nState   State Char  State  Size");

		// This is the place where semantic actions for a transition to the initial
		// state occur

		userNameSize = 0; // Initialize the UserName size

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state
		while (running) {
			// The switch statement takes the execution to the code for the current state,
			// where
			// that code sees whether or not the current character is valid to transition to
			// a
			// next state
			switch (state) {
			case 0:
				// State 0 has 1 valid transition that is addressed by an if statement.

				// The current character is checked against A-Z, a-z. If any are matched
				// the FSM goes to state 1

				// A-Z, a-z -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z')) { // Check for a-z
					nextState = 1;

					// Count the character
					userNameSize++;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 1:
				// State 1 has two valid transitions,
				// 1: a A-Z, a-z, 0-9 that transitions back to state 1
				// 2: a period, underscore, or minus sign that transitions to state 2

				// A-Z, a-z, 0-9 -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // Check for 0-9
					nextState = 1;

					// Count the character
					userNameSize++;
				}
				// ., _, - -> State 2
				else if (currentChar == '.' || // check for period
						currentChar == '_' || // check for underscore
						currentChar == '-') { // check for minus sign
					nextState = 2;

					// Count the ., _, or -
					userNameSize++;
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				// If the size is larger than 16, the loop must stop
				if (userNameSize > 16)
					running = false;
				break;

			case 2:
				// State 2 deals with a character after a period in the name.

				// A-Z, a-z, 0-9 -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // Check for 0-9
					nextState = 1;

					// Count the odd digit
					userNameSize++;

				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				// If the size is larger than 16, the loop must stop
				if (userNameSize > 16)
					running = false;
				break;
			}

			if (running) {
				displayDebuggingInfoUserFSM();
				// When the processing of a state has finished, the FSM proceeds to the next
				// character in the input and if there is one, it fetches that character and
				// updates the currentChar. If there is no next character the currentChar is
				// set to a blank.
				moveToNextCharacter();

				// Move to the next state
				state = nextState;

				// Is the new state a final state? If so, signal this fact.
				if (state == 1)
					finalState = true;

				// Ensure that one of the cases sets this to a valid value
				nextState = -1;
			}
			// Should the FSM get here, the loop starts again

		}
		displayDebuggingInfoUserFSM();

		System.out.println("The loop has ended.");

		// When the FSM halts, we must determine if the situation is an error or not.
		// That depends
		// of the current state of the FSM and whether or not the whole string has been
		// consumed.
		// This switch directs the execution to separate code for each of the FSM states
		// and that
		// makes it possible for this code to display a very specific error message to
		// improve the
		// user experience.
		userNameRecognizerIndexofError = currentCharNdx; // Set index of a possible error;

		// The following code is a slight variation to support just console output.
		switch (state) {
		case 0:
			// State 0 is not a final state, so we can return a very specific error message
			userNameRecognizerErrorMessage = "A Username must start with A-Z or a-z.\n";
			return userNameRecognizerErrorMessage;

		case 1:
			// State 1 is a final state. Check to see if the UserName length is valid. If so
			// we
			// we must ensure the whole string has been consumed.

			if (userNameSize < 4) {
				// UserName is too small
				userNameRecognizerErrorMessage = "A Username must have at least 4 characters.\n";
				return userNameRecognizerErrorMessage;
			} else if (userNameSize > 16) {
				// UserName is too long
				userNameRecognizerErrorMessage = "A Username must have no more than 16 characters.\n";
				return userNameRecognizerErrorMessage;
			} else if (currentCharNdx < input.length()) {
				// There are characters remaining in the input, so the input is not valid
				userNameRecognizerErrorMessage = "A Username character may only contain the characters A-Z, a-z, 0-9.\n";
				return userNameRecognizerErrorMessage;
			} else if (theDatabase.usernameUsed(input)) {
				userNameRecognizerErrorMessage = "The username entered already exists.";
				return userNameRecognizerErrorMessage;
			} else {
				// UserName is valid
				userNameRecognizerIndexofError = -1;
				userNameRecognizerErrorMessage = "";
				return userNameRecognizerErrorMessage;
			}

		case 2:
			// State 2 is not a final state, so we can return a very specific error message
			userNameRecognizerErrorMessage = "A Username character after a period, underscore, or minus sign must be A-Z, a-z, or 0-9.\n";
			return userNameRecognizerErrorMessage;

		default:
			// This is for the case where we have a state that is outside of the valid
			// range.
			// This should not happen
			return "";
		}
	}

	/*********************************************************************************************
	 * 
	 * Attributes used by the Password Finite State Machine to inform the user about
	 * what was and was not valid and point to the character of the error. This will
	 * enhance the user experience.
	 * 
	 */

	public static String passwordErrorMessage = ""; // The error message text
	public static String passwordInput = ""; // The input being processed
	public static int passwordIndexofError = -1; // The index where the error was located
	public static boolean foundUpperCase = false;
	public static boolean foundLowerCase = false;
	public static boolean foundNumericDigit = false;
	public static boolean foundSpecialChar = false;
	public static boolean foundLongEnough = false;

	/*
	 * This private method displays the input line and then on a line under it
	 * displays the input up to the point of the error. At that point, a question
	 * mark is place and the rest of the input is ignored. This method is designed
	 * to be used to display information to make it clear to the user where the
	 * error in the input can be found, and show that on the console terminal.
	 * 
	 */

	private static void displayInputState() {
		// Display the entire input line
		System.out.println(inputLine);
		System.out.println(inputLine.substring(0, currentCharNdx) + "?");
		System.out.println("The password size: " + inputLine.length() + "  |  The currentCharNdx: " + currentCharNdx
				+ "  |  The currentChar: \"" + currentChar + "\"");
	}

	/**********
	 * <p>
	 * Title: evaluatePassword - Public Method
	 * </p>
	 * 
	 * <p>
	 * Description: This method is a mechanical transformation of a Directed Graph
	 * diagram into a Java method. This method is used by both the GUI version of
	 * the application as well as the testing automation version.
	 * 
	 * @param input The input string evaluated by the directed graph processing
	 * @return An output string that is empty if every things is okay or it will be
	 *         a string with a helpful description of the error follow by two lines
	 *         that shows the input line follow by a line with an up arrow at the
	 *         point where the error was found.
	 */

	public static String evaluatePassword(String input) {
		// The following are the local variable used to perform the Directed Graph
		// simulation
		passwordErrorMessage = "";
		passwordIndexofError = 0; // Initialize the IndexofError
		inputLine = input; // Save the reference to the input line as a global
		currentCharNdx = 0; // The index of the current character

		if (input.length() <= 0) {
			return "The password is empty!";
		}

		// The input is not empty, so we can access the first character
		currentChar = input.charAt(0); // The current character from the above indexed position

		// The Directed Graph simulation continues until the end of the input is reached
		// or at some
		// state the current character does not match any valid transition to a next
		// state. This
		// local variable is a working copy of the input.
		passwordInput = input; // Save a copy of the input

		// The following are the attributes associated with each of the requirements
		foundUpperCase = false; // Reset the Boolean flag
		foundLowerCase = false; // Reset the Boolean flag
		foundNumericDigit = false; // Reset the Boolean flag
		foundSpecialChar = false; // Reset the Boolean flag
		foundNumericDigit = false; // Reset the Boolean flag
		foundLongEnough = false; // Reset the Boolean flag

		// This flag determines whether the directed graph (FSM) loop is operating or
		// not
		running = true; // Start the loop

		// The Directed Graph simulation continues until the end of the input is reached
		// or at some
		// state the current character does not match any valid transition
		while (running) {
			displayInputState();
			// The cascading if statement sequentially tries the current character against
			// all of
			// the valid transitions, each associated with one of the requirements
			if (currentChar >= 'A' && currentChar <= 'Z') {
				System.out.println("Upper case letter found");
				foundUpperCase = true;
			} else if (currentChar >= 'a' && currentChar <= 'z') {
				System.out.println("Lower case letter found");
				foundLowerCase = true;
			} else if (currentChar >= '0' && currentChar <= '9') {
				System.out.println("Digit found");
				foundNumericDigit = true;
			} else if ("~`!@#$%^&*()_-+={}[]|\\:;\"'<>,.?/".indexOf(currentChar) >= 0) {
				System.out.println("Special character found");
				foundSpecialChar = true;
			} else {
				passwordIndexofError = currentCharNdx;
				return "*** Error *** An invalid character has been found!";
			}
			if (currentCharNdx >= 7 && currentCharNdx <= 31) {
				System.out.println("At least 8 characters found");
				foundLongEnough = true;
			} else if (currentCharNdx > 31) {
				passwordIndexofError = currentCharNdx;
				foundLongEnough = false;
				return "*** Error *** The password exceeded a length of 32 characters!";
			}

			// Go to the next character if there is one
			currentCharNdx++;
			if (currentCharNdx >= inputLine.length())
				running = false;
			else
				currentChar = input.charAt(currentCharNdx);

			System.out.println();
		}

		// Construct a String with a list of the requirement elements that were found.
		String errMessage = "";
		if (!foundUpperCase)
			errMessage += "Upper case; ";

		if (!foundLowerCase)
			errMessage += "Lower case; ";

		if (!foundNumericDigit)
			errMessage += "Numeric digits; ";

		if (!foundSpecialChar)
			errMessage += "Special character; ";

		if (!foundLongEnough)
			errMessage += "Long Enough; ";

		if (errMessage == "")
			return "";

		// If it gets here, there something was not found, so return an appropriate
		// message
		passwordIndexofError = currentCharNdx;
		return errMessage + "conditions were not satisfied";
	}

	/*********************************************************************************************
	 * 
	 * Attributes used by the Name Finite State Machine to inform the user about
	 * what was and was not valid and point to the character of the error. This will
	 * enhance the user experience.
	 * 
	 */

	public static String nameRecognizerErrorMessage = ""; // The error message text
	public static String nameRecognizerInput = ""; // The input being processed
	public static int nameRecognizerIndexofError = -1; // The index of error location
	private static int charCounter = 0; // An input length may not exceed 50 characters
	// Private method to display the current state of the Name FSM as part of an
	// execution trace

	private static void displayDebuggingInfoNameFSM() {

		if (currentCharNdx >= inputLine.length())
			// display the line with the current state numbers aligned
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "None");
		else
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "  " + currentChar + " "
					+ ((nextState > 99) ? "" : (nextState > 9) || (nextState == -1) ? "   " : "    ") + nextState
					+ "     " + charCounter);
	}

	/**********
	 * This method is a mechanical transformation of the Name Finite State Machine
	 * diagram into a Java method.
	 * 
	 * @param input The input string for the Finite State Machine
	 * @return An output string that is empty if every thing is okay or it is a
	 *         String with a helpful description of the error
	 */
	public static String checkForValidName(String input) {
		// Normalize string input to ensure it consists of single Unicode code points
		String normalizedInput = Normalizer.normalize(input, Normalizer.Form.NFC);

		// Check to ensure that there is input to process
		if (normalizedInput.length() <= 0) {
			nameRecognizerIndexofError = 0; // Error at first character;
			return "\nThe input is empty";
		}

		// The local variables used to perform the Finite State Machine simulation
		state = 0; // This is the FSM state number
		inputLine = normalizedInput; // Save the reference to the input line as a global
		currentCharNdx = 0; // The index of the current character
		currentChar = normalizedInput.charAt(0); // The current character from above indexed position

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state

		nameRecognizerInput = normalizedInput; // Save a copy of the normalized input
		running = true; // Start the loop
		nextState = -1; // There is no next state
		System.out.println("\nCurrent Final Input  Next  Date\nState   State Char  State  Size");

		// This is the place where semantic actions for a transition to the initial
		// state occur

		charCounter = 0; // Initialize the Name size

		// The Finite State Machines continues until the end of the normalized input is
		// reached or at some
		// state the current character does not match any valid transition to a next
		// state
		while (running) {
			// The switch statement takes the execution to the code for the current state,
			// where
			// that code sees whether or not the current character is valid to transition to
			// a
			// next state
			switch (state) {
			case 0:
				// State 0 has 1 valid transition that is addressed by an if statement.

				// The current character is checked against any valid Unicode Letter.
				// If any are matched, the FSM goes to state 1.

				// Unicode Letter -> State 1
				if (Character.isLetter((int) currentChar)) { // Check for Unicode letter by converting to
					nextState = 1; // Unicode code point

					// Count the unicode letter
					charCounter++;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is not a unicode letter, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 1:
				// State 1 has two valid transitions,
				// 1: a Unicode letter that transitions back to state 1
				// 2: a space, hyphen/dash, or apostrophe that transitions to state 2

				// Unicode letter -> State 1
				if (Character.isLetter((int) currentChar)) {
					nextState = 1;

					// Count the unicode letter
					charCounter++;
				}
				// space, hyphen/dash, apostrophe -> State 2
				else if (currentChar == ' ' || // check for space
						currentChar == '-' || // check for hyphen/dash
						currentChar == '\'') { // check for apostrophe
					nextState = 2;

					// Count the space, hyphen/dash, or apostrophe
					charCounter++;
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				// If the size is larger than 50, the loop must stop
				if (charCounter > 50)
					running = false;
				break;

			case 2:
				// State 2 deals with a character after a space, hyphen/dash, or apostrophe in
				// the name.

				// Unicode letter -> State 1
				if (Character.isLetter((int) currentChar)) {
					nextState = 1;
					// Count the unicode letter
					charCounter++;

				}
				// If it is not a unicode letter, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				// If the size is larger than 50, the loop must stop
				if (charCounter > 50)
					running = false;
				break;
			}

			if (running) {
				displayDebuggingInfoNameFSM();
				// When the processing of a state has finished, the FSM proceeds to the next
				// character in the input and if there is one, it fetches that character and
				// updates the currentChar. If there is no next character the currentChar is
				// set to a blank.
				moveToNextCharacter();

				// Move to the next state
				state = nextState;

				// Is the new state a final state? If so, signal this fact.
				if (state == 1)
					finalState = true;

				// Ensure that one of the cases sets this to a valid value
				nextState = -1;
			}
			// Should the FSM get here, the loop starts again

		}

		displayDebuggingInfoNameFSM();

		System.out.println("The loop has ended.");

		// When the FSM halts, we must determine if the situation is an error or not.
		// That depends
		// of the current state of the FSM and whether or not the whole normalized
		// string has been consumed.
		// This switch directs the execution to separate code for each of the FSM states
		// and that
		// makes it possible for this code to display a very specific error message to
		// improve the
		// user experience.
		nameRecognizerIndexofError = currentCharNdx; // Set index of a possible error;

		// The following code is a slight variation to support just console output.
		switch (state) {
		case 0:
			// State 0 is not a final state, so we can return a very specific error message
			nameRecognizerErrorMessage = "Name must start with a unicode letter\n";
			return nameRecognizerErrorMessage;

		case 1:
			// State 1 is a final state. Check to see if the Name length is valid. If so we
			// we must ensure the whole normalized string has been consumed.

			if (charCounter < 1) {
				// Name is too small
				nameRecognizerErrorMessage = "Name must have at least 1 character.\n";
				return nameRecognizerErrorMessage;
			} else if (charCounter > 50) {
				// Name is too long
				nameRecognizerErrorMessage = "Name must have no more than 50 characters.\n";
				return nameRecognizerErrorMessage;
			} else if (currentCharNdx < normalizedInput.length()) {
				// There are characters remaining in the input, so the input is not valid
				nameRecognizerErrorMessage = "Name character may only contain valid letters, or a space, hyphen/dash, or apostrophe in-between valid letters.\n";
				return nameRecognizerErrorMessage;
			} else {
				// Name is valid
				nameRecognizerIndexofError = -1;
				nameRecognizerErrorMessage = "";
				return nameRecognizerErrorMessage;
			}

		case 2:
			// State 2 is not a final state, so we can return a very specific error message
			nameRecognizerErrorMessage = "Name character after a space, hyphen/dash, or minus sign must be a valid letter.\n";
			return nameRecognizerErrorMessage;

		default:
			// This is for the case where we have a state that is outside of the valid
			// range.
			// This should not happen
			return "";
		}
	}

	/*********************************************************************************************
	 * 
	 * Attributes used by the Email Finite State Machine to inform the user about
	 * what was and was not valid and point to the character of the error. This will
	 * enhance the user experience.
	 * 
	 */

	private static int localCharCounter = 0; // Local section of email may not exceed 64 characters
	private static int domainCharCounter = 0; // Domain section of email may not exceed 63 characters
	private static int domainPeriodCounter = 0; // There should be at least 1 period in the domain section
	private static int domainLabelCounter = 0; // There should be between 2 to 24 characters in each label
	private static boolean TLDAllLetters = false; // The last label must only contain letters

	// Private method to display the current state of the Email FSM as part of an
	// execution trace
	private static void displayDebuggingInfoEmailFSM() {

		if (currentCharNdx >= inputLine.length())
			// display the line with the current state numbers aligned
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "None");
		else
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "  " + currentChar + " "
					+ ((nextState > 99) ? "" : (nextState > 9) || (nextState == -1) ? "   " : "    ") + nextState
					+ "     " + (localCharCounter + domainCharCounter));
	}

	// Private method to move to the next character within the limits of the input
	// line, modified for the email finite state machine
	private static boolean atEnd;

	private static void moveToNextCharacterEmail() {
		currentCharNdx++;
		if (currentCharNdx < inputLine.length())
			currentChar = inputLine.charAt(currentCharNdx);
		else {
			atEnd = true;
			currentChar = '\0'; // make sure end of input is reached
			running = false;
		}
	}

	public static String emailRecognizerErrorMessage = ""; // The error message text
	public static String emailRecognizerInput = ""; // The input being processed
	public static int emailRecognizerIndexofError = -1; // The index of error location

	/**********
	 * This method is a mechanical transformation of the Email Finite State Machine
	 * diagram into a Java method.
	 * 
	 * @param input The input string for the Finite State Machine
	 * @return An output string that is empty if every thing is okay or it is a
	 *         String with a helpful description of the error
	 */
	public static String checkForValidEmail(String input) {
		// Reset flag
		atEnd = false;

		// Check to ensure that there is input to process
		if (input.length() <= 0) {
			emailRecognizerIndexofError = 0; // Error at first character;
			return "\nThe input is empty";
		}

		// The local variables used to perform the Finite State Machine simulation
		state = 0; // This is the FSM state number
		inputLine = input; // Save the reference to the input line as a global
		currentCharNdx = 0; // The index of the current character
		currentChar = input.charAt(0); // The current character from above indexed position

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state

		emailRecognizerInput = input; // Save a copy of the input
		running = true; // Start the loop
		nextState = -1; // There is no next state
		System.out.println("\nCurrent Final Input  Next  Date\nState   State Char  State  Size");

		// This is the place where semantic actions for a transition to the initial
		// state occur

		localCharCounter = 0; // Reset the Counter

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state
		while (running) {
			// The switch statement takes the execution to the code for the current state,
			// where
			// that code sees whether or not the current character is valid to transition to
			// a
			// next state
			switch (state) {
			case 0:
				// State 0 has 1 valid transition that is addressed by an if statement.

				// The current character is checked against A-Z, a-z, 0-9, and a collection of
				// special characters.
				// If any are matched, the FSM goes to state 1.

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 1:
				// State 1 has three valid transitions,
				// 1: a A-Z, a-z, 0-9, or specific special character that transitions back to
				// state 1
				// 2: a period that transitions to state 2
				// 3: an @ character that transitions to state 3

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// . -> State 2
				else if (currentChar == '.') { // check for period
					nextState = 2;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";
						return emailRecognizerErrorMessage;
					}
				}

				// @ -> State 3
				else if (currentChar == '@') { // check for @
					nextState = 3;

					domainCharCounter = 0; // Reset the Counter
					domainPeriodCounter = 0; // Reset the Counter
					domainLabelCounter = 0; // Reset the Counter
					TLDAllLetters = true; // Set the Flag to True
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 2:
				// State 2 deals with a character after a period in the local section of the
				// email

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 3:
				// State 3 has one 1 valid transition that is addressed by an if statement.

				// The current character is checked against A-Z, a-z, 0-9
				// If any are matched, the FSM goes to state 4.

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar)) // Check if character is a digit
						TLDAllLetters = false;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 4:
				// State 4 has three valid transitions,
				// 1: a A-Z, a-z, or 0-9 that transitions back to state 4
				// 2: a period that transitions to state 5
				// 3: a dash/hyphen that transitions to state 6

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}

				// . -> State 5
				else if (currentChar == '.') {
					nextState = 5;

					// Count the period
					domainCharCounter++;
					domainPeriodCounter++;

					// Validate label that previously ended
					if (domainLabelCounter < 2) {
						emailRecognizerErrorMessage = "Each label in the Domain of the Email must have at least 2 characters.\n";
						return emailRecognizerErrorMessage;
					}

					if (domainLabelCounter > 24) {
						emailRecognizerErrorMessage = "Each label in the Domain of the Email must have no more than 24 characters.\n";
						return emailRecognizerErrorMessage;
					}

					domainLabelCounter = 0; // Reset the Label Counter
					TLDAllLetters = true; // Reset the Flag
				}

				// - -> State 6
				else if (currentChar == '-') {
					nextState = 6;

					// Count the hyphen/dash
					domainCharCounter++;
					domainLabelCounter++;

					TLDAllLetters = false; // False since dash is not a letter
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 5:
				// State 5 deals with a character after a period in the domain section of the
				// email

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 6:
				// State 6 deals with a character after a hyphen/dash in the domain section of
				// the email

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;
			}

			if (running) {
				displayDebuggingInfoEmailFSM();
				// When the processing of a state has finished, the FSM proceeds to the next
				// character in the input and if there is one, it fetches that character and
				// updates the currentChar. If there is no next character the currentChar is
				// set to a blank.
				moveToNextCharacterEmail();

				// Move to the next state
				state = nextState;

				// Is the new state a final state? If so, signal this fact.
				if (state == 4)
					finalState = true;

				// Ensure that one of the cases sets this to a valid value
				nextState = -1;
			}
			// Should the FSM get here, the loop starts again

		}

		displayDebuggingInfoEmailFSM();

		System.out.println("The loop has ended.");

		// When the FSM halts, we must determine if the situation is an error or not.
		// That depends on the string of the current state of the FSM and whether or not
		// the
		// whole string has been consumed.
		// This switch directs the execution to separate code for each of the FSM states
		// and that makes it possible for this code to display a very specific error
		// message to improve the user experience.
		emailRecognizerIndexofError = currentCharNdx; // Set index of a possible error;

		// The following code is a slight variation to support just console output.
		switch (state) {
		case 0:
			// State 0 is not a final state, so we can return a very specific error message
			emailRecognizerErrorMessage = "An Email must start with a letter, digit or "
					+ "specific special character (!#$%&'*+/=?^_{|}~-).\n";
			return emailRecognizerErrorMessage;

		case 1:
			// State 1 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "Missing '@' and domain after the local part of the email.";
			} else {
				emailRecognizerErrorMessage = "An Email in the local section can only contain letters, digits"
						+ ", specific special characters (!#$%&'*+/=?^_{|}~-), or period (between characters).\n";
			}
			return emailRecognizerErrorMessage;

		case 2:
			// State 2 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "The local part of an email cannot end with a period.";
			} else {
				emailRecognizerErrorMessage = "A period must be followed by a letter, digit, or "
						+ "specific special character (e.g., !#$%&'*+/=?^_{|}~-).\n";
			}
			return emailRecognizerErrorMessage;

		case 3:
			// State 3 is not a final state, so we can return a a very specific error
			// message
			if (atEnd) {
				emailRecognizerErrorMessage = "Missing domain name after '@' in the email address.";
			} else {
				emailRecognizerErrorMessage = "The domain must start with a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;
		case 4:
			// State 4 is a final state. Check to see if the Email requirements are met.
			// if so, we must ensure the whole string has been consumed.

			if (domainLabelCounter < 2) {
				emailRecognizerErrorMessage = "Each label in the Domain of the Email must have at least 2 characters.\n";
				return emailRecognizerErrorMessage;
			}

			else if (domainLabelCounter > 24) {
				emailRecognizerErrorMessage = "Each label in the Domain of the Email must have no more than 24 characters.\n";
				return emailRecognizerErrorMessage;
			}

			else if (domainPeriodCounter < 1) {
				emailRecognizerErrorMessage = "There must be at least one period in the Domain of an Email.\n";
				return emailRecognizerErrorMessage;
			}

			else if (!TLDAllLetters) {
				emailRecognizerErrorMessage = "The final label of the Domain of an Email must solely consist of letters.\n";
				return emailRecognizerErrorMessage;
			} else if (theDatabase.emailaddressUsed(input)) {
				emailRecognizerErrorMessage = "The email address entered already exists.";
				return emailRecognizerErrorMessage;
			} else {
				// Email address is valid
				emailRecognizerIndexofError = -1;
				emailRecognizerErrorMessage = "";
				return emailRecognizerErrorMessage;
			}

		case 5:
			// State 5 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "The domain cannot end with a period.";
			} else {
				emailRecognizerErrorMessage = "A period must be followed by a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;

		case 6:
			// State 6 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "A domain label cannot end with a hyphen.";
			} else {
				emailRecognizerErrorMessage = "A hyphen/dash must be followed by a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;

		default:
			// This is for the case where we have a state that is outside of the valid
			// range.
			// This should not happen
			return "";
		}
	}
}
