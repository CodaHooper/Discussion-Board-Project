package guiUserUpdate;

import java.util.Optional;

import database.Database;
import entityClasses.User;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

/*-********************************************************************************************

The Controller for ViewUserUpdate 

**********************************************************************************************/

/**********
 * <p>
 * Title: ControllerUserUpdate Class
 * </p>
 * 
 * <p>
 * Description: This static class supports the actions initiated by the
 * ViewUserUpdate class.
 * </p>
 *
 */
public class ControllerUserUpdate {

	/*-********************************************************************************************
	
	The User Interface Actions for this page
	
	**********************************************************************************************/

	/**********
	 * <p>
	 * Method: public goToUserHomePage(Stage theStage, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the user has clicked on the button to
	 * proceed to the user's home page.
	 * 
	 * @param theStage specifies the JavaFX Stage for next next GUI page and it's
	 *                 methods
	 * 
	 * @param theUser  specifies the user so we go to the right page and so the
	 *                 right information
	 */
	protected static void goToUserHomePage(Stage theStage, User theUser) {

		// Get the roles the user selected during login
		int theRole = applicationMain.DiscussionsMain.activeHomePage;

		// Use that role to proceed to that role's home page
		switch (theRole) {
		case 1:
			guiAdminHome.ViewAdminHome.displayAdminHome(theStage, theUser);
			break;
		case 2:
			guiStaffHome.ViewStaffHome.displayStaffHome(theStage, theUser);
			break;
		case 3:
			guiStudentHome.ViewStudentHome.displayStudentHome(theStage, theUser);
			break;
		default:
			System.out.println("*** ERROR *** UserUpdate goToUserHome has an invalid role: " + theRole);
			System.exit(0);
		}
	}

	/**********
	 * <p>
	 * Method: protected static boolean evaluateFormFullyFilled(String firstName,
	 * String lastName, String middleName, String perferedName, String email)
	 * </p>
	 * <p>
	 * This method checks that the provided first name, last name, and email are
	 * valid. If the entries are not empty, this method also checks the middle name
	 * and preferred name. Validation is delegated to the Model
	 * </p>
	 *
	 * @param firstName     the user's first name (valid AND non-empty)
	 * @param lastName      the user's last name (valid AND non-empty)
	 * @param middleName    the user's middle name (valid IF non-empty)
	 * @param preferredName the user's preferred name (valid IF non-empty)
	 * @param email         the user's email (valid AND non-empty)
	 * 
	 */
	protected static String evaluateFormFullyFilled(String firstName, String lastName, String middleName,
			String preferredName, String email) {

		String out = "";

		if (firstName.compareTo("<none>") == 0) {
			out += "First name is required.\n";
		}
		if (lastName.compareTo("<none>") == 0) {
			out += "Last name is required.\n";
		}

		if (email.compareTo("<none>") == 0) {
			out += "Email address is required.\n";
		}
		// We can be confident that an email in the database is correctly formatted by
		// previous checks, and if the user has changed it, then it must be changed to a
		// valid email address. Therefore, if the email address is in the database, or
		// if it is a valid email address, then this field is considered filled
		// properly allowing the user to proceed with their account creation

		return out;
	}

	// Parse the message from the model and turn it into something that looks nice
	// to display. Only took names and password out of the view class anonymous
	// declarations for now, may need to move some more of those methods over to
	// this class if their complexity increases significantly

	/**********
	 * <p>
	 * 
	 * Method: updateFirstName().
	 * </p>
	 * 
	 * <p>
	 * Description: Protected static method that is intended to handle the user
	 * First Name update process. The method prompts the user with a dialog to enter
	 * a new First Name , validates the entered value and displays a helpful error
	 * message if the name does not meet the required constraints. If the name is
	 * valid, the method updates the user’s First Name in the database, refreshes
	 * the user’s account details, and updates the UI label with the new First Name.
	 * </p>
	 * 
	 * @param theDatabase This Database object provides access to the user account
	 *                    details and is used to update the stored First Name.
	 * @param theUser     This User object represents the user whose First Name is
	 *                    being updated. Its First Name field is updated if the new
	 *                    First Name is valid and successfully saved
	 */
	protected static void updateFirstName(Database theDatabase, User theUser) {
		ViewUserUpdate.dialogUpdateFirstName.getEditor().setText("");
		Optional<String> result = ViewUserUpdate.dialogUpdateFirstName.showAndWait();
		if (!result.isPresent())
			return;

		// Receive the potential first name and evaluate it by using the
		// ModelUserUpdate class.
		String potentialFirstName = result.get().trim();
		String validityMessage = ModelUserUpdate.checkForValidName(potentialFirstName);

		// Display the error message and do not update the DB.
		if (!validityMessage.isEmpty()) {
			String displayMessage = parseAndBuildNameDisplayErrorMessage(validityMessage, "First");

			Alert a = new Alert(AlertType.ERROR);
			a.setTitle("Invalid First Name");
			a.setHeaderText("First name does not meet requirements.");
			a.setContentText(displayMessage);
			a.showAndWait();
			validityMessage = "";
			return;
		}
		result.ifPresent(name -> theDatabase.updateFirstName(theUser.getUserName(), result.get()));
		theDatabase.getUserAccountDetails(theUser.getUserName());
		String newName = theDatabase.getCurrentFirstName();
		theUser.setFirstName(newName);
		if (newName == null || newName.length() < 1)
			ViewUserUpdate.label_CurrentFirstName.setText("<none>");
		else
			ViewUserUpdate.label_CurrentFirstName.setText(newName);
	}

	/**********
	 * <p>
	 * 
	 * Method: updateMiddleName().
	 * </p>
	 * 
	 * <p>
	 * Description: Protected static method that is intended to handle the user
	 * Middle Name update process. The method prompts the user with a dialog to
	 * enter a new Middle Name , validates the entered value and displays a helpful
	 * error message if the name does not meet the required constraints. If the name
	 * is valid, the method updates the user’s Middle Name in the database,
	 * refreshes the user’s account details, and updates the UI label with the new
	 * Middle Name.
	 * </p>
	 * 
	 * @param theDatabase This Database object provides access to the user account
	 *                    details and is used to update the stored Middle Name.
	 * @param theUser     This User object represents the user whose Middle Name is
	 *                    being updated. Its Middle Name field is updated if the new
	 *                    Middle Name is valid and successfully saved
	 */
	protected static void updateMiddleName(Database theDatabase, User theUser) {
		ViewUserUpdate.dialogUpdateMiddleName.getEditor().setText("");
		Optional<String> result = ViewUserUpdate.dialogUpdateMiddleName.showAndWait();
		if (!result.isPresent())
			return;

		// Receive the potential middle name and evaluate it by using the
		// ModelUserUpdate class.
		String potentialMiddleName = result.get().trim();
		String validityMessage = ModelUserUpdate.checkForValidName(potentialMiddleName);

		// Display the error message and do not update the DB.
		if (!validityMessage.isEmpty()) {
			String displayMessage = parseAndBuildNameDisplayErrorMessage(validityMessage, "Middle");

			Alert a = new Alert(AlertType.ERROR);
			a.setTitle("Invalid Middle Name");
			a.setHeaderText("Middle name does not meet requirements.");
			a.setContentText(displayMessage);
			a.showAndWait();
			validityMessage = "";
			return;
		}
		result.ifPresent(name -> theDatabase.updateMiddleName(theUser.getUserName(), result.get()));
		theDatabase.getUserAccountDetails(theUser.getUserName());
		String newName = theDatabase.getCurrentMiddleName();
		theUser.setMiddleName(newName);
		if (newName == null || newName.length() < 1)
			ViewUserUpdate.label_CurrentMiddleName.setText("<none>");
		else
			ViewUserUpdate.label_CurrentMiddleName.setText(newName);
	}

	/**********
	 * <p>
	 * 
	 * Method: updateLastName().
	 * </p>
	 * 
	 * <p>
	 * Description: Protected static method that is intended to handle the user Last
	 * Name update process. The method prompts the user with a dialog to enter a new
	 * Last Name , validates the entered value and displays a helpful error message
	 * if the name does not meet the required constraints. If the name is valid, the
	 * method updates the user’s Last Name in the database, refreshes the user’s
	 * account details, and updates the UI label with the new Last Name.
	 * </p>
	 * 
	 * @param theDatabase This Database object provides access to the user account
	 *                    details and is used to update the stored Last Name.
	 * @param theUser     This User object represents the user whose Last Name is
	 *                    being updated. Its Last Name field is updated if the new
	 *                    Last Name is valid and successfully saved
	 */
	protected static void updateLastName(Database theDatabase, User theUser) {
		ViewUserUpdate.dialogUpdateLastName.getEditor().setText("");
		Optional<String> result = ViewUserUpdate.dialogUpdateLastName.showAndWait();
		if (!result.isPresent())
			return;

		// Receive the potential last name and evaluate it by using the
		// ModelUserUpdate class.
		String potentialLastName = result.get().trim();
		String validityMessage = ModelUserUpdate.checkForValidName(potentialLastName);

		// Display the error message and do not update the DB.
		if (!validityMessage.isEmpty()) {
			String displayMessage = parseAndBuildNameDisplayErrorMessage(validityMessage, "Last");

			Alert a = new Alert(AlertType.ERROR);
			a.setTitle("Invalid Last Name");
			a.setHeaderText("Last name does not meet requirements.");
			a.setContentText(displayMessage);
			a.showAndWait();
			validityMessage = "";
			return;
		}
		result.ifPresent(name -> theDatabase.updateLastName(theUser.getUserName(), result.get()));
		theDatabase.getUserAccountDetails(theUser.getUserName());
		String newName = theDatabase.getCurrentLastName();
		theUser.setLastName(newName);
		if (newName == null || newName.length() < 1)
			ViewUserUpdate.label_CurrentLastName.setText("<none>");
		else
			ViewUserUpdate.label_CurrentLastName.setText(newName);
	}

	/**********
	 * <p>
	 * 
	 * Method: updatePreferredFirstName().
	 * </p>
	 * 
	 * <p>
	 * Description: Protected static method that is intended to handle the user
	 * Preferred First Name update process. The method prompts the user with a
	 * dialog to enter a new Preferred First Name, validates the entered value and
	 * displays a helpful error message if the name does not meet the required
	 * constraints. If the name is valid, the method updates the user’s Preferred
	 * First Name in the database, refreshes the user’s account details, and updates
	 * the UI label with the new Preferred First Name.
	 * </p>
	 * 
	 * @param theDatabase This Database object provides access to the user account
	 *                    details and is used to update the stored Preferred First
	 *                    Name.
	 * @param theUser     This User object represents the user whose Preferred First
	 *                    Name is being updated. Its Preferred First Name field is
	 *                    updated if the new Preferred First Name is valid and
	 *                    successfully saved
	 */
	protected static void updatePreferredFirstName(Database theDatabase, User theUser) {
		ViewUserUpdate.dialogUpdatePreferredFirstName.getEditor().setText("");
		Optional<String> result = ViewUserUpdate.dialogUpdatePreferredFirstName.showAndWait();
		if (!result.isPresent())
			return;

		// Receive the potential preferred first name and evaluate it by using the
		// ModelUserUpdate class.
		String potentialLastName = result.get().trim();
		String validityMessage = ModelUserUpdate.checkForValidName(potentialLastName);

		// Display the error message and do not update the DB.
		if (!validityMessage.isEmpty()) {
			String displayMessage = parseAndBuildNameDisplayErrorMessage(validityMessage, "Preferred First");

			Alert a = new Alert(AlertType.ERROR);
			a.setTitle("Invalid Last Name");
			a.setHeaderText("Preferred first name does not meet requirements");
			a.setContentText(displayMessage);
			a.showAndWait();
			validityMessage = "";
			return;
		}
		result.ifPresent(name -> theDatabase.updatePreferredFirstName(theUser.getUserName(), result.get()));
		theDatabase.getUserAccountDetails(theUser.getUserName());
		String newName = theDatabase.getCurrentPreferredFirstName();
		theUser.setPreferredFirstName(newName);
		if (newName == null || newName.length() < 1)
			ViewUserUpdate.label_CurrentPreferredFirstName.setText("<none>");
		else
			ViewUserUpdate.label_CurrentPreferredFirstName.setText(newName);
	}

	/**********
	 * <p>
	 * 
	 * Method: updatePassword().
	 * </p>
	 * 
	 * <p>
	 * Description: Protected static method that is intended to handle the user
	 * password update process. The method prompts the user with a dialog to enter a
	 * new password, validates the entered value by reusing logic from the
	 * ModelFirstAdmin class, and displays a helpful error message if the password
	 * does not meet the required constraints. If the password is valid, the method
	 * updates the user’s password in the database, refreshes the user’s account
	 * details, and updates the UI label with the new password.
	 * </p>
	 * 
	 * @param theDatabase This Database object provides access to the user account
	 *                    details and is used to update the stored password.
	 * @param theUser     This User object represents the user whose password is
	 *                    being updated. Its password field is updated if the new
	 *                    password is valid and successfully saved. *
	 */

	protected static void updatePassword(Database theDatabase, User theUser) {
		ViewUserUpdate.diaLogUpdatePassword.getEditor().setText("");
		Optional<String> result = ViewUserUpdate.diaLogUpdatePassword.showAndWait();
		if (!result.isPresent())
			return;

		// Receive the potential password and evaluate it by reusing the ModelFirstAdmin
		// class.
		String potentialPass = result.get().trim();
		String passMessage = ModelUserUpdate.evaluatePassword(potentialPass);

		// Display the error message and do not update the DB.
		if (!passMessage.isEmpty()) {
			String errorMessage = buildPassErrorMessage(passMessage);
			Alert a = new Alert(AlertType.ERROR);
			a.setTitle("Invalid Password");
			a.setHeaderText("Password does not meet requirements");
			a.setContentText(errorMessage);
			a.showAndWait();
			return;
		}
		result.ifPresent(name -> theDatabase.updatePassword(theUser.getUserName(), potentialPass));
		theDatabase.getUserAccountDetails(theUser.getUserName());
		String newPassword = theDatabase.getCurrentPassword();
		theUser.setPassword(newPassword);
		if (newPassword == null || newPassword.length() < 1)
			ViewUserUpdate.label_CurrentPassword.setText("<none>");
		else
			ViewUserUpdate.label_CurrentPassword.setText(newPassword);
	}

	/**********
	 * <p>
	 * 
	 * Method: buildPassErrorMessage().
	 * </p>
	 * 
	 * <p>
	 * Description: Public static method that generates a user-friendly error
	 * message describing why a given password input is invalid. this method
	 * converts the error message into more meaningful feedback for the user, such
	 * as whether the password is empty, exceeds length limits, or is missing
	 * certain required character types (uppercase, lowercase, digit, or special
	 * character).
	 * </p>
	 * 
	 * @param passMessage This String contains the raw error message for the
	 *                    password
	 * 
	 * @return String Returns a user-friendly error message that explains the
	 *         problem with the password in plain English. If multiple requirements
	 *         are missing, the message lists each missing element.
	 */

	public static String buildPassErrorMessage(String passMessage) {

		System.out.println("\tPass message:\t" + passMessage);

		if (passMessage.equals("*** Error *** The password is empty!")) {
			return "Your password cannot be empty!";
		}

		if (passMessage.contains("*** Error *** The password exceeded a length of 32 characters!")
				|| passMessage.contains("Long Enough;")) {
			return "Your password must be between 8 and 32 charecters!";
		}

		String out = "Your password is missing:\n";
		if (passMessage.contains("Upper case;")) {
			out += "Upper case charecter\n";
		}
		if (passMessage.contains("Lower case;")) {
			out += "Lower case charecter\n";
		}
		if (passMessage.contains("Numeric digits;")) {
			out += "A digit 0-9\n";
		}
		if (passMessage.contains("Special character;")) {
			out += "A special charecter: ~`!@#$%^&*()_-+={}[]|\\\\:;\\\"'<>,.?/";
		}
		return out;

	}

	/**********
	 * <p>
	 * 
	 * Method: parseAndBuildNameDisplayErrorMessage().
	 * </p>
	 * 
	 * <p>
	 * Description: Public static method that generates a user-friendly error
	 * message describing why a given name input is invalid. this method converts
	 * the error message into more meaningful feedback for the user, such as if the
	 * input is empty, or if the error message needs to be labeled with the provided
	 * field description to the error message for clearer feedback in the user
	 * interface.
	 * </p>
	 * 
	 * @param message  This String contains the raw validation message generated for
	 *                 a particular name input field
	 * @param nameType This String specifies which name field (e.g., "First",
	 *                 "Last", "Middle") the error message is associated with.
	 * 
	 * @return String Returns a formatted error message suitable for display, either
	 *         the original message if the input is empty or the name type prepended
	 *         to the message for clarity.
	 */

	private static String parseAndBuildNameDisplayErrorMessage(String message, String nameType) {
		if (message.contains("The input is empty")) {
			return message;
		}
		return nameType + " " + message;
	}

	public static void performLogout() {
		ViewUserUpdate.theRootPane.getChildren().add(ViewUserUpdate.button_ProceedToUserHomePage);
		ViewUserUpdate.theRootPane.getChildren().remove(ViewUserUpdate.button_Logout);
		guiUserLogin.ViewUserLogin.displayUserLogin(ViewUserUpdate.theStage);

	}
}
