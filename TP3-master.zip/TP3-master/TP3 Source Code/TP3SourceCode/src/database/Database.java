package database;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.time.LocalDateTime;

import entityClasses.Post;
import entityClasses.Reply;
import entityClasses.User;
import entityClasses.RequestsCollection;

/*******
 * <p>
 * Title: Database Class.
 * </p>
 * 
 * <p>
 * Description: This is an in-memory database built on H2. Detailed
 * documentation of H2 can be found at https://www.h2database.com/html/main.html
 * (Click on "PDF (2MP) for a PDF of 438 pages on the H2 main page.) This class
 * leverages H2 and provides numerous special supporting methods.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2025
 * </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 2.00 2025-04-29 Updated and expanded from the version produce by on
 *          a previous version by Pravalika Mukkiri and Ishwarya Hidkimath Basavaraj
 */

/*
 * The Database class is responsible for establishing and managing the
 * connection to the database, and performing operations such as user
 * registration, login validation, handling invitation codes, and numerous other
 * database related functions.
 */
public class Database {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "org.h2.Driver";
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";

	// Database credentials
	static final String USER = "sa";
	static final String PASS = "";

	// Shared variables used within this class
	private Connection connection = null; // Singleton to access the database
	private Statement statement = null;   // The H2 Statement is used to construct queries

	// These are the easily accessible attributes of the currently logged-in user
	// This is only useful for single user applications
	private String currentUsername;
	private String currentPassword;
	private String currentFirstName;
	private String currentMiddleName;
	private String currentLastName;
	private String currentPreferredFirstName;
	private String currentEmailAddress;
	private boolean currentAdminRole;
	private boolean currentStaffRole;
	private boolean currentStudentRole;

	/*******
	 * <p>
	 * Method: Database
	 * </p>
	 * 
	 * <p>
	 * Description: The default constructor used to establish this singleton object.
	 * </p>
	 * 
	 */

	public Database() {

	}

	/*******
	 * <p>
	 * Method: connectToDatabase
	 * </p>
	 * 
	 * <p>
	 * Description: Used to establish the in-memory instance of the H2 database from
	 * secondary storage.
	 * </p>
	 *
	 * @throws SQLException when the DriverManager is unable to establish a
	 *                      connection
	 * 
	 */
	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement();
			// You can use this command to clear the database and restart from fresh.
			// statement.execute("DROP ALL OBJECTS");

			createTables(); // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}
	
	/**
	 * 
	 * <p>Method: resetDatabase</p>
	 * 
	 * <p>Description: Used to reset the database to start from a fresh state.</p>
	 * 
	 * @throws SQLException when the DriverManager is unable to establish a connection.
	 */
	public void resetDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER);
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement();
			statement.execute("DROP ALL OBJECTS");
			
			createTables();
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	/*******
	 * <p>
	 * Method: createTables
	 * </p>
	 * 
	 * <p>
	 * Description: Used to create new instances of the two database tables used by
	 * this class.
	 * </p>
	 * 
	 */
	private void createTables() throws SQLException {
				// Create the user table.
				String userTable = "CREATE TABLE IF NOT EXISTS userDB ("
								 + "id INT AUTO_INCREMENT PRIMARY KEY, "
								 + "userName VARCHAR(255) UNIQUE, "
								 + "password VARCHAR(255), "
								 + "firstName VARCHAR(255), "
								 + "middleName VARCHAR(255), "
								 + "lastName VARCHAR (255), "
								 + "preferredFirstName VARCHAR(255), "
								 + "emailAddress VARCHAR(255), "
								 + "adminRole BOOL DEFAULT FALSE, "
								 + "staffRole BOOL DEFAULT FALSE, "
								 + "studentRole BOOL DEFAULT FALSE);";
				
				// Create the invitation codes table.
			    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
			            					+ "code VARCHAR(10) PRIMARY KEY, "
			            					+ "emailAddress VARCHAR(255), "
			            					+ "role VARCHAR(10), "
			            					+ "expirationDate TIMESTAMP);";
			    
			    // Create the one time passwords table.
			    String oneTimePasswordsTable = "CREATE TABLE IF NOT EXISTS OneTimePasswords ("
			    							 + "userName VARCHAR(255) UNIQUE, "
			    							 + "password VARCHAR(10));";
			    
			    // Create the threads table.
			    String threadsTable = "CREATE TABLE IF NOT EXISTS threads ("
						  			+ "threadID INT AUTO_INCREMENT PRIMARY KEY,"
						  			+ "authorUsername VARCHAR(255),"
						  			+ "title VARCHAR(200) NOT NULL,"
						  			+ "content VARCHAR(10000) NOT NULL);";
			    
			    // Create the posts table.
			    String postsTable = "CREATE TABLE IF NOT EXISTS posts ("
			    				  + "postID INT AUTO_INCREMENT PRIMARY KEY,"
			    				  + "threadID INT NOT NULL,"
			    				  + "parentID INT NULL,"
			    				  + "authorUsername VARCHAR(255),"
			    				  + "title VARCHAR(200) NOT NULL,"
			    				  + "content VARCHAR(10000) NOT NULL,"
			    				  + "isDeleted BOOLEAN DEFAULT FALSE, "
			    				  + "CONSTRAINT fk_posts_thread\n"
			    				  + "   FOREIGN KEY (threadID) REFERENCES threads(threadID)\n"
			    				  + "   ON DELETE CASCADE);";
			    
			    // Create the postsRead table.
			    String postsReadTable = "CREATE TABLE IF NOT EXISTS postsRead (" 
						    		  + "userName VARCHAR(255) NOT NULL, "
									  + "postID INT NOT NULL, " 
						    		  + "isRead BOOLEAN DEFAULT FALSE, " 
						    		  + "PRIMARY KEY (userName, postID), "
									  + "FOREIGN KEY (userName) REFERENCES userDB(userName) ON DELETE CASCADE, "
									  + "FOREIGN KEY (postID) REFERENCES posts(postID) ON DELETE CASCADE);";
			    
			    // Create the evalParameters table.
				String evalParametersTable = "CREATE TABLE IF NOT EXISTS evalParameters ("
						                   + "parameterID INT AUTO_INCREMENT PRIMARY KEY,"
										   + "title VARCHAR(50) UNIQUE NOT NULL, " 
						                   + "description VARCHAR(1000) NOT NULL" + ");";
			    
				// Create the evalScore table.
				String evalScoreTable = "CREATE TABLE IF NOT EXISTS evalScore ("
									  + "scoreID INT AUTO_INCREMENT PRIMARY KEY,"
									  + "userName VARCHAR(255) NOT NULL,"
									  + "postID INT NOT NULL,"
									  + "score INT CHECK (score BETWEEN 0 AND 5),"
									  + "evaluatorUsername VARCHAR(255),"
									  + "UNIQUE(userName, postID),"
									  + "gradedAT TIMESTAMP DEFAULT CURRENT_TIMESTAMP,"
									  + "FOREIGN KEY (userName) REFERENCES userDB(userName) ON DELETE CASCADE,"
									  + "FOREIGN KEY (postID) REFERENCES posts(postID) ON DELETE CASCADE"
									  + ");";

				// Create the requests table
				String requestsTable = "CREATE TABLE IF NOT EXISTS requests ("
									 + "author VARCHAR(255), "
									 + "title VARCHAR(255), "
									 + "description VARCHAR(1000), "
									 + "uuid VARCHAR(255) PRIMARY KEY, "
									 + "status VARCHAR(255));";
									  
				
				// Execute each SQL statement
				statement.execute(userTable);
				statement.execute(invitationCodesTable);
				statement.execute(oneTimePasswordsTable);
				statement.execute(threadsTable);
				statement.execute(postsTable);
				statement.execute(postsReadTable);
				statement.execute(evalParametersTable);
				statement.execute(evalScoreTable);
				statement.execute(requestsTable);
	}
	
	/*******
	 * <p>
	 * Method: createScore(String userName, int postID, int score, String evalUser) 
	 * </p>
	 * 
	 * <p>
	 * Description: Add a record to the evalScore table.
	 * </p>
	 * 
	 * @param userName is the username of the post/reply
	 * 
	 * @param postID is the post ID of the post
	 * 
	 * @param score is the grade the post/reply received
	 * 
	 * @param evalUser is the evaluator username
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public void createScore(String userName, int postID, int score, String evalUser) throws SQLException {
		deleteScore(userName, postID);
		String sql = "INSERT INTO evalScore (userName, postID, score, evaluatorUsername) "
				   + "VALUES (?, ?, ?, ?)";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, userName);
			ps.setInt(2, postID);
			ps.setInt(3, score);
			ps.setString(4, evalUser);
			ps.executeUpdate();
		}
	}
	
	/*******
	 * <p>
	 * Method: Map<String, Object> readScore(String userName, int postID) 
	 * </p>
	 * 
	 * <p>
	 * Description: Read a record from the evalScore table.
	 * </p>
	 * 
	 * @param userName is the username of the post's author
	 * 
	 * @param postID is the post ID of the post/reply
	 * 
	 * @return result which is a hashMap that maps Strings (columns) to objects (values)
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public Map<String, Object> readScore(String userName, int postID) throws SQLException {
		String sql = "SELECT score, evaluatorUsername, gradedAt FROM evalScore WHERE userName = ? AND postID = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, userName);
			ps.setInt(2, postID);
			try (ResultSet rs = ps.executeQuery()) {
				if (!rs.next()) return null;

				Map<String, Object> result = new HashMap<>();
				result.put("score", rs.getInt("score"));
				result.put("evaluator", rs.getString("evaluatorUsername"));
				result.put("gradedAt", rs.getTimestamp("gradedAt"));
				return result;
			}
		}
	}
	
	/*******
	 * <p>
	 * Method: deleteScore(String userName, int postID) 
	 * </p>
	 * 
	 * <p>
	 * Description: Delete a record from the evalScore table.
	 * </p>
	 * 
	 * @param userName is the username of the post's author
	 * 
	 * @param postID is the post ID of the post
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public void deleteScore(String userName, int postID) throws SQLException {
		String sql = "DELETE FROM evalScore WHERE userName = ? AND postID = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, userName);
			ps.setInt(2, postID);
			ps.executeUpdate();
		}
	}
	
	/**
	 * <p>
	 * Method: createRequest(String author, String title, String description, UUID uuid)
	 * </p>
	 * 
	 * <p>
	 * Description: Add a reqeusts to the requests table.
	 * </p>
	 * 
	 * @param author the author of the request
	 * @param title the title of the request
	 * @param description the description of the request
	 * @param uuid the unique identifier of the request
	 */
	public void createRequest(String author, String title, String description, String uuid) throws SQLException {
		String statement = "INSERT INTO requests (author, title, description, uuid, status) VALUES (?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			pstmt.setString(1, author);
			pstmt.setString(2, title);;
			pstmt.setString(3, description);
			pstmt.setString(4, uuid);
			pstmt.setString(5, "Pending");
			pstmt.executeUpdate();
		}  catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * <p>
	 * Method: completeRequest(UUID uuid)
	 * </p>
	 * 
	 * <p>
	 * Description: Mark the specified request as completed (done by an Admin)
	 * </p>
	 * 
	 * @param uuid the UUID to be marked as completed.
	 * @throws SQLException
	 */
	public void completeRequest(String uuid) throws SQLException {
		String statement = "UPDATE requests SET status = 'Complete' WHERE uuid = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			pstmt.setString(1, uuid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * <p>
	 * Method: denyRequest(UUID uuid)
	 * </p>
	 * 
	 * <p>
	 * Description: Mark the specified request as denied (done by an Admin)
	 * </p>
	 * 
	 * @param uuid the UUID to be marked as denied.
	 * @throws SQLException
	 */
	public void denyRequest(String uuid) throws SQLException {
		String statement = "UPDATE requests SET status = 'Denied' WHERE uuid = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			pstmt.setString(1, uuid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * <p>
	 * Method: reopenRequest(UUID uuid)
	 * </p>
	 * 
	 * <p>
	 * Description: Mark the specified request as pending (done by an Admin)
	 * </p>
	 * 
	 * @param uuid the UUID to be marked as pending.
	 * @throws SQLException
	 */
	public void reopenRequest(String uuid) throws SQLException {
		String statement = "UPDATE requests SET status = 'Pending' WHERE uuid = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			pstmt.setString(1, uuid);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * <p>
	 * Method: retrieveActiveRequests()
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieve all of the incomplete requests in the system.
	 * </p>
	 * 
	 * @return a RequestsCollection object representing all incomplete requests in the system.
	 * 
	 * @throws SQLException
	 */
	public RequestsCollection retrievePendingRequests() throws SQLException {
		RequestsCollection requests = new RequestsCollection();
		
		String statement = "SELECT * FROM requests WHERE status = 'Pending'";
		
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				requests.createRequest(rs.getString("author"), rs.getString("title"), rs.getString("description"), rs.getString("uuid"), rs.getString("status"));
			}
		}
		
		return requests;
	}
	
	/**
	 * <p>
	 * Method: retrieveCompletedRequests()
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieve all of the denied or completed requests in the system.
	 * </p>
	 * 
	 * @return a RequestsCollection object representing all completed or denied requests in the system.
	 * 
	 * @throws SQLException
	 */
	public RequestsCollection retrieveCompletedRequests() throws SQLException {
		RequestsCollection requests = new RequestsCollection();
		
		String statement = "SELECT * FROM requests WHERE status = 'Complete' OR status = 'Denied'";
		
		try (PreparedStatement pstmt = connection.prepareStatement(statement)) {
			ResultSet rs = pstmt.executeQuery();
			
			while (rs.next()) {
				requests.createRequest(rs.getString("author"), rs.getString("title"), rs.getString("description"), rs.getString("uuid"), rs.getString("status"));
			}
		}
		
		return requests;
	}
	
	/*******
	 * <p>
	 * Method: createParameter(String title, String description)
	 * </p>
	 * 
	 * <p>
	 * Description: Add a record to the evalParameters table.
	 * </p>
	 * 
	 * @param title       is the title of the evaluation parameter
	 * 
	 * @param description is the description of the evaluation parameter
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public void createParameter(String title, String description) throws SQLException {
		String sql = "INSERT INTO evalParameters(title, description) VALUES (?, ?)";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, title);
			ps.setString(2, description);
			int n = ps.executeUpdate();
			if (n != 1)
				throw new SQLException("INSERT did not affect 1 row");
		}
	}

	/*******
	 * <p>
	 * Method: String readParameter(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: Read the description of an evaluation parameter in the
	 * evalParameter database.
	 * </p>
	 * 
	 * @param title is the title of the evaluation parameter
	 *
	 * @return the description of the parameter, if it exists.
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public String readParameter(String title) throws SQLException {
		String sql = "SELECT description FROM evalParameters WHERE title = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, title);
			try (ResultSet rs = ps.executeQuery()) {
				return rs.next() ? rs.getString(1) : "";
			}
		}
	}

	/*******
	 * <p>
	 * Method: updateParameter(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the description of an evaluation parameter inside of the
	 * evalParameters table.
	 * </p>
	 * 
	 * @param title       is the title of the evaluation parameter
	 * 
	 * @param description is the modified description of the evaluation parameter
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public void updateParameter(String title, String description) throws SQLException {
		String sql = "UPDATE evalParameters SET description = ? WHERE title = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, description);
			ps.setString(2, title);
			ps.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: deleteParameter(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: Delete an evaluation parameter from the database.
	 * </p>
	 * 
	 * @param title is the title of the evaluation parameter to delete
	 * 
	 * @throws SQLException if a database access error occurs
	 */
	public void deleteParameter(String title) throws SQLException {
		String sql = "DELETE FROM evalParameters WHERE title = ?";
		try (PreparedStatement ps = connection.prepareStatement(sql)) {
			ps.setString(1, title);
			ps.executeUpdate();
		}
	}
	
	/*******
	 * <p>
	 * Method: List<Map<String, Object>> fetchAllParameters()
	 * </p>
	 * 
	 * <p>
	 * Description: fetch all parameters from the evalParameters table
	 * </p>
	 * 
	 * @return a list of hashmaps that map table columns to their values
	 */
	public List<Map<String, Object>> fetchAllParameters() throws SQLException {
		List<Map<String, Object>> parameters = new ArrayList<>();
		String query = "SELECT title, description FROM evalParameters;";
		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				HashMap<String, Object> parameter = new HashMap<>();
				parameter.put("title", rs.getString("title"));
				parameter.put("description", rs.getString("description"));

				parameters.add(parameter);
			}
		}
		return parameters;
	}
	
	/*******
	 * <p>
	 * Method: createThread(String author, String title, String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Add a row to the threads table.
	 * </p>
	 * 
	 * @param author  is the unique username of the author of the thread
	 * 
	 * @param title   is premise of the thread
	 * 
	 * @param content is the main contents of the thread
	 */
	public void createThread(String author, String title, String content) throws SQLException {
		String query = "INSERT INTO threads (authorUsername, title, content) "
				 + "VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, author);
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			pstmt.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: HashMap<String, Object> readThread(int threadID)
	 * </p>
	 * 
	 * <p>
	 * Description: Read the author, title, and contents of a thread from the
	 * threads table.
	 * </p>
	 * 
	 * @param threadID the ID number of the thread to read
	 * 
	 * @return HashMap that maps the author, title, and contents of a thread to
	 *         their respective values in the threads table
	 */
	public HashMap<String, Object> readThread(int threadID) {
		String query = "SELECT authorUsername, title, content FROM threads WHERE threadID = ?";
		HashMap<String, Object> threadMap = new HashMap<String, Object>();
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, threadID);
			ResultSet rs = pstmt.executeQuery();
			
			if (rs.next()) {
				threadMap.put("author", rs.getString("authorUsername"));
				threadMap.put("title", rs.getString("title"));
				threadMap.put("content", rs.getString("content"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return threadMap;
	}

	/*******
	 * <p>
	 * Method: updateThread(int threadID, String title, String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the title, and contents of a thread given the threadID
	 * </p>
	 * 
	 * @param threadID the ID number of the thread to delete
	 * 
	 * @param title    the new title to set for the thread
	 * 
	 * @param content  the new contents to set for the thread
	 */
	public void updateThread(int threadID, String title, String content) throws SQLException {
		String query = "UPDATE threads SET title = ?, content = ? WHERE threadID = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, threadID);
			pstmt.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: deleteThread(int threadID)
	 * </p>
	 * 
	 * <p>
	 * Description: Completely erase a thread and any dependent rows
	 * </p>
	 * 
	 * @param threadID the ID number of the thread to delete
	 */
	public void deleteThread(int threadID) throws SQLException {
		String query = "DELETE FROM threads WHERE threadID = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, threadID);
			pstmt.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: List<Map<String, Object>> fetchAllThreads()
	 * </p>
	 * 
	 * <p>
	 * Description: fetch all threads from the threads table
	 * </p>
	 * 
	 * @return a list of hashmaps that map table columns to their values
	 */
	public List<Map<String, Object>> fetchAllThreads() throws SQLException {
		List<Map<String, Object>> threads = new ArrayList<>();
		String query = "SELECT threadID, authorUsername, title, content FROM threads;";
		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				HashMap<String, Object> thread = new HashMap<>();
				thread.put("threadID", rs.getInt("threadID"));
				thread.put("author", rs.getString("authorUsername"));
				thread.put("title", rs.getString("title"));
				thread.put("content", rs.getString("content"));

				threads.add(thread);
			}
		}
		return threads;
	}

	/*******
	 * <p>
	 * Method: createPost(int thread_id, Integer parent_id, String author, String
	 * title, String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Add a row to the posts table.
	 * </p>
	 * 
	 * @param thread_id specifies the thread the post is made under
	 * 
	 * @param parent_id specifies the post being replied to, if not a reply
	 *                  parent_id is null
	 * 
	 * @param author    is the unique username of the author of a post
	 * 
	 * @param title     is the title of the post
	 * 
	 * @param content   is the main contents of the post
	 * 
	 * @return the integer postID of the new post
	 */
	public void createPost(int threadID, Integer parentID, String author, String title, String content)
			throws SQLException {
		String query = "INSERT INTO posts (threadID, parentID, authorUsername, title, content) "
					 + "VALUES (?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, threadID);
			if (parentID == null) pstmt.setNull(2, java.sql.Types.INTEGER);	// if the post is at the root of the thread
			else pstmt.setInt(2, parentID);
			pstmt.setString(3, author);
			pstmt.setString(4, title);
			pstmt.setString(5, content);
			pstmt.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: HashMap<String, Object> readPost(int postID)
	 * </p>
	 * 
	 * <p>
	 * Description: Read the author, title, and contents of a post from the posts
	 * table
	 * </p>
	 * 
	 * @param postID the ID number of the post to read
	 * 
	 * @return HashMap that maps the author, title, and contents of a post to their
	 *         respective values in the posts table
	 * 
	 */
	public HashMap<String, Object> readPost(int postID) throws SQLException {
		String query = "SELECT authorUsername, title, content FROM posts WHERE postID = ?";
		HashMap<String, Object> postMap = new HashMap<String, Object>();
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postID);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				postMap.put("author", rs.getString("authorUsername"));
				postMap.put("title", rs.getString("title"));
				postMap.put("content", rs.getString("content"));
			}
		}
		return postMap;
	}

	/*******
	 * <p>
	 * Method: updatePost(int postID, String title, String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the contents of a post given the postID
	 * </p>
	 * 
	 * @param postID  the ID number of the post to delete
	 * 
	 * @param title   the new title to update the post
	 * 
	 * @param content the new contents to update the post
	 * 
	 */
	public void updatePost(int postID, String title, String content) throws SQLException {
		String query = "UPDATE posts SET title = ?, content = ? WHERE postID = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, postID);
			pstmt.executeUpdate();
		}
	}

	/*******
	 * <p>
	 * Method: deletePost(int postID)
	 * </p>
	 * 
	 * <p>
	 * Description: If the post has replies, perform a soft delete. Otherwise,
	 * perform a hard delete.
	 * </p>
	 * 
	 * @param postID the ID number of the post to delete
	 * 
	 */
	public void deletePost(int postID) throws SQLException {
		int count = countReplies(postID);
		String query;
		// If there are replies, soft delete
		if (count > 0) 
			query = "UPDATE posts SET authorUsername = 'N/A', "
				  + "title = 'DELETED', "
				  + "content = 'This post has been deleted.', "	
				  + "isDeleted = TRUE WHERE postID = ?";
		// If no replies, hard delete
		else
			query = "DELETE FROM posts WHERE postID = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postID);
			pstmt.executeUpdate();
		} 
	}

	/*******
	 * <p>
	 * Method: setReadPost(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: When a user reads a post, it will be marked as read.
	 * </p>
	 * 
	 * @param postID   the ID number of the post to mark as read
	 * 
	 * @param username the unique username of the user
	 * 
	 */
	public void setReadPost(int postID, String username) {
		String query = "MERGE INTO postsRead(userName, postID, isRead) " + "KEY (userName, postID) VALUES (?, ?, TRUE)";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.setInt(2, postID);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: public boolean isAPostRead(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This method checks the postsRead table for an entry
	 * corresponding to the postID and username. If an entry exists, it returns the
	 * value of the isRead column, otherwise false
	 * </p>
	 * 
	 * Class & method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 *
	 * @param postID   The unique identifier of the post to check.
	 * @param username The username of the user whose read status is being queried.
	 *
	 * @return true if the user has read the post as, otherwise false
	 */
	public boolean isAPostRead(int postID, String username) {
		String query = "SELECT isRead FROM postsRead WHERE postID = ? AND userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postID);
			pstmt.setString(2, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getBoolean("isRead");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: int countReplies(int postID)
	 * </p>
	 * 
	 * <p>
	 * Description: count the number of replies to a post given the post's id
	 * </p>
	 * 
	 * @param postID the ID number of the post to query
	 * 
	 * @return the number of replies to a given post
	 * 
	 */
	public int countReplies(int postID) {
		String query = "SELECT COUNT(*) AS count FROM posts WHERE parentID = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postID);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getInt("count");
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	/*******
	 * <p>
	 * Method: List<Map<String, Object>> fetchAllPosts()
	 * </p>
	 * 
	 * <p>
	 * Description: fetch all posts from the posts table
	 * </p>
	 * 
	 * @return a list of hashmaps that map table columns to their values
	 * 
	 */
	public List<Map<String, Object>> fetchAllPosts() throws SQLException {
		List<Map<String, Object>> posts = new ArrayList<>();
		String query = "SELECT postID, threadID, parentID, authorUsername, title, content, isDeleted FROM posts";
		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {
			while (rs.next()) {
				HashMap<String, Object> post = new HashMap<>();
				post.put("postID", rs.getInt("postID"));
				post.put("threadID", rs.getInt("threadID"));
				post.put("parentID", rs.getObject("parentID", Integer.class));
				post.put("author", rs.getString("authorUsername"));
				post.put("title", rs.getString("title"));
				post.put("content", rs.getString("content"));
				post.put("isDeleted", rs.getBoolean("isDeleted"));

				posts.add(post);
			}
		}
		return posts;
	}

	/*******
	 * <p>
	 * Method: List<Post> getTopLevelPostsByThread(int threadID)
	 * </p>
	 * 
	 * <p>
	 * Description: Fetch all top-level posts (i.e., posts with parentID IS NULL)
	 * for a given thread. username is used to determine if the user has read each
	 * reply.
	 * </p>
	 * 
	 * @param threadID the ID of the thread whose top-level posts are requested
	 * 
	 * @param username the user requesting posts.
	 * 
	 * @return a list of hashmaps that map table columns to their values
	 * 
	 */
	public List<Post> getTopLevelPostsByThread(int threadID, String username) throws SQLException {
		List<Post> posts = new ArrayList<>();
		int postID;
		String query = "SELECT postID, threadID, parentID, authorUsername, title, content, isDeleted "
					 + "FROM posts WHERE threadID = ? AND parentID IS NULL";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, threadID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				postID = rs.getInt("postID");
				Post post = new Post(postID, rs.getInt("threadID"), rs.getString("authorUsername"),
						rs.getString("title"), rs.getString("content"), rs.getBoolean("isDeleted"),
						countReplies(postID), isAPostRead(postID, username));
				posts.add(post);
			}
		}
		return posts;
	}

	/*******
	 * <p>
	 * Method: List<Reply> getRepliesForPost(int postID)
	 * </p>
	 * 
	 * <p>
	 * Description: fetch all direct replies whose parentID equals the specified
	 * parent postID. username is used to determine if the user has read each reply.
	 * </p>
	 * 
	 * @param postID   The id of the parent post whose replies are requested.
	 * @param username The username of the user requesting the replies
	 * 
	 * @return a list of hashmaps that map table columns to their values
	 * 
	 */
	public List<Reply> getRepliesForPost(int postID, String username) throws SQLException {
		List<Reply> replies = new ArrayList<>();
		String query = "SELECT postID, threadID, parentID, authorUsername, title, content, isDeleted "
					 + "FROM posts WHERE parentID = ?";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setInt(1, postID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				Reply reply = new Reply(rs.getInt("postID"), rs.getInt("threadID"), rs.getInt("parentID"),
						rs.getString("authorUsername"), rs.getString("title"), rs.getString("content"),
						rs.getBoolean("isDeleted"), isAPostRead(rs.getInt("postID"), username));
				replies.add(reply);
			}
		}
		return replies;
	}

	/*******
	 * <p>
	 * Method: isDatabaseEmpty
	 * </p>
	 * 
	 * <p>
	 * Description: If the user database has no rows, true is returned, else false.
	 * </p>
	 * 
	 * @return true if the database is empty, else it returns false
	 * 
	 */
	public boolean isDatabaseEmpty() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count") == 0;
			}
		} catch (SQLException e) {
			return false;
		}
		return true;
	}

	/*******
	 * <p>
	 * Method: getNumberOfUsers
	 * </p>
	 * 
	 * <p>
	 * Description: Returns an integer .of the number of users currently in the user
	 * database.
	 * </p>
	 * 
	 * @return the number of user records in the database.
	 * 
	 */
	public int getNumberOfUsers() {
		String query = "SELECT COUNT(*) AS count FROM userDB";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch (SQLException e) {
			return 0;
		}
		return 0;
	}

	/*******
	 * <p>
	 * Method: register(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Creates a new row in the database using the user parameter.
	 * </p>
	 * 
	 * @throws SQLException when there is an issue creating the SQL command or
	 *                      executing it.
	 * 
	 * @param user specifies a user object to be added to the database.
	 * 
	 */
	public void register(User user) throws SQLException {
		String insertUser = "INSERT INTO userDB (userName, password, firstName, middleName, "
				+ "lastName, preferredFirstName, emailAddress, adminRole, staffRole, studentRole) "
				+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			currentUsername = user.getUserName();
			pstmt.setString(1, currentUsername);

			currentPassword = user.getPassword();
			pstmt.setString(2, currentPassword);

			currentFirstName = user.getFirstName();
			pstmt.setString(3, currentFirstName);

			currentMiddleName = user.getMiddleName();
			pstmt.setString(4, currentMiddleName);

			currentLastName = user.getLastName();
			pstmt.setString(5, currentLastName);

			currentPreferredFirstName = user.getPreferredFirstName();
			pstmt.setString(6, currentPreferredFirstName);

			currentEmailAddress = user.getEmailAddress();
			pstmt.setString(7, currentEmailAddress);

			currentAdminRole = user.getAdminRole();
			pstmt.setBoolean(8, currentAdminRole);

			currentStaffRole = user.getStaffRole();
			pstmt.setBoolean(9, currentStaffRole);

			currentStudentRole = user.getStudentRole();
			pstmt.setBoolean(10, currentStudentRole);

			pstmt.executeUpdate();
		}

	}

	/*******
	 * <p>
	 * Method: List getUserList()
	 * </p>
	 * 
	 * <P>
	 * Description: Generate an List of Strings, one for each user in the database,
	 * starting with "<Select User>" at the start of the list.
	 * </p>
	 * 
	 * @return a list of userNames found in the database.
	 */
	public List<String> getUserList() {
		List<String> userList = new ArrayList<String>();
		userList.add("<Select a User>");
		String query = "SELECT userName FROM userDB";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				userList.add(rs.getString("userName"));
			}
		} catch (SQLException e) {
			return null;
		}
		return userList;
	}

	/**
	 * <p>
	 * Method: deleteUser(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Given a username, delete that user from the userDB table.
	 * </p>
	 * 
	 * @param username
	 */
	public void deleteUser(String username) {
		String query = "DELETE FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: boolean loginAdmin(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Check to see that a user with the specified username, password,
	 * and role is the same as a row in the table for the username, password, and
	 * role.
	 * </p>
	 * 
	 * @param user specifies the specific user that should be logged in playing the
	 *             Admin role.
	 * 
	 * @return true if the specified user has been logged in as an Admin else false.
	 * 
	 */
	public boolean loginAdmin(User user) {
		// Validates an admin user's login credentials so the user can login in as an
		// admin.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND " + "adminRole = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next(); // If a row is returned, rs.next() will return true
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: boolean loginStaff(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Check to see that a user with the specified username, password,
	 * and role is the same as a row in the table for the username, password, and
	 * role.
	 * </p>
	 * 
	 * @param user specifies the specific user that should be logged in playing the
	 *             Student role.
	 * 
	 * @return true if the specified user has been logged in as an Student else
	 *         false.
	 * 
	 */
	public boolean loginStaff(User user) {
		// Validates a student user's login credentials.
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND " + "staffRole = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: boolean loginStudent(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Check to see that a user with the specified username, password,
	 * and role is the same as a row in the table for the username, password, and
	 * role.
	 * </p>
	 * 
	 * @param user specifies the specific user that should be logged in playing the
	 *             Reviewer role.
	 * 
	 * @return true if the specified user has been logged in as an Student else
	 *         false.
	 * 
	 */
	// Validates a reviewer user's login credentials.
	public boolean loginStudent(User user) {
		String query = "SELECT * FROM userDB WHERE userName = ? AND password = ? AND " + "studentRole = TRUE";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			ResultSet rs = pstmt.executeQuery();
			return rs.next();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: boolean doesUserExist(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Check to see that a user with the specified username is in the
	 * table.
	 * </p>
	 * 
	 * @param userName specifies the specific user that we want to determine if it
	 *                 is in the table.
	 * 
	 * @return true if the specified user is in the table else false.
	 * 
	 */
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
		String query = "SELECT COUNT(*) FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {

			pstmt.setString(1, userName);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				// If the count is greater than 0, the user exists
				return rs.getInt(1) > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false; // If an error occurs, assume user doesn't exist
	}

	/*******
	 * <p>
	 * Method: int getNumberOfRoles(User user)
	 * </p>
	 * 
	 * <p>
	 * Description: Determine the number of roles a specified user plays.
	 * </p>
	 * 
	 * @param user specifies the specific user that we want to determine if it is in
	 *             the table.
	 * 
	 * @return the number of roles this user plays (0 - 5).
	 * 
	 */
	// Get the number of roles that this user plays
	public int getNumberOfRoles(User user) {
		int numberOfRoles = 0;
		if (user.getAdminRole())
			numberOfRoles++;
		if (user.getStaffRole())
			numberOfRoles++;
		if (user.getStudentRole())
			numberOfRoles++;
		return numberOfRoles;
	}

	/*******
	 * <p>
	 * Method: String generateInvitationCode(String emailAddress, String role)
	 * </p>
	 * 
	 * <p>
	 * Description: Given an email address and a roles, this method establishes and
	 * invitation code and adds a record to the InvitationCodes table. When the
	 * invitation code is used, the stored email address is used to establish the
	 * new user and the record is removed from the table.
	 * </p>
	 * 
	 * @param emailAddress specifies the email address for this new user.
	 * 
	 * @param role         specified the role that this new user will play.
	 * 
	 * @return the code of six characters so the new user can use it to securely
	 *         setup an account.
	 * 
	 */
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode(String emailAddress, String role) {
		String code = UUID.randomUUID().toString().substring(0, 6); // Generate a random 6-character code
		LocalDateTime expiration = LocalDateTime.now().plusDays(1); // Apply an expiration date to the invitation code
		String query = "INSERT INTO InvitationCodes (code, emailAddress, role, expirationDate) VALUES (?, ?, ?, ?)";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			pstmt.setString(2, emailAddress);
			pstmt.setString(3, role);
			pstmt.setTimestamp(4, Timestamp.valueOf(expiration));
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return code;
	}

	/*******
	 * <p>
	 * Method: int getNumberOfInvitations()
	 * </p>
	 * 
	 * <p>
	 * Description: Determine the number of outstanding invitations in the table.
	 * </p>
	 * 
	 * @return the number of invitations in the table.
	 * 
	 */
	// Number of invitations in the database
	public int getNumberOfInvitations() {
		String query = "SELECT COUNT(*) AS count FROM InvitationCodes";
		try {
			ResultSet resultSet = statement.executeQuery(query);
			if (resultSet.next()) {
				return resultSet.getInt("count");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	/**
	 * <p>
	 * Method: String generateOneTimePassword(String userName)
	 * </p>
	 * 
	 * <p>
	 * Description: Given a user name, this method generates a one-time use password
	 * and adds it to the database. It can then be used by the assigned user to
	 * reset their password if it has been forgotten.
	 * </p>
	 * 
	 * @param user specifies the user to assign the one-time password to
	 * 
	 * @return the one-time password as a string.
	 */
	public String generateOneTimePassword(String userName) {
		// Generate an 8 character random password.
		String password = UUID.randomUUID().toString().substring(0, 8);

		// This SQL statement ensures that each user is only allowed a single
		// one-time password. If a new one is generated, it overrides the old one,
		// rendering it useless. They would need the new generated one.
		String query = "MERGE INTO OneTimePasswords (userName, password) KEY(userName) VALUES (?, ?)";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return password;
	}

	/**
	 * <p>
	 * Method: Boolean validateOneTimePassword(String userName, String password)
	 * </p>
	 * 
	 * <p>
	 * Description: Given a user name and a one-time password, this method verifies
	 * that it is the correct one-time password stored in the database. This is used
	 * during the reset password process.
	 * 
	 * @param userName specifies the user name associated with the one-time
	 *                 password.
	 * 
	 * @param password the given one-time password from the user.
	 * 
	 * @return a Boolean value indicating if the one-time password is correct.
	 */
	public Boolean validateOneTimePassword(String userName, String password) {
		String query = "SELECT * FROM OneTimePasswords WHERE userName = ? AND password = ?";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	/**
	 * <p>
	 * Method: deleteOneTimePassword(String user)
	 * </p>
	 * 
	 * <p>
	 * Description: Given a user name, this method deletes the assigned one-time
	 * password if one exists. This method will be called after a user successfully
	 * uses their one-time password to reset their password.
	 * </p>
	 * 
	 * @param user specifies which user's OTP to delete.
	 */
	public void deleteOneTimePassword(String userName) {
		String query = "SELECT COUNT(*) AS count FROM OneTimePasswords WHERE userName = ?";

		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, userName);
			ResultSet result = pstmt.executeQuery();

			if (result.next()) {
				int counter = result.getInt(1);

				if (counter > 0) {
					query = "DELETE FROM OneTimePasswords WHERE userName = ?";
					try (PreparedStatement pstmt2 = connection.prepareStatement(query)) {
						pstmt2.setString(1, userName);
						pstmt2.executeUpdate();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: boolean emailaddressHasBeenUsed(String emailAddress)
	 * </p>
	 * 
	 * <p>
	 * Description: Determine if an email address has been user to establish a user.
	 * </p>
	 * 
	 * @param emailAddress is a string that identifies a user in the table
	 * 
	 * @return true if the email address is in the table, else return false.
	 * 
	 */
	// Check to see if an email address is already in the InvitationCodes database
	public boolean emailaddressHasBeenUsed(String emailAddress) {
		String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE emailAddress = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, emailAddress);
			ResultSet rs = pstmt.executeQuery();
			System.out.println(rs);
			if (rs.next()) {
				// Mark the code as used
				return rs.getInt("count") > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: String getRoleGivenAnInvitationCode(String code)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the role associated with an invitation code.
	 * </p>
	 * 
	 * @param code is the 6 character String invitation code
	 * 
	 * @return the role for the code or an empty string.
	 * 
	 */
	// Obtain the roles associated with an invitation code.
	public String getRoleGivenAnInvitationCode(String code) {
		String query = "SELECT * FROM InvitationCodes WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("role");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}

	/*******
	 * <p>
	 * Method: String getEmailAddressUsingCode (String code )
	 * </p>
	 * 
	 * <p>
	 * Description: Get the email addressed associated with an invitation code.
	 * </p>
	 * 
	 * @param code is the 6 character String invitation code
	 * 
	 * @return the email address for the code or an empty string.
	 * 
	 */
	// For a given invitation code, return the associated email address of an empty
	// string
	public String getEmailAddressUsingCode(String code) {
		String query = "SELECT emailAddress FROM InvitationCodes WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				return rs.getString("emailAddress");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "";
	}

	/*******
	 * <p>
	 * Method: void removeInvitation(String code)
	 * </p>
	 * 
	 * <p>
	 * Description: Remove an invitation record.
	 * </p>
	 * 
	 * @param code is the 6 character String invitation code
	 * 
	 */
	// Remove an invitation using an email address
	public void removeInvitation(String code) {
		String query = "SELECT COUNT(*) AS count FROM InvitationCodes WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int counter = rs.getInt(1);
				// Only do the remove if the code is still in the invitation table
				if (counter > 0) {
					query = "DELETE FROM InvitationCodes WHERE code = ?";
					try (PreparedStatement pstmt2 = connection.prepareStatement(query)) {
						pstmt2.setString(1, code);
						pstmt2.executeUpdate();
					} catch (SQLException e) {
						e.printStackTrace();
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return;
	}

	/*******
	 * <p>
	 * Method void extendInvitationDate(String code, LocalDateTime newExpiration)
	 * </p>
	 * 
	 * <p>
	 * Description: Extend the expiration date of a new user's sign up code.
	 * </p>
	 * 
	 * @param code          is the 6 character String invitation code
	 * 
	 * @param newExpiration is the new expiration date for the user's sign up code
	 * 
	 */

	public void extendInvitationDate(String code, LocalDateTime newExpiration) {
		String query = "UPDATE InvitationCodes SET expirationDate = ? WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setTimestamp(1, Timestamp.valueOf(newExpiration));
			pstmt.setString(2, code);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method LocalDateTime getInvitationExpiration(String code)
	 * </p>
	 * 
	 * <p>
	 * Description: Return the Expiration date of the code.
	 * </p>
	 * 
	 * @param code is the 6 character String invitation code
	 * 
	 * @return Expiration date of the code
	 * 
	 */

	public LocalDateTime getInvitationExpiration(String code) {
		String query = "SELECT expirationDate FROM InvitationCodes WHERE code = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, code);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				Timestamp ts = rs.getTimestamp("expirationDate"); // convert to Timestamp from database
				return ts == null ? null : ts.toLocalDateTime(); // convert to LocalDateTime object
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: String updateUsername(String username, String newUsername)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the username of a user given that user's username and the
	 * new username.
	 * </p>
	 * 
	 * @param username    is the username of the user
	 * 
	 * @param newUsername is the new username of the user
	 * 
	 */
	// update the username
	public void updateUsername(String username, String newUsername) {
		String query = "UPDATE userDB SET username = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, newUsername);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentUsername = newUsername;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: boolean usernameUsed(String emailAddress)
	 * </p>
	 * 
	 * <p>
	 * Description: Determine if a username has been user to establish a user.
	 * </p>
	 * 
	 * @param username is a string that identifies a user in the table
	 * 
	 * @return true if the username is in the table, else return false.
	 * 
	 */
	// Check to see if an email address is already in the userDB database
	public boolean usernameUsed(String username) {
		String query = "SELECT COUNT(*) AS count FROM userDB WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			System.out.println(rs);
			if (rs.next()) {
				// Mark the code as used
				return rs.getInt("count") > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: String updatePassword(String username, String password)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the password of a user given that user's username and the
	 * new password.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @param password is the new password of the user
	 * 
	 */
	// update the password
	public void updatePassword(String username, String password) {
		String query = "UPDATE userDB SET password = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, password);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentPassword = password;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: String getFirstName(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the first name of a user given that user's username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the first name of a user given that user's username
	 * 
	 */
	// Get the First Name
	public String getFirstName(String username) {
		String query = "SELECT firstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("firstName"); // Return the first name if user exists
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: void updateFirstName(String username, String firstName)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the first name of a user given that user's username and
	 * the new first name.
	 * </p>
	 * 
	 * @param username  is the username of the user
	 * 
	 * @param firstName is the new first name for the user
	 * 
	 */
	// update the first name
	public void updateFirstName(String username, String firstName) {
		String query = "UPDATE userDB SET firstName = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, firstName);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentFirstName = firstName;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: String getMiddleName(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the middle name of a user given that user's username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the middle name of a user given that user's username
	 * 
	 */
	// get the middle name
	public String getMiddleName(String username) {
		String query = "SELECT MiddleName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("middleName"); // Return the middle name if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: void updateMiddleName(String username, String middleName)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the middle name of a user given that user's username and
	 * the new middle name.
	 * </p>
	 * 
	 * @param username   is the username of the user
	 * 
	 * @param middleName is the new middle name for the user
	 * 
	 */
	// update the middle name
	public void updateMiddleName(String username, String middleName) {
		String query = "UPDATE userDB SET middleName = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, middleName);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentMiddleName = middleName;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: String getLastName(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the last name of a user given that user's username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the last name of a user given that user's username
	 * 
	 */
	// get he last name
	public String getLastName(String username) {
		String query = "SELECT LastName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("lastName"); // Return last name role if user exists
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: void updateLastName(String username, String lastName)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the middle name of a user given that user's username and
	 * the new middle name.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @param lastName is the new last name for the user
	 * 
	 */
	// update the last name
	public void updateLastName(String username, String lastName) {
		String query = "UPDATE userDB SET lastName = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, lastName);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentLastName = lastName;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: String getPreferredFirstName(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the preferred first name of a user given that user's
	 * username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the preferred first name of a user given that user's username
	 * 
	 */
	// get the preferred first name
	public String getPreferredFirstName(String username) {
		String query = "SELECT preferredFirstName FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("firstName"); // Return the preferred first name if user exists
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: void updatePreferredFirstName(String username, String
	 * preferredFirstName)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the preferred first name of a user given that user's
	 * username and the new preferred first name.
	 * </p>
	 * 
	 * @param username           is the username of the user
	 * 
	 * @param preferredFirstName is the new preferred first name for the user
	 * 
	 */
	// update the preferred first name of the user
	public void updatePreferredFirstName(String username, String preferredFirstName) {
		String query = "UPDATE userDB SET preferredFirstName = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, preferredFirstName);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentPreferredFirstName = preferredFirstName;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: String getEmailAddress(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get the email address of a user given that user's username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return the email address of a user given that user's username
	 * 
	 */
	// get the email address
	public String getEmailAddress(String username) {
		String query = "SELECT emailAddress FROM userDB WHERE userName = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return rs.getString("emailAddress"); // Return the email address if user exists
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/*******
	 * <p>
	 * Method: void updateEmailAddress(String username, String emailAddress)
	 * </p>
	 * 
	 * <p>
	 * Description: Update the email address name of a user given that user's
	 * username and the new email address.
	 * </p>
	 * 
	 * @param username     is the username of the user
	 * 
	 * @param emailAddress is the new preferred first name for the user
	 * 
	 */
	// update the email address
	public void updateEmailAddress(String username, String emailAddress) {
		String query = "UPDATE userDB SET emailAddress = ? WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, emailAddress);
			pstmt.setString(2, username);
			pstmt.executeUpdate();
			currentEmailAddress = emailAddress;
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/*******
	 * <p>
	 * Method: boolean emailaddressUsed(String emailAddress)
	 * </p>
	 * 
	 * <p>
	 * Description: Determine if an email address has been user to establish a user.
	 * </p>
	 * 
	 * @param emailAddress is a string that identifies a user in the table
	 * 
	 * @return true if the email address is in the table, else return false.
	 * 
	 */
	// Check to see if an email address is already in the userDB database
	public boolean emailaddressUsed(String emailAddress) {
		String query = "SELECT COUNT(*) AS count FROM userDB WHERE emailAddress = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, emailAddress);
			ResultSet rs = pstmt.executeQuery();
			System.out.println(rs);
			if (rs.next()) {
				// Mark the code as used
				return rs.getInt("count") > 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: boolean getUserAccountDetails(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Get all the attributes of a user given that user's username.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @return true of the get is successful, else false
	 * 
	 */
	// get the attributes for a specified user
	public boolean getUserAccountDetails(String username) {
		String query = "SELECT * FROM userDB WHERE username = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, username);
			ResultSet rs = pstmt.executeQuery();
			rs.next();
			currentUsername = rs.getString(2);
			currentPassword = rs.getString(3);
			currentFirstName = rs.getString(4);
			currentMiddleName = rs.getString(5);
			currentLastName = rs.getString(6);
			currentPreferredFirstName = rs.getString(7);
			currentEmailAddress = rs.getString(8);
			currentAdminRole = rs.getBoolean(9);
			currentStaffRole = rs.getBoolean(10);
			currentStudentRole = rs.getBoolean(11);
			return true;
		} catch (SQLException e) {
			return false;
		}
	}

	/*******
	 * <p>
	 * Method: boolean updateUserRole(String username, String role, String value)
	 * </p>
	 * 
	 * <p>
	 * Description: Update a specified role for a specified user's and set and
	 * update all the current user attributes.
	 * </p>
	 * 
	 * @param username is the username of the user
	 * 
	 * @param role     is string that specifies the role to update
	 * 
	 * @param value    is the string that specified TRUE or FALSE for the role
	 * 
	 * @return true if the update was successful, else false
	 * 
	 */
	// Update a users role
	public boolean updateUserRole(String username, String role, String value) {
		if (role.compareTo("Admin") == 0) {
			String query = "UPDATE userDB SET adminRole = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentAdminRole = true;
				else
					currentAdminRole = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		if (role.compareTo("Staff") == 0) {
			String query = "UPDATE userDB SET staffRole = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentStaffRole = true;
				else
					currentStaffRole = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		if (role.compareTo("Student") == 0) {
			String query = "UPDATE userDB SET studentRole = ? WHERE username = ?";
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
				pstmt.setString(1, value);
				pstmt.setString(2, username);
				pstmt.executeUpdate();
				if (value.compareTo("true") == 0)
					currentStudentRole = true;
				else
					currentStudentRole = false;
				return true;
			} catch (SQLException e) {
				return false;
			}
		}
		return false;
	}

	/*******
	 * <p>
	 * Method: List<Hashmap<String, Object>> fetchAllUsers()
	 * </p>
	 * 
	 * <p>
	 * Description: Fetch every row in the userDB database and map them to id,
	 * userName, firstName, middleName, lastName, preferredFirstName, emailAddress,
	 * adminRole, staffRole, and student Role.
	 * </p>
	 * 
	 * @return list of hashmaps mapping id, userName, firstName, middleName,
	 *         lastName, preferredFirstName, emailAddress, adminRole, staffRole, and
	 *         student Role.
	 * 
	 */

	public List<Map<String, Object>> fetchAllUsers() throws SQLException {
		List<Map<String, Object>> rows = new ArrayList<>();
		String query = "SELECT userName, password, firstName, middleName, lastName, "
				+ "preferredFirstName, emailAddress, adminRole, staffRole, studentRole FROM userDB";
		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				HashMap<String, Object> row = new HashMap<>();
				row.put("userName", rs.getString("userName"));
				row.put("password", rs.getString("password"));
				row.put("firstName", rs.getString("firstName"));
				row.put("middleName", rs.getString("middleName"));
				row.put("lastName", rs.getString("lastName"));
				row.put("preferredFirstName", rs.getString("preferredFirstName"));
				row.put("emailAddress", rs.getString("emailAddress"));
				row.put("adminRole", rs.getBoolean("adminRole"));
				row.put("staffRole", rs.getBoolean("staffRole"));
				row.put("studentRole", rs.getBoolean("studentRole"));
				rows.add(row);
			}
		}
		return rows;
	}

	/*******
	 * <p>
	 * Method: List<Hashmap<String, Object>> fetchAllInvitations()
	 * </p>
	 * 
	 * <p>
	 * Description: Fetch rows in the InvitationCodes database, map it to email,
	 * invitation code, role, and expiration date columns.
	 * </p>
	 * 
	 * @return list of hashmaps mapping email, invitation code, role, and expiration
	 *         date.
	 * 
	 */

	public List<Map<String, Object>> fetchAllInvitations() throws SQLException {
		List<Map<String, Object>> rows = new ArrayList<>();
		String query = "SELECT code, emailAddress, role, expirationDate FROM InvitationCodes";
		try (PreparedStatement pstmt = connection.prepareStatement(query); ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				HashMap<String, Object> row = new HashMap<>();
				row.put("code", rs.getString("code"));
				row.put("emailAddress", rs.getString("emailAddress"));
				row.put("role", rs.getString("role"));

				Timestamp ts = rs.getTimestamp("expirationDate");
				row.put("expirationDate", ts == null ? null : ts.toLocalDateTime());

				rows.add(row);
			}
		}
		return rows;
	}

	// Attribute getters for the current user
	/*******
	 * <p>
	 * Method: String getCurrentUsername()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's username.
	 * </p>
	 * 
	 * @return the username value is returned
	 * 
	 */
	public String getCurrentUsername() {
		return currentUsername;
	};

	/*******
	 * <p>
	 * Method: String getCurrentPassword()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's password.
	 * </p>
	 * 
	 * @return the password value is returned
	 * 
	 */
	public String getCurrentPassword() {
		return currentPassword;
	};

	/*******
	 * <p>
	 * Method: String getCurrentFirstName()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's first name.
	 * </p>
	 * 
	 * @return the first name value is returned
	 * 
	 */
	public String getCurrentFirstName() {
		return currentFirstName;
	};

	/*******
	 * <p>
	 * Method: String getCurrentMiddleName()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's middle name.
	 * </p>
	 * 
	 * @return the middle name value is returned
	 * 
	 */
	public String getCurrentMiddleName() {
		return currentMiddleName;
	};

	/*******
	 * <p>
	 * Method: String getCurrentLastName()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's last name.
	 * </p>
	 * 
	 * @return the last name value is returned
	 * 
	 */
	public String getCurrentLastName() {
		return currentLastName;
	};

	/*******
	 * <p>
	 * Method: String getCurrentPreferredFirstName(
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's preferred first name.
	 * </p>
	 * 
	 * @return the preferred first name value is returned
	 * 
	 */
	public String getCurrentPreferredFirstName() {
		return currentPreferredFirstName;
	};

	/*******
	 * <p>
	 * Method: String getCurrentEmailAddress()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's email address name.
	 * </p>
	 * 
	 * @return the email address value is returned
	 * 
	 */
	public String getCurrentEmailAddress() {
		return currentEmailAddress;
	};

	/*******
	 * <p>
	 * Method: boolean getCurrentAdminRole()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's Admin role attribute.
	 * </p>
	 * 
	 * @return true if this user plays an Admin role, else false
	 * 
	 */
	public boolean getCurrentAdminRole() {
		return currentAdminRole;
	};

	/*******
	 * <p>
	 * Method: boolean getCurrentStaffRole()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's Staff role attribute.
	 * </p>
	 * 
	 * @return true if this user plays a Student role, else false
	 * 
	 */
	public boolean getCurrentStaffRole() {
		return currentStaffRole;
	};

	/*******
	 * <p>
	 * Method: boolean getCurrentStudentRole()
	 * </p>
	 * 
	 * <p>
	 * Description: Get the current user's Student role attribute.
	 * </p>
	 * 
	 * @return true if this user plays a Reviewer role, else false
	 * 
	 */
	public boolean getCurrentStudentRole() {
		return currentStudentRole;
	};

	/*******
	 * <p>
	 * Debugging method
	 * </p>
	 * 
	 * <p>
	 * Description: Debugging method that dumps the database of the console.
	 * </p>
	 * 
	 * @throws SQLException if there is an issues accessing the database.
	 * 
	 */
	// Dumps the database.
	public void dump() throws SQLException {
		String query = "SELECT * FROM userDB";
		ResultSet resultSet = statement.executeQuery(query);
		ResultSetMetaData meta = resultSet.getMetaData();
		while (resultSet.next()) {
			for (int i = 0; i < meta.getColumnCount(); i++) {
				System.out.println(meta.getColumnLabel(i + 1) + ": " + resultSet.getString(i + 1));
			}
			System.out.println();
		}
		resultSet.close();
	}

	/*******
	 * <p>
	 * Method: void closeConnection()
	 * </p>
	 * 
	 * <p>
	 * Description: Closes the database statement and connection.
	 * </p>
	 * 
	 */
	// Closes the database statement and connection.
	public void closeConnection() {
		try {
			if (statement != null)
				statement.close();
		} catch (SQLException se2) {
			se2.printStackTrace();
		}
		try {
			if (connection != null)
				connection.close();
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}
}
