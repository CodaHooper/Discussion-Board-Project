package guiAdminHome;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import java.util.Properties;

import database.Database;

/*******
 * <p>
 * Title: ModelAdminHome Class.
 * </p>
 * 
 * <p>
 * Description: The AdminHome Page Model.
 * </p>
 * 
 * @author Nikhil Ugra
 * 
 * @version 1.00 2025-09-15 Initial version
 * 
 */

public class ModelAdminHome {
	// This enables access to the application's database
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********************************************************************************************
	 * 
	 * Result attributes to be used for GUI applications where a detailed error
	 * message and a pointer to the character of the error will enhance the user
	 * experience.
	 * 
	 */
	private static int state = 0; // The current state value
	private static int nextState = 0; // The next state value
	private static boolean finalState = false; // Is this state a final state?
	private static String inputLine = ""; // The input line
	private static char currentChar; // The current character in the line
	private static int currentCharNdx; // The index of the current character
	private static boolean running; // The flag that specifies if the FSM is
									// running

	/*********************************************************************************************
	 * 
	 * Attributes used by the Email Finite State Machine to inform the user about
	 * what was and was not valid and point to the character of the error. This will
	 * enhance the user experience.
	 * 
	 */

	private static int localCharCounter = 0; // Local section of email may not exceed 64 characters
	private static int domainCharCounter = 0; // Domain section of email may not exceed 63 characters
	private static int domainPeriodCounter = 0; // There should be at least 1 period in the domain section
	private static int domainLabelCounter = 0; // There should be between 2 to 24 characters in each label
	private static boolean TLDAllLetters = false; // The last label must only contain letters

	// Private method to display the current state of the Email FSM as part of an
	// execution trace
	private static void displayDebuggingInfoEmailFSM() {
		if (currentCharNdx >= inputLine.length())
			// display the line with the current state numbers aligned
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "None");
		else
			System.out.println(((state > 99) ? " " : (state > 9) ? "  " : "   ") + state
					+ ((finalState) ? "       F   " : "           ") + "  " + currentChar + " "
					+ ((nextState > 99) ? "" : (nextState > 9) || (nextState == -1) ? "   " : "    ") + nextState
					+ "     " + (localCharCounter + domainCharCounter));
	}

	// Private method to move to the next character within the limits of the input
	// line, modified for the email finite state machine
	private static boolean atEnd;

	private static void moveToNextCharacterEmail() {
		currentCharNdx++;
		if (currentCharNdx < inputLine.length())
			currentChar = inputLine.charAt(currentCharNdx);
		else {
			atEnd = true;
			currentChar = '\0'; // make sure end of input is reached
			running = false;
		}
	}

	public static String emailRecognizerErrorMessage = ""; // The error message text
	public static String emailRecognizerInput = ""; // The input being processed
	public static int emailRecognizerIndexofError = -1; // The index of error location

	/**********
	 * This method is a mechanical transformation of the Email Finite State Machine
	 * diagram into a Java method.
	 * 
	 * @param input The input string for the Finite State Machine
	 * @return An output string that is empty if every thing is okay or it is a
	 *         String with a helpful description of the error
	 */
	public static String checkForValidEmail(String input) {
		// Reset flag
		atEnd = false;

		// Check to ensure that there is input to process
		if (input.length() <= 0) {
			emailRecognizerIndexofError = 0; // Error at first character;
			return "\nThe input is empty";
		}

		// The local variables used to perform the Finite State Machine simulation
		state = 0; // This is the FSM state number
		inputLine = input; // Save the reference to the input line as a global
		currentCharNdx = 0; // The index of the current character
		currentChar = input.charAt(0); // The current character from above indexed position

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state

		emailRecognizerInput = input; // Save a copy of the input
		running = true; // Start the loop
		nextState = -1; // There is no next state
		System.out.println("\nCurrent Final Input  Next  Date\nState   State Char  State  Size");

		// This is the place where semantic actions for a transition to the initial
		// state occur

		localCharCounter = 0; // Reset the Counter

		// The Finite State Machines continues until the end of the input is reached or
		// at some
		// state the current character does not match any valid transition to a next
		// state
		while (running) {
			// The switch statement takes the execution to the code for the current state,
			// where
			// that code sees whether or not the current character is valid to transition to
			// a
			// next state
			switch (state) {
			case 0:
				// State 0 has 1 valid transition that is addressed by an if statement.

				// The current character is checked against A-Z, a-z, 0-9, and a collection of
				// special characters.
				// If any are matched, the FSM goes to state 1.

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 1:
				// State 1 has three valid transitions,
				// 1: a A-Z, a-z, 0-9, or specific special character that transitions back to
				// state 1
				// 2: a period that transitions to state 2
				// 3: an @ character that transitions to state 3

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";

						return emailRecognizerErrorMessage;
					}
				}
				// . -> State 2
				else if (currentChar == '.') { // check for period
					nextState = 2;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";
						return emailRecognizerErrorMessage;
					}
				}

				// @ -> State 3
				else if (currentChar == '@') { // check for @
					nextState = 3;

					domainCharCounter = 0; // Reset the Counter
					domainPeriodCounter = 0; // Reset the Counter
					domainLabelCounter = 0; // Reset the Counter
					TLDAllLetters = true; // Set the Flag to True
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 2:
				// State 2 deals with a character after a period in the local section of the
				// email

				// A-Z, a-z, 0-9, or in collection of special characters -> State 1
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9') || // check for 0-9
						("!#$%&'*+/=?^_{|}~-".indexOf(currentChar) >= 0)) { // check for special character
					nextState = 1;

					// Count the character
					localCharCounter++;

					// If local size is larger than 64, the loop must stop
					if (localCharCounter > 64) {
						emailRecognizerErrorMessage = "The local-part of the Email must have no more than 64 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 3:
				// State 3 has one 1 valid transition that is addressed by an if statement.

				// The current character is checked against A-Z, a-z, 0-9
				// If any are matched, the FSM goes to state 4.

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar)) // Check if character is a digit
						TLDAllLetters = false;

					// This only occurs once, so there is no need to check for the size getting
					// too large.
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 4:
				// State 4 has three valid transitions,
				// 1: a A-Z, a-z, or 0-9 that transitions back to state 4
				// 2: a period that transitions to state 5
				// 3: a dash/hyphen that transitions to state 6

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}

				// . -> State 5
				else if (currentChar == '.') {
					nextState = 5;

					// Count the period
					domainCharCounter++;
					domainPeriodCounter++;

					// Validate label that previously ended
					if (domainLabelCounter < 2) {
						emailRecognizerErrorMessage = "Each label in the Domain of the Email must have at least 2 characters.\n";
						return emailRecognizerErrorMessage;
					}

					if (domainLabelCounter > 24) {
						emailRecognizerErrorMessage = "Each label in the Domain of the Email must have no more than 24 characters.\n";
						return emailRecognizerErrorMessage;
					}

					domainLabelCounter = 0; // Reset the Label Counter
					TLDAllLetters = true; // Reset the Flag
				}

				// - -> State 6
				else if (currentChar == '-') {
					nextState = 6;

					// Count the hyphen/dash
					domainCharCounter++;
					domainLabelCounter++;

					TLDAllLetters = false; // False since dash is not a letter
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;

				// The execution of this state is finished
				break;

			case 5:
				// State 5 deals with a character after a period in the domain section of the
				// email

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;

			case 6:
				// State 6 deals with a character after a hyphen/dash in the domain section of
				// the email

				// A-Z, a-z, or 0-9 -> State 4
				if ((currentChar >= 'A' && currentChar <= 'Z') || // Check for A-Z
						(currentChar >= 'a' && currentChar <= 'z') || // Check for a-z
						(currentChar >= '0' && currentChar <= '9')) { // check for 0-9
					nextState = 4;

					// Count the character
					domainCharCounter++;
					domainLabelCounter++;

					if (Character.isDigit(currentChar))
						TLDAllLetters = false;

					// If domain size is larger than 63, the loop must stop
					if (domainCharCounter > 63) {
						emailRecognizerErrorMessage = "The domain of the Email must have no more than 63 characters.";
						return emailRecognizerErrorMessage;
					}
				}
				// If it is none of those characters, the FSM halts
				else
					running = false;
				break;
			}

			if (running) {
				displayDebuggingInfoEmailFSM();
				// When the processing of a state has finished, the FSM proceeds to the next
				// character in the input and if there is one, it fetches that character and
				// updates the currentChar. If there is no next character the currentChar is
				// set to a blank.
				moveToNextCharacterEmail();

				// Move to the next state
				state = nextState;

				// Is the new state a final state? If so, signal this fact.
				if (state == 4)
					finalState = true;

				// Ensure that one of the cases sets this to a valid value
				nextState = -1;
			}
			// Should the FSM get here, the loop starts again

		}

		displayDebuggingInfoEmailFSM();

		System.out.println("The loop has ended.");

		// When the FSM halts, we must determine if the situation is an error or not.
		// That depends on the string of the current state of the FSM and whether or not
		// the
		// whole string has been consumed.
		// This switch directs the execution to separate code for each of the FSM states
		// and that makes it possible for this code to display a very specific error
		// message to improve the user experience.
		emailRecognizerIndexofError = currentCharNdx; // Set index of a possible error;

		// The following code is a slight variation to support just console output.
		switch (state) {
		case 0:
			// State 0 is not a final state, so we can return a very specific error message
			emailRecognizerErrorMessage = "An Email must start with a letter, digit or "
					+ "specific special character (!#$%&'*+/=?^_{|}~-).\n";
			return emailRecognizerErrorMessage;

		case 1:
			// State 1 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "Missing '@' and domain after the local part of the email.";
			} else {
				emailRecognizerErrorMessage = "An Email in the local section can only contain letters, digits"
						+ ", specific special characters (!#$%&'*+/=?^_{|}~-), or period (between characters).\n";
			}
			return emailRecognizerErrorMessage;

		case 2:
			// State 2 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "The local part of an email cannot end with a period.";
			} else {
				emailRecognizerErrorMessage = "A period must be followed by a letter, digit, or "
						+ "specific special character (e.g., !#$%&'*+/=?^_{|}~-).\n";
			}
			return emailRecognizerErrorMessage;

		case 3:
			// State 3 is not a final state, so we can return a a very specific error
			// message
			if (atEnd) {
				emailRecognizerErrorMessage = "Missing domain name after '@' in the email address.";
			} else {
				emailRecognizerErrorMessage = "The domain must start with a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;
		case 4:
			// State 4 is a final state. Check to see if the Email requirements are met.
			// if so, we must ensure the whole string has been consumed.

			if (domainLabelCounter < 2) {
				emailRecognizerErrorMessage = "Each label in the Domain of the Email must have at least 2 characters.\n";
				return emailRecognizerErrorMessage;
			}

			else if (domainLabelCounter > 24) {
				emailRecognizerErrorMessage = "Each label in the Domain of the Email must have no more than 24 characters.\n";
				return emailRecognizerErrorMessage;
			}

			else if (domainPeriodCounter < 1) {
				emailRecognizerErrorMessage = "There must be at least one period in the Domain of an Email.\n";
				return emailRecognizerErrorMessage;
			}

			else if (!TLDAllLetters) {
				emailRecognizerErrorMessage = "The final label of the Domain of an Email must solely consist of letters.\n";
				return emailRecognizerErrorMessage;
			} else if (theDatabase.emailaddressUsed(input)) {
				emailRecognizerErrorMessage = "The email address entered already exists.";
				return emailRecognizerErrorMessage;
			} else {
				// Email address is valid
				emailRecognizerIndexofError = -1;
				emailRecognizerErrorMessage = "";
				return emailRecognizerErrorMessage;
			}

		case 5:
			// State 5 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "The domain cannot end with a period.";
			} else {
				emailRecognizerErrorMessage = "A period must be followed by a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;

		case 6:
			// State 6 is not a final state, so we can return a very specific error message
			if (atEnd) {
				emailRecognizerErrorMessage = "A domain label cannot end with a hyphen.";
			} else {
				emailRecognizerErrorMessage = "A hyphen/dash must be followed by a letter or digit.\n";
			}
			return emailRecognizerErrorMessage;

		default:
			// This is for the case where we have a state that is outside of the valid
			// range.
			// This should not happen
			return "";
		}
	}

	/**********
	 * <p>
	 * 
	 * Title: sendEmail () Method.
	 * </p>
	 * 
	 * <p>
	 * Sends an email to the provided email address containing the code in which new
	 * users shall use to claim and register their account. The email shall come
	 * from `team22teamproject@gmail.com`
	 * </p>
	 * 
	 * @param code    the code which the user shall be sent to register their
	 *                account with
	 * 
	 * @param toEmail the email address to which the code shall be sent
	 */
	public static Boolean sendEmail(String code, String toEmail) {
		// These constants are for the sender and recipients
		final String senderEmail = "team22teamproject@gmail.com";
		final String appPass = "xlxzysicmkewgxde";
		final String receiverEmail = toEmail;

		// These are SMTP properties to establish a connection with an existing Gmail
		// SMTP server
		Properties props = new Properties(); // essentially a hashmap with specific purposes (e.g., string only)
		props.put("mail.smtp.auth", "true"); // SMTP authentication is required
		props.put("mail.smtp.starttls.enable", "true"); // upgrade to TLS using STARTTLS
		props.put("mail.smtp.host", "smtp.gmail.com"); // Gmail's SMTP server
		props.put("mail.smtp.port", "587"); // TLS port

		// Create a mailing session that is authenticated
		Session session = Session.getInstance(props, new Authenticator() { // session holds configuration and
																			// credentials
			@Override
			protected PasswordAuthentication getPasswordAuthentication() { // Authenticator authenticates gmail and app
																			// password whenever
				return new PasswordAuthentication(senderEmail, appPass); // the SMTP server requests for an
																			// authentication
			}
		});

		try {
			// Create the message to send in the email
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(senderEmail));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiverEmail));
			msg.setSubject("Invitation Code");
			msg.setText("Hello, here is your invitation code: " + code);

			// Send the message
			Transport.send(msg);
			return true;

		} // Handle any errors
		catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}
	}
}
