package guiCreatePost;

import java.sql.SQLException;

import database.Database;

/**
 * <p>
 * Title: ModelCreatePost Class
 * </p>
 * 
 * <p>
 * Description: The ModelCreatePost class is part of the MVC structure for the
 * Create Post feature. It currently has no implemented methods because database
 * operations are managed elsewhere in the application.
 * </p>
 * 
 * <p>
 * This class is included for completeness and future scalability, allowing for
 * potential separation of post-related data handling logic if needed later.
 * </p>
 */
public class ModelCreatePost {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: createPostDB(int threadID, String username, String title, String
	 * content)
	 * </p>
	 * 
	 * <p>
	 * Description: This method performs the database operation required to create a
	 * new post. It interacts directly with the Database to insert the new post
	 * </p>
	 * 
	 * <p>
	 * If the post creation is successful, the input fields in the view are cleared.
	 * If a database error occurs, the exception is caught and logged, and the
	 * method returns false
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn Walden.
	 * 
	 * @param threadID the thread to which the post will be added
	 * 
	 * @param username the username of the author creating the post
	 * 
	 * @param title    the title of the post entered by the user
	 * 
	 * @param content  the body text of the post entered by the user
	 * 
	 * @return true if the post was created successfully, false if not.
	 * 
	 */
	protected static boolean createPostDB(int threadID, String username, String title, String content) {
		try {
			theDatabase.createPost(threadID, null, username, title, content);
			ViewCreatePost.postTitle.clear();
			ViewCreatePost.postContent.clear();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}

	}
}
