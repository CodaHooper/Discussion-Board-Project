package guiCreatePost;

/**
 * <p>
 * Title: ControllerCreatePost Class
 * </p>
 * 
 * <p>
 * Description: The ControllerCreatePost class is part of the MVC structure for the
 * Create Post feature. Currently, it does not contain any logic or methods since
 * all functionality is handled directly within the view.
 * </p>
 * 
 * <p>
 * This class exists to maintain structural consistency within the MVC design and
 * may be implemented in future updates if controller logic becomes necessary.
 * </p>
 */
public class ControllerCreatePost {
	
	protected static void doCreatePost(entityClasses.Thread t, String username) {
		if (t != null) ViewCreatePost.openThread(t, username);
	}
	
	public static String validatePostCreation(int threadID, String title, String content, String username) {
		if (title.isEmpty()) {
			return "Post title cannot be empty.";
		} else if (content.isEmpty()) {
			return "Post body cannot be empty.";
		} else if (title.length() > 200) {
			return "Post title cannot exceed 200 characters.";
		} else if (content.length() > 10000) {
			return "Post body cannot exceed 10,000 characters.";
		} else {
			return null;
		}
	}
	
	protected static boolean actionCreatePost(int threadID, String title, String content, String username) {
		String error = validatePostCreation(threadID, title, content, username);
		
		if (error == null) {
			return ModelCreatePost.createPostDB(threadID, username, title, content);
		} else {
        	ViewCreatePost.postTitle.clear();
        	ViewCreatePost.postContent.clear();
        	ViewCreatePost.alertCreatePost.setContentText(error);
        	ViewCreatePost.alertCreatePost.showAndWait();
        	return false;
		}	
	}
}
