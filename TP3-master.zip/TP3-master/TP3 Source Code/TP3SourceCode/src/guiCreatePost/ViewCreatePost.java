package guiCreatePost;

import java.util.List;
import database.Database;
import entityClasses.Thread;
import entityClasses.ThreadsCollection;
import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

/**
 * <p>
 * Title: ViewCreatePost Class
 * </p>
 * 
 * <p>
 * Description: The ViewCreatePost class provides the graphical user interface
 * (GUI) for creating posts within existing discussion threads. It displays all
 * threads in a table and allows users to select a thread and submit a new post
 * to it.
 * </p>
 */
public class ViewCreatePost {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of threads to the title, author, and actions columns
	private static TableView<Thread> threadsTable;

	// Alert error for create post errors
	protected static Alert alertCreatePost = new Alert(Alert.AlertType.ERROR);
	protected static TextField postTitle;
	protected static TextArea postContent;

	// GUI Area 3: This area is used to enable the student to return to the student
	// home
	// screen
	protected static Button button_StudentHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewCreatePost theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theCreatePostScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayCreatePost(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View Create Post page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * threads
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayCreatePost(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewCreatePost(); // Instantiate singleton if needed
		}

		// GUI Area 2
		ThreadsCollection tc = new ThreadsCollection(theDatabase);
		List<Thread> threads = tc.getThreads();
		populateThreads(threads);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theCreatePostScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewCreatePost()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayCreateUser method.
	 * </p>
	 * 
	 */
	private ViewCreatePost() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theCreatePostScene = new Scene(theRoot, width, height);

		theCreatePostScene.getStylesheets().add(getClass().getResource("/css/guiCreatePost.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Discussions: Create Post");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		threadsTable = buildThreadsTable();

		// GUI Area 3
		setupButtonUI(button_StudentHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StudentHomeScreen.setOnAction((event) -> {
			guiStudentHome.ViewStudentHome.displayStudentHome(theStage, user);
		});
		button_StudentHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, threadsTable, button_StudentHomeScreen);
	}

	/****
	 * <p>
	 * Method: TableView<Thread> buildThreadsTable()
	 * </p>
	 * 
	 * <p>
	 * Description: Creates and configures a TableView for displaying threads. It
	 * defines columns for title, author, and actions, and sets up the table’s
	 * appearance and behavior.
	 * </p>
	 * 
	 * @return a configured TableView for Thread objects
	 */
	private TableView<Thread> buildThreadsTable() {
		TableView<Thread> table = new TableView<>();
		table.setPrefHeight(height - 100);
		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

		TableColumn<Thread, String> colTitle = new TableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getTitle()));
		colTitle.setPrefWidth(width * 0.65);

		TableColumn<Thread, String> colAuthor = new TableColumn<>("Author");
		colAuthor.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getAuthor()));
		colAuthor.setPrefWidth(width * 0.35);

		TableColumn<Thread, Thread> colActions = new TableColumn<>("Actions");
		colActions.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		colActions.setCellFactory(col -> new TableCell<Thread, Thread>() {
			private final MenuItem createPost = new MenuItem("Create Post");
			private final MenuButton menu = new MenuButton("⋮", null, createPost);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
				createPost.setOnAction(e -> {
					Thread t = getTableView().getItems().get(getIndex());
					ControllerCreatePost.doCreatePost(t, user.getUserName());
				});
			}

			@Override
			protected void updateItem(Thread item, boolean empty) {
				super.updateItem(item, empty);
				setGraphic(empty ? null : menu);
			}
		});
		colActions.setPrefWidth(width * 0.15);
		colActions.setSortable(false);

		table.getColumns().addAll(colTitle, colAuthor, colActions);
		return table;
	}

	/****
	 * <p>
	 * Method: void populateThreads(List<Thread> threads)
	 * </p>
	 * 
	 * <p>
	 * Description: Populates the threads table with a list of Thread objects. It
	 * first clears existing rows and then adds the provided threads.
	 * </p>
	 * 
	 * @param threads a list of Thread objects to display in the table
	 */
	protected static void populateThreads(java.util.List<Thread> threads) {
		if (threadsTable == null)
			return;
		threadsTable.getItems().clear();
		if (threads != null) {
			threadsTable.getItems().addAll(threads);
		}
	}

	/****
	 * <p>
	 * Method: void openThread(Thread t, String user)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to create a new post
	 * within the selected thread. The post includes a title and content input area.
	 * </p>
	 * 
	 * @param t    the Thread object where the post will be created
	 * 
	 * @param user the username of the person creating the post
	 */
	protected static void openThread(Thread t, String user) {
		Stage dialog = new Stage();
		dialog.setTitle("Create Post in: " + t.getTitle());

		Label title = new Label("Post Title:");
		postTitle = new TextField();

		Label author = new Label("Thread Author: " + t.getAuthor());

		postContent = new TextArea();
		postContent.setPromptText("Post content...");
		postContent.setWrapText(true);
		postContent.setPrefRowCount(10);

		Button sendBtn = new Button("Create Post");
		sendBtn.setOnAction(e -> {
			String pt = postTitle.getText().trim();
			String content = postContent.getText().trim();
			if (ControllerCreatePost.actionCreatePost(t.getThreadID(), pt, content, user)) {
				new Alert(Alert.AlertType.INFORMATION, "Post created.").showAndWait();
				dialog.close();
			}
		});

		Button closeBtn = new Button("Cancel");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, new Label("Thread: " + t.getTitle()), author, new Separator(), title, postTitle,
				new Label("Content:"), postContent, new Separator(), new HBox(10, sendBtn, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 325);
		dialog.setScene(scene);
		dialog.showAndWait();
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
