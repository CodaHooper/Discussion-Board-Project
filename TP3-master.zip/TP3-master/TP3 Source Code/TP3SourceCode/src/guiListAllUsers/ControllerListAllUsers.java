package guiListAllUsers;

import javafx.collections.FXCollections;
import javafx.scene.control.*;
import java.util.List;
import entityClasses.User;

/*******
 * <p>
 * Title: ControllerListDiscussions Class.
 * </p>
 * 
 * <p>
 * Description: This class serves as the controller within the MVC structure for
 * the List Discussions feature. This class manages viewing threads, posts, and
 * replies, as well as creating replies to existing discussions.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerListAllUsers {

	/**********
	 * <p>
	 * Method: showError(String message, Exception ex)
	 * </p>
	 * 
	 * <p>
	 * Description: This method displays a JavaFX error Alert dialogue box. the
	 * error message displayed is based on the exceptions passed to this method, the
	 * header is set to passed and the content is set to the error message of the
	 * exception
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param message the message to be displayed in the header of the error pop up
	 *                dialogue
	 * 
	 * @param ex      the exception raised with the message in which to pass along
	 *                to the user
	 * 
	 */
	private static void showError(String message, Exception ex) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText(null); // no header, just a body
		alert.setContentText(message + "\n" + ex.getMessage());
		alert.showAndWait();
	}

	/**********
	 * <p>
	 * Method: {@code loadInto(TableView<User> table)}
	 * </p>
	 * 
	 * <p>
	 * Description: This method verifies the data conforms to what is expected, and
	 * loads the provided users into a data type readable by the table view GUI, and
	 * sets the view to the provided data.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param table specifies the TableView that will be populated with User objects
	 * 
	 */

	public static void loadInto(TableView<User> table) {
		try {
			List<User> list = ModelListAllUsers.loadUsers();
			table.setItems(FXCollections.observableArrayList(list));
		} catch (Exception ex) {
			showError("Failed to load users", ex);
			table.getItems().clear();
		}
	}
}
