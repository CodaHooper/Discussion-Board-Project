package guiListAllUsers;

import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ViewListAllUsers {
	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of data to the username, full name, email, and roles columns
	protected static TableView<User> tableListAllUsers = new TableView<>();
	protected static TableColumn<User, String> usernameColumn = new TableColumn<>("Username");
	protected static TableColumn<User, String> fullNameColumn = new TableColumn<>("Full Name");
	protected static TableColumn<User, String> emailColumn = new TableColumn<>("Email Address");
	protected static TableColumn<User, String> rolesColumn = new TableColumn<>("Roles");

	// GUI Area 3: This area is used to enable the admin to return to the admin home
	// screen
	protected static Button button_AdminHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewListAllUsers theView; // Used to determine if instantiation of the class
	// is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theListAllUsersScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayListAllUsers(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is the single entry point from outside this package
	 * to cause the View List All Users page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * invitations
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayListAllUsers(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null)
			theView = new ViewListAllUsers(); // Instantiate singleton if needed

		// GUI Area 2
		usernameColumn.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getUserName()));
		fullNameColumn.setCellValueFactory(cd -> new ReadOnlyObjectWrapper<>(cd.getValue().getFirstName() + " "
				+ cd.getValue().getMiddleName() + " " + cd.getValue().getLastName()));
		emailColumn.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getEmailAddress()));
		rolesColumn.setCellValueFactory(
				cd -> new ReadOnlyStringWrapper(cd.getValue().getAllRoles(cd.getValue().getAdminRole(),
						cd.getValue().getStaffRole(), cd.getValue().getStudentRole())));

		if (tableListAllUsers.getColumns().isEmpty()) {
			tableListAllUsers.getColumns().addAll(usernameColumn, fullNameColumn, emailColumn, rolesColumn);
		}

		// Neatly fits columns without extra space in-between them
		usernameColumn.setPrefWidth(200);
		fullNameColumn.setPrefWidth(200);
		emailColumn.setPrefWidth(200);
		rolesColumn.setPrefWidth(200);

		tableListAllUsers.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

		ControllerListAllUsers.loadInto(tableListAllUsers);
		theStage.setTitle("List All Users Page");
		theStage.setScene(theListAllUsersScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewListAllUsers()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayListAllUsers method.
	 * </p>
	 * 
	 */
	private ViewListAllUsers() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theListAllUsersScene = new Scene(theRoot, width, height);

		theListAllUsersScene.getStylesheets().add(getClass().getResource("/css/guiListAllUsers.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("List All Users Page");
		setupLabelUI(label_PageTitle, "Arial", 28.0, width, Pos.CENTER, 0.0, 0.0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 3
		setupButtonUI(button_AdminHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_AdminHomeScreen.setOnAction((event) -> {
			guiAdminHome.ViewAdminHome.displayAdminHome(theStage, user);
		});
		button_AdminHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, tableListAllUsers, button_AdminHomeScreen);
		VBox.setVgrow(tableListAllUsers, Priority.ALWAYS);
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}