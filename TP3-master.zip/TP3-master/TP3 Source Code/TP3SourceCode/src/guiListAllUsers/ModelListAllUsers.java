package guiListAllUsers;

import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import database.Database;
import entityClasses.User;

/***************
 * <p>
 * Title: ModelListAllUsers Class
 * </p>
 * 
 * <p>
 * Description: The ModelListAllUsers class provides the data-handling logic for
 * the List All Users feature. It represents the Model component in the MVC
 * architecture and is responsible for retrieving user data from the database.
 * </p>
 * 
 * <p>
 * This class does not perform any controller or interface functions—it simply
 * loads data. It is designed to maintain a clean separation between the model
 * and the view, ensuring scalability and maintainability for future extensions
 * such as pagination, filtering, or caching of user data.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ModelListAllUsers {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: loadUsers()
	 * </p>
	 * 
	 * <p>
	 * Description: Loads all users from the database and puts them in a list. It
	 * retrieves a list of user data maps and then creates the corresponding User
	 * object for each record.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @return A {@code List<User> } containing all user objects retrieved from the
	 *         database.
	 * 
	 * @throws SQLException If a database access error occurs during data retrieval.
	 */
	public static List<User> loadUsers() throws SQLException {
		List<User> users = new ArrayList<>();
		List<Map<String, Object>> userRows = theDatabase.fetchAllUsers();
		for (Map<String, Object> row : userRows) {
			User user = new User((String) row.get("userName"), (String) row.get("password"),
					(String) row.get("firstName"), (String) row.get("middleName"), (String) row.get("lastName"),
					(String) row.get("preferredFirstName"), (String) row.get("emailAddress"),
					(boolean) row.get("adminRole"), (boolean) row.get("staffRole"), (boolean) row.get("studentRole"));
			users.add(user);
		}
		return users;
	}
}
