package guiRubric;

import entityClasses.EvalParameter;

public class ControllerRubric {
	/**********
	 * <p>
	 * Method: openParameterButton(EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: Opens the selected eval parameter in a read-only dialog 
	 * if it is not null.
	 * </p>
	 *
	 * @param ep The EvalParameter object to open
	 */
	protected static void openParameterButton(EvalParameter ep) {
		if (ep != null)
			ViewRubric.openEvalParameter(ep);
	}
}
