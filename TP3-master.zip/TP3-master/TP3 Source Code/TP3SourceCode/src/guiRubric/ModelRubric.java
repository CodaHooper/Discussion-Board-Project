package guiRubric;

public class ModelRubric {

}
