package guiListThreads;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import database.Database;
import entityClasses.Post;
import entityClasses.Reply;
import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;

/**
 * <p>
 * Title: ModelListThreads Class
 * </p>
 *
 * <p>
 * Description: This class is part of the MVC structure for the List Threads
 * feature. It handles database interactions for thread deletion and updating. *
 * </p>
 *
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ModelListThreads {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: getTopLevelPosts(int threadID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This method retrieves all top-level posts associated with a
	 * given thread. It calls the getTopLevelPostsByThread method from the database
	 * and returns a list of Post objects for the specified user and thread.
	 * </p>
	 * 
	 * @param threadID Specifies the unique identifier of the thread.
	 * @param username Specifies the username of the user requesting the posts.
	 * 
	 * @return A List<Post> containing all top-level posts within the given thread.
	 */
	protected static List<Post> getTopLevelPosts(int threadID, String username) {
		List<Post> topLevelPosts = new ArrayList<Post>();
		try {
			topLevelPosts = theDatabase.getTopLevelPostsByThread(threadID, username);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return topLevelPosts;
	}

	/**********
	 * <p>
	 * Method: getPostReplies(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies for a given post. If a database exception
	 * occurs, returns an empty list.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param postID   The id of the parent post.
	 * @param username The username of the user requesting replies.
	 * 
	 * @return A List<Reply> containing all direct replies to the specified post.
	 */
	protected static List<Reply> getPostReplies(int postID, String username) {
		try {
			return theDatabase.getRepliesForPost(postID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}

	/**********
	 * <p>
	 * Method: getReplyReplies(int replyID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies to a given reply. If any database
	 * exception occurs, returns an empty list.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param replyID  The unique identifier of the parent reply.
	 * @param username The user requesting replies.
	 * 
	 * @return A List<Reply> containing all direct replies to the specified reply.
	 */
	protected static List<Reply> getReplyReplies(int replyID, String username) {
		try {
			return theDatabase.getRepliesForPost(replyID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}

	/**
	 * <p>
	 * Method: protected static String getThreadTitle(int threadID)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies to a given reply. If any database
	 * exception occurs, returns an empty list.
	 * </p>
	 * 
	 * 
	 * @param threadID
	 * @return
	 */
	protected static String getThreadTitle(int threadID) {
		return (String) (theDatabase.readThread(threadID)).get("title");
	}

	/**
	 * <p>
	 * Method: deleteThreadDB(Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Deletes the thread from the database. If an SQL exception
	 * occurs, print stack trace and return false.
	 * </p>
	 *
	 * @param t The Thread to delete
	 * @return true if the thread was successfully deleted, otherwise false.
	 */
	protected static boolean deleteThreadDB(entityClasses.Thread t) {
		try {
			theDatabase.deleteThread(t.getThreadID());
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**
	 * <p>
	 * Method: editThreadDB(String title, String content, Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Updates the title and content of the specified thread in the
	 * database. If an SQL exception occurs, print stack trace and return false.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param title   The new title of the thread
	 * @param content The new content of the thread
	 * @param t       The thread to update
	 * @return true if the thread was successfully updated, otherwise false
	 */
	protected static boolean editThreadDB(String title, String content, entityClasses.Thread t) {
		try {
			theDatabase.updateThread(t.getThreadID(), title, content);
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**********
	 * <p>
	 * Method: setReadDB(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Marks a post or reply as read for the given user.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param postID   The ID of the post or reply to mark as read.
	 * @param username The user reading the post or reply
	 */
	protected static void setReadDB(int postID, String username) {
		theDatabase.setReadPost(postID, username);
	}

	/**********
	 * <p>
	 * 
	 * Title: Boolean sendEmail(String message, String toEmail, String fromEmail)
	 * Method.
	 * </p>
	 * 
	 * <p>
	 * Sends an email to the provided email address containing the code in which new
	 * users shall use to claim and register their account. The email shall come
	 * from `team22teamproject@gmail.com`
	 * </p>
	 * 
	 * @param message   the message which is to be sent to the user
	 * @param toEmail   the email which the message is to be sent
	 * @param fromEmail the email with which to use to send the message to the user
	 * 
	 * @param toEmail   the email address to which the code shall be sent
	 */
	public static Boolean sendEmail(String message, String toEmail, String fromEmail) {
		// These constants are for the sender and recipients
		final String senderEmail = "team22teamproject@gmail.com";
		final String appPass = "xlxzysicmkewgxde";
		final String receiverEmail = toEmail;

		// These are SMTP properties to establish a connection with an existing Gmail
		// SMTP server
		Properties props = new Properties(); // essentially a hashmap with specific purposes (e.g., string only)
		props.put("mail.smtp.auth", "true"); // SMTP authentication is required
		props.put("mail.smtp.starttls.enable", "true"); // upgrade to TLS using STARTTLS
		props.put("mail.smtp.host", "smtp.gmail.com"); // Gmail's SMTP server
		props.put("mail.smtp.port", "587"); // TLS port

		// Create a mailing session that is authenticated
		Session session = Session.getInstance(props, new Authenticator() { // session holds configuration and
																			// credentials
			@Override
			protected PasswordAuthentication getPasswordAuthentication() { // Authenticator authenticates gmail and app
																			// password whenever
				return new PasswordAuthentication(senderEmail, appPass); // the SMTP server requests for an
																			// authentication
			}
		});

		try {
			// Create the message to send in the email
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(senderEmail));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiverEmail));
			msg.setSubject("Private Feedback");
			msg.setText(message + "\n\n From: " + fromEmail);

			// Send the message
			Transport.send(msg);
			return true;

		} // Handle any errors
		catch (MessagingException e) {
			e.printStackTrace();
			return false;
		}
	}
}
