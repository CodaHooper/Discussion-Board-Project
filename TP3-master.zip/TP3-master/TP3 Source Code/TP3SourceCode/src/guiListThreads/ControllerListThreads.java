package guiListThreads;

import javafx.scene.control.ButtonType;

/**
 * <p>
 * Title: ControllerListThreads Class
 * </p>
 *
 * <p>
 * Description: This class is part of the MVC structure for the List Threads
 * feature. It manages user interactions and controls reading, updating, and
 * deleting threads. It validates inputs and update the database.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerListThreads {

	/**********
	 * <p>
	 * Method: openThreadButton(Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Opens the selected thread in a read-only dialog if it is not
	 * null.
	 * </p>
	 *
	 * @param t The Thread object to open
	 */
	protected static void openThreadButton(entityClasses.Thread t) {
		if (t != null)
			ViewListThreads.openThread(t);
	}

	/**********
	 * <p>
	 * Method: editThreadButton(Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Opens the update dialog for the specified thread if it is not
	 * null.
	 * </p>
	 *
	 * @param t The Thread object to edit
	 */
	protected static void editThreadButton(entityClasses.Thread t) {
		if (t != null)
			ViewListThreads.openEditThread(t);
	}

	protected static boolean deleteThreadButton(entityClasses.Thread t) {
		if (t == null)
			return false;

		ViewListThreads.confirm.setContentText("Are you sure you want to delete this thread?");
		ViewListThreads.confirm.setHeaderText("Confirm Delete");
		if (ViewListThreads.confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
			return ModelListThreads.deleteThreadDB(t);
		}
		return false;
	}

	/**********
	 * <p>
	 * Method: deleteThreadButton(Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Prompts the user to confirm deletion of a thread. If the user
	 * confirms, the thread is deleted.
	 * </p>
	 *
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param t The Thread object to delete
	 * @return true if the thread was successfully deleted, otherwise false
	 */
	protected static boolean editThreadLogic(String title, String content, entityClasses.Thread t) {
		if (title.isEmpty()) { // Thread title cannot be empty.
			ViewListThreads.threadTitle.setText(t.getTitle());
			ViewListThreads.threadContent.setText(t.getContent());
			ViewListThreads.alertEditError.setContentText("Thread title cannot be empty.");
			ViewListThreads.alertEditError.showAndWait();
			return false;
		} else if (content.isEmpty()) { // Thread body cannot be empty.
			ViewListThreads.threadTitle.setText(t.getTitle());
			ViewListThreads.threadContent.setText(t.getContent());
			ViewListThreads.alertEditError.setContentText("Thread body cannot be empty.");
			ViewListThreads.alertEditError.showAndWait();
			return false;
		} else if (title.length() > 200) { // Thread title cannot exceed 200 characters.
			ViewListThreads.threadTitle.setText(t.getTitle());
			ViewListThreads.threadContent.setText(t.getContent());
			ViewListThreads.alertEditError.setContentText("Thread title cannot exceed 200 characters.");
			ViewListThreads.alertEditError.showAndWait();
			return false;
		} else if (content.length() > 10000) { // Thread body cannot exceed 10,000 characters.
			ViewListThreads.threadTitle.setText(t.getTitle());
			ViewListThreads.threadContent.setText(t.getContent());
			ViewListThreads.alertEditError.setContentText("Thread body cannot exceed 10,000 characters.");
			ViewListThreads.alertEditError.showAndWait();
			return false;
		} else {
			return ModelListThreads.editThreadDB(title, content, t);
		}
	}
	
	/**********
	 * <p>
	 * Method: openObject(Object o)
	 * </p>
	 * 
	 * <p>
	 * Description: This method determines the type of the object selected by the
	 * user. Depending on the type, this method will pass the cast and pass the
	 * object to the appropriate view.
	 * </p>
	 * 
	 * <p>
	 * Depending on whether the selected object is a Thread, Post, or Reply, the
	 * method calls a different display function from ViewListThreads
	 * </p>
	 *
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param the object selected by the user, which can be an instance of a Thread,
	 *            Post, or Reply
	 * 
	 */
	protected static void openObject(Object o) {
		if (o instanceof entityClasses.Thread t)
			ViewListThreads.openThread(t);
		else if (o instanceof entityClasses.Post p)
			ViewListThreads.openPost(p);
		else if (o instanceof entityClasses.Reply r)
			ViewListThreads.openReply(r);
	}
}
