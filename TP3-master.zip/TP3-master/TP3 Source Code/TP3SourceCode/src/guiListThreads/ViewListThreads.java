package guiListThreads;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import database.Database;
import entityClasses.Post;
import entityClasses.Reply;
import entityClasses.Thread;
import entityClasses.ThreadsCollection;
import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ViewListThreads {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;
	
	// Placeholder for mark reply branches that aren't loaded yet
	private static final Object LAZY_PLACEHOLDER = new Object();

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of threads, posts, and replies using a treetableview
	private static TreeTableView<Object> threadsTree;
	protected static TreeTableView<Object> tree;

	// Alerts for deletion confirmation and edit errors
	protected static Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
	protected static Alert alertEditError = new Alert(Alert.AlertType.ERROR);

	// Edit attributes
	protected static TextField threadTitle;
	protected static TextArea threadContent;

	// GUI Area 3: This area is used to enable the staff member to return to the
	// staf home
	// screen
	protected static Button button_StaffHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewListThreads theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theListThreadsScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayListThreads(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View List Threads page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * threads
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayListThreads(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewListThreads(); // Instantiate singleton if needed
		}

		// GUI Area 2
		ThreadsCollection tc = new ThreadsCollection(theDatabase);
		List<Thread> threads = tc.getThreads();
		populateThreads(threads);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theListThreadsScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewListThreads()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayStaffThreads method.
	 * </p>
	 * 
	 */
	private ViewListThreads() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theListThreadsScene = new Scene(theRoot, width, height);

		theListThreadsScene.getStylesheets().add(getClass().getResource("/css/guiListThreads.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Discussions: All Threads");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		threadsTree = buildThreadsTree();

		// GUI Area 3
		setupButtonUI(button_StaffHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StaffHomeScreen.setOnAction((event) -> {
			guiStaffHome.ViewStaffHome.displayStaffHome(theStage, user);
		});
		button_StaffHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, threadsTree, button_StaffHomeScreen);
	}

	/****
	 * <p>
	 * Method: TableView<Post> buildThreadsTable()
	 * </p>
	 * 
	 * <p>
	 * Description: Creates and configures a TableView for displaying threads. It
	 * defines columns for title, author, and actions, and sets up the table’s
	 * appearance and behavior.
	 * </p>
	 * 
	 * @return a configured TableView for Thread objects
	 */
	private TreeTableView<Object> buildThreadsTree() {
		TreeTableColumn<Object, String> colTitle = new TreeTableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> {
			Object row = cd.getValue().getValue();
			String title;
			if (row instanceof Thread t)
				title = t.getTitle();
			else if (row instanceof Post p)
				title = p.getTitle();
			else if (row instanceof Reply r)
				title = r.getTitle();
			else
				title = "";
			return new ReadOnlyStringWrapper(title == null || title.isBlank() ? "(untitled)" : title);
		});
		colTitle.setPrefWidth(width * 0.50);

		TreeTableColumn<Object, String> colAuthor = new TreeTableColumn<>("Author");
		colAuthor.setCellValueFactory(cd -> {
			Object row = cd.getValue().getValue();
			String author;
			if (row instanceof Thread t)
				author = t.getAuthor();
			else if (row instanceof Post p)
				author = p.getAuthor();
			else if (row instanceof Reply r)
				author = r.getAuthor();
			else
				author = "";
			return new ReadOnlyStringWrapper(author);
		});
		colAuthor.setPrefWidth(width * 0.16);
		
		TreeTableColumn<Object, String> colReplyCount = new TreeTableColumn<>("Replies");
		colReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyCount()); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colReplyCount.setPrefWidth(width * 0.07);
		
		TreeTableColumn<Object, String> colUnreadReplyCount = new TreeTableColumn<>("Unread Replies");
		colUnreadReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyUnread(theDatabase, user.getUserName())); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colUnreadReplyCount.setPrefWidth(width * 0.10);
		
		TreeTableColumn<Object, String> colRead = new TreeTableColumn<>("Read");
		colRead.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = p.getIsRead(); // only meaningful for posts/replies
			else if (o instanceof Reply r)
				v = r.getIsRead();
			return new ReadOnlyStringWrapper(v);
		});
		colRead.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, Object> colActions = new TreeTableColumn<>("Actions");
		colActions.setCellValueFactory(
				param -> new ReadOnlyObjectWrapper<>(param.getValue() == null ? null : param.getValue().getValue()));
		colActions.setCellFactory(col -> new TreeTableCell<Object, Object>() {
			private final MenuItem openItem = new MenuItem("Open");
			private final MenuItem editItem = new MenuItem("Edit Thread");
			private final MenuItem deleteItem = new MenuItem("Delete Thread");
			private final MenuItem review = new MenuItem("Review");
			private final MenuItem viewScoreItem = new MenuItem("View Score");
			private final MenuItem messageItem = new MenuItem("Send Message");
			private final MenuButton menu = new MenuButton("⋮", null, openItem, editItem, deleteItem, review, viewScoreItem);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
				
				openItem.setOnAction(e -> {
					Object o = getItem();
					ControllerListThreads.openObject(o);
				});
				
				editItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Thread t) {
						ControllerListThreads.editThreadButton(t);
					}
				});

				deleteItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Thread t) {
						if (ControllerListThreads.deleteThreadButton(t)) {
							TreeItem<Object> currentItem = getTreeTableView().getTreeItem(getIndex());
							getTreeTableView().getRoot().getChildren().remove(currentItem);
							new Alert(Alert.AlertType.INFORMATION, "Thread deleted.").showAndWait();
						} else
							new Alert(Alert.AlertType.ERROR, "Failed to delete thread.").showAndWait();
					}
				});
				
				review.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) guiRubric.ViewRubric.displayRubric(theStage, user, p.getAuthor(), p.getPostID());
					if (o instanceof Reply r) guiRubric.ViewRubric.displayRubric(theStage, user, r.getAuthor(), r.getPostID());
				});
				
				viewScoreItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) showScoreDialog(p.getAuthor(), p.getPostID());
					if (o instanceof Reply r) showScoreDialog(r.getAuthor(), r.getPostID());
				});
				
				messageItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) sendMessage(p.getAuthor(), theDatabase.getEmailAddress(p.getAuthor()));
				});
			}

			@Override
			protected void updateItem(Object item, boolean empty) {
				super.updateItem(item, empty);
				if (empty) {
					setGraphic(empty ? null : menu);
					return;
				}

				Object v = getTreeTableView().getTreeItem(getIndex()).getValue();

				// reset menu items per row
				menu.getItems().setAll(openItem);
				if (v instanceof Thread) {
					menu.getItems().addAll(editItem, deleteItem);
				}
				if (v instanceof Post || v instanceof Reply) {
					menu.getItems().addAll(review);
					menu.getItems().addAll(viewScoreItem);
					menu.getItems().addAll(messageItem);
				}
				
				setGraphic(menu);
			}
		});
		colActions.setPrefWidth(width * 0.10);
		colActions.setSortable(false);

		TreeItem<Object> root = new TreeItem<>();
		root.setExpanded(true);
		
		tree = new TreeTableView<>(root);
		tree.getColumns().addAll(colTitle, colAuthor, colReplyCount, colUnreadReplyCount, colRead, colActions);
		tree.setShowRoot(false);
		tree.setColumnResizePolicy(TreeTableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
		tree.setPrefHeight(height - 100);
		return tree;
	}

	/****
	 * <p>
	 * Method: void populateThreads(List<Thread> threads)
	 * </p>
	 *
	 * <p>
	 * Description: Populates the root of the tree with thread rows and adds each
	 * thread’s top-level posts. Reply children are attached lazily.
	 * </p>
	 *
	 * @param threads the list of Thread objects to render at the root level
	 */
	protected static void populateThreads(List<Thread> threads) {
		if (threadsTree == null)
			return;
		TreeItem<Object> root = threadsTree.getRoot();
		root.getChildren().clear();

		if (threads == null)
			return;

		for (Thread t : threads) {
			TreeItem<Object> threadItem = new TreeItem<>(t);
			root.getChildren().add(threadItem);

			List<Post> topLevelPosts = new ArrayList<Post>();
			topLevelPosts = ModelListThreads.getTopLevelPosts(t.getThreadID(), user.getUserName());
			if (topLevelPosts != null) {
				for (Post p : topLevelPosts) {
					TreeItem<Object> postItem = new TreeItem<>(p);
					threadItem.getChildren().add(postItem);
					lazyReplyForPost(postItem, p.getPostID());
				}
			}
		}
	}
	
	/****
	 * <p>
	 * Method: void lazyReplyForPost(TreeItem<Object> postItem, int postId)
	 * </p>
	 *
	 * <p>
	 * Description: Attaches a lazy loader to a post row. When the post node is
	 * expanded, this method fetches its direct replies and inserts them as
	 * children. Each reply child is itself wired for further lazy loading.
	 * </p>
	 *
	 * @param postItem the TreeItem representing the parent post in the tree
	 * 
	 * @param postId   the database ID of the parent post whose replies are loaded
	 */
	protected static void lazyReplyForPost(TreeItem<Object> postItem, int postId) {
		postItem.getChildren().setAll(new TreeItem<>(LAZY_PLACEHOLDER));
		postItem.expandedProperty().addListener((obs, was, is) -> {
			if (!is)
				return;
			if (postItem.getChildren().size() == 1 && postItem.getChildren().get(0).getValue() == LAZY_PLACEHOLDER) {
				postItem.getChildren().clear();
				List<Reply> replies;
				replies = ModelListThreads.getPostReplies(postId, user.getUserName());
				for (Reply r : replies) {
					TreeItem<Object> replyItem = new TreeItem<>(r);
					postItem.getChildren().add(replyItem);
					lazyReplyForReply(replyItem, r.getPostID());
				}
			}
		});
	}
	
	/****
	 * <p>
	 * Method: void lazyReplyForReply(TreeItem<Object> replyItem, int replyId)
	 * </p>
	 *
	 * <p>
	 * Description: Attaches a lazy loader to a reply row. When expanded, it loads
	 * the reply’s direct children (nested replies) and adds them to the tree,
	 * enabling unbounded nesting.
	 * </p>
	 *
	 * @param replyItem the TreeItem representing the parent reply in the tree
	 * 
	 * @param replyId   the database ID of the reply whose child replies are loaded
	 */
	protected static void lazyReplyForReply(TreeItem<Object> replyItem, int replyId) {
		replyItem.getChildren().setAll(new TreeItem<>(LAZY_PLACEHOLDER));
		replyItem.expandedProperty().addListener((obs, was, is) -> {
			if (!is)
				return;
			if (replyItem.getChildren().size() == 1 && replyItem.getChildren().get(0).getValue() == LAZY_PLACEHOLDER) {
				replyItem.getChildren().clear();
				List<Reply> replies;
				replies = ModelListThreads.getReplyReplies(replyId, user.getUserName());
				for (Reply r : replies) {
					TreeItem<Object> child = new TreeItem<>(r);
					replyItem.getChildren().add(child);
					lazyReplyForReply(child, r.getPostID());
				}
			}
		});
	}

	/****
	 * <p>
	 * Method: void openThread(Thread t)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a thread. The
	 * thread includes a title and content input area.
	 * </p>
	 * 
	 * @param t the Thread object where the thread will be created
	 * 
	 */
	protected static void openThread(Thread t) {
		Stage dialog = new Stage();
		dialog.setTitle("Thread");
		Label title = new Label(t.getTitle() == null || t.getTitle().isBlank() ? "(untitled)" : t.getTitle());
		Label author = new Label("By: " + t.getAuthor());

		TextArea content = new TextArea(t.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}
	
	/****
	 * <p>
	 * Method: void openPost(Post p)
	 * </p>
	 *
	 * <p>
	 * Description: Opens a dialog showing a post (title, author, content).
	 * </p>
	 *
	 * @param p the Post to display.
	 */
	protected static void openPost(Post p) {
		Stage dialog = new Stage();
		dialog.setTitle("Post");

		Label titleLabel = new Label(p.getTitle() == null || p.getTitle().isBlank() ? "(untitled)" : p.getTitle());
		Label authorLabel = new Label("By: " + p.getAuthor());

		TextArea content = new TextArea(p.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(10);
		
		ModelListThreads.setReadDB(p.getPostID(), user.getUserName());

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, titleLabel, authorLabel, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
		};
		
		/****
		 * <p>
		 * Method: void openReply(Reply r)
		 * </p>
		 *
		 * <p>
		 * Description: Opens a dialog showing a reply (author, content).
		 * </p>
		 *
		 * @param r the Reply to display.
		 */
		protected static void openReply(Reply r) {
			Stage dialog = new Stage();
			dialog.setTitle("Reply");

			Label by = new Label("By: " + r.getAuthor());
			TextArea content = new TextArea(r.getContent());
			content.setEditable(false);
			content.setWrapText(true);
			content.setPrefRowCount(10);
			
			ModelListThreads.setReadDB(r.getPostID(), user.getUserName());

			Button closeBtn = new Button("Close");
			closeBtn.setOnAction(e -> dialog.close());

			VBox layout = new VBox(10, by, new Separator(), content, new HBox(10, closeBtn));
			layout.setPadding(new Insets(15));
			layout.setAlignment(Pos.CENTER_LEFT);

			Scene scene = new Scene(layout, 600, 350);
			dialog.setScene(scene);
			dialog.initOwner(theStage);
			dialog.showAndWait();
		}

	/****
	 * <p>
	 * Method: void openEditThread(Thread t)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to edit a thread's
	 * title and content.
	 * </p>
	 * 
	 * @param t the Thread object where the post will be created
	 * 
	 */
	protected static void openEditThread(Thread t) {
		Stage dialog = new Stage();
		dialog.setTitle("Edit Thread");

		Label titleLabel = new Label("Title:");
		threadTitle = new TextField(t.getTitle());

		Label contentLabel = new Label("Content:");
		threadContent = new TextArea(t.getContent());
		threadContent.setWrapText(true);
		threadContent.setPrefRowCount(12);

		Button saveBtn = new Button("Save");
		saveBtn.setOnAction(e -> {
			String title = threadTitle.getText().trim();
			String content = threadContent.getText().trim();
			if (ControllerListThreads.editThreadLogic(title, content, t)) {
				// Update the in-memory object so the table shows the changes
				t.setTitle(title);
				t.setContent(content);
				// Refresh tree
				threadsTree.refresh();
				new Alert(Alert.AlertType.INFORMATION, "Thread updated.").showAndWait();
				dialog.close();
			} else
				new Alert(Alert.AlertType.ERROR, "Failed to update thread.").showAndWait();
		});

		Button cancelBtn = new Button("Cancel");
		cancelBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, titleLabel, threadTitle, contentLabel, threadContent,
				new HBox(10, saveBtn, cancelBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 500);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}
	
	/****
	 * <p>
	 * Method: showScoreDialog(String author, int postID)
	 * </p>
	 * 
	 * <p>
	 * Description: Displays the grade a post received.
	 * </p>
	 */
	private static void showScoreDialog(String author, int postID) {
	    try {
	        Map<String, Object> score = theDatabase.readScore(author, postID);
	        
	        String msg;
	        if (score == null) {
	            msg = "No score has been recorded yet for this post.";
	        } else {
	        	Timestamp ts = (Timestamp) score.get("gradedAt");
		        LocalDateTime dt = ts.toLocalDateTime();
		        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy 'at' hh:mm a");
		        String formattedTime = dt.format(formatter);
		        
	            msg = "Current score for " + author +
	                  " on this post: " + score.get("score") + " / 5\n\n" +
	                  "Graded by " + score.get("evaluator") + "\n" + 
	                  "On " + formattedTime;
	        }

	        Alert a = new Alert(Alert.AlertType.INFORMATION);
	        a.setHeaderText("Post Score");
	        a.setContentText(msg);
	        a.showAndWait();

	    } catch (Exception e) {
	        Alert err = new Alert(Alert.AlertType.ERROR);
	        err.setHeaderText("Error");
	        err.setContentText("Failed to read score: " + e.getMessage());
	        err.showAndWait();
	    }
	}
	
	/****
	 * <p>
	 * Method: sendMessage(String author, String email)
	 * </p>
	 * 
	 * <p>
	 * Description: Sends a private message to a student from their post.
	 * </p>
	 */
	private static void sendMessage(String author, String email) {
		Stage dialog = new Stage();
		dialog.setTitle("Private Message");

		TextArea message = new TextArea();
		message.setPromptText("...");
		message.setWrapText(true);
		message.setPrefRowCount(4);

		Button sendBtn = new Button("Send");
		sendBtn.setOnAction(e -> {
			String content = message.getText().trim();
			if (ModelListThreads.sendEmail(content, email, user.getEmailAddress())) {
				Alert a = new Alert(Alert.AlertType.INFORMATION);
				a.setHeaderText("Private Message");
				a.setContentText("Private message has been successfully sent!");
				a.showAndWait();
				dialog.close();
			}
		});

		Button closeBtn = new Button("Cancel");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, new Label("Private Message:"), message, new Separator(),
				new HBox(10, sendBtn, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 125);
		dialog.setScene(scene);
		dialog.showAndWait();
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
