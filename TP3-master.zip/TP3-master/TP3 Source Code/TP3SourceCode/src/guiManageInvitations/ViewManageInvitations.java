package guiManageInvitations;

import entityClasses.Invitation;
import entityClasses.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.time.LocalDateTime;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.property.ReadOnlyObjectWrapper;

public class ViewManageInvitations {
	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of data to the email, code, role, and status columns
	protected static TableView<Invitation> tableInvitationData = new TableView<>();
	protected static TableColumn<Invitation, String> emailColumn = new TableColumn<>("Email");
	protected static TableColumn<Invitation, String> codeColumn = new TableColumn<>("Code");
	protected static TableColumn<Invitation, String> roleColumn = new TableColumn<>("Role");
	protected static TableColumn<Invitation, LocalDateTime> expirationColumn = new TableColumn<>("Expiration");
	protected static TableColumn<Invitation, Void> actionColumn = new TableColumn<>("");

	// GUI Area 3: This area is used to enable the admin to return to the admin home
	// screen
	protected static Button button_AdminHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewManageInvitations theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theManageInvitationsScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayManageInvitations(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View Manage Invitations page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GIUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * invitations
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayManageInvitations(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewManageInvitations(); // Instantiate singleton if needed
		}

		// GUI Area 2
		emailColumn.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getEmailAddress()));
		codeColumn.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getCode()));
		roleColumn.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getRole()));
		expirationColumn.setCellValueFactory(cd -> new ReadOnlyObjectWrapper<>(cd.getValue().getExpirationDate()));
		actionColumn.setCellFactory(col -> new TableCell<Invitation, Void>() {

			private final MenuButton menu = new MenuButton("⋮");

			{ // initializer: runs once per cell instance
				MenuItem delete = new MenuItem("Delete");
				MenuItem change = new MenuItem("Change Deadline");
				menu.getItems().addAll(delete, change);

				delete.setOnAction(e -> {
					Invitation inv = getTableView().getItems().get(getIndex());
					ControllerManageInvitations.handleDelete(inv, tableInvitationData);
				});
				change.setOnAction(e -> {
					Invitation inv = getTableView().getItems().get(getIndex());
					ControllerManageInvitations.handleExtend(inv, theStage, tableInvitationData);
				});
			}

			@Override
			protected void updateItem(Void item, boolean empty) {
				super.updateItem(item, empty);
				setGraphic(empty ? null : menu);
			}
		});

		if (tableInvitationData.getColumns().isEmpty()) {
			tableInvitationData.getColumns().addAll(emailColumn, codeColumn, roleColumn, expirationColumn,
					actionColumn);
		}

		// Neatly fits columns without extra space in-between them
		emailColumn.setPrefWidth(200);
		codeColumn.setPrefWidth(200);
		roleColumn.setPrefWidth(200);
		expirationColumn.setPrefWidth(200);

		actionColumn.setPrefWidth(60);
		actionColumn.setMaxWidth(60);
		actionColumn.setMinWidth(60);
		tableInvitationData.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);

		ControllerManageInvitations.loadInto(tableInvitationData);
		theStage.setTitle("CSE 360 TP1 | Team 22");
		theStage.setScene(theManageInvitationsScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewManageInvitations()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayManageInvitations method.
	 * </p>
	 * 
	 */
	private ViewManageInvitations() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theManageInvitationsScene = new Scene(theRoot, width, height);

		theManageInvitationsScene.getStylesheets()
				.add(getClass().getResource("/css/guiManageInvitations.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Invitations");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 3
		setupButtonUI(button_AdminHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_AdminHomeScreen.setOnAction((event) -> {
			guiAdminHome.ViewAdminHome.displayAdminHome(theStage, user);
		});
		button_AdminHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, tableInvitationData, button_AdminHomeScreen);
		VBox.setVgrow(tableInvitationData, Priority.ALWAYS);
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
