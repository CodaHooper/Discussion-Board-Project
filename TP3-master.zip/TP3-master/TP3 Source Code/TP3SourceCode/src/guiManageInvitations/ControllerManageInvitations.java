package guiManageInvitations;

import javafx.collections.FXCollections;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import entityClasses.Invitation;

public class ControllerManageInvitations {

	/**********
	 * <p>
	 * Method: showError(String message, Exception ex)
	 * </p>
	 * 
	 * <p>
	 * Description: This method displays a JavaFX error Alert dialogue box. the
	 * error message displayed is based on the exceptions passed to this method, the
	 * header is set to passed and the content is set to the error message o f the
	 * exception
	 * 
	 * @param message the message to be displayed in the header of the error pop up
	 *                dialogue
	 * 
	 * @param ex      the exception raised with the message in which to pass along
	 *                to the user
	 * 
	 */
	private static void showError(String message, Exception ex) {
		Alert alert = new Alert(Alert.AlertType.ERROR);
		alert.setTitle("Error");
		alert.setHeaderText(null); // no header, just a body
		alert.setContentText(message + "\n" + ex.getMessage());
		alert.showAndWait();
	}

	/**********
	 * <p>
	 * Method: {@code loadInto(TableView<Invitation> table)}
	 * </p>
	 * 
	 * <p>
	 * Description: This method verifies the data conforms to what is expected, and
	 * loads the provided invitations into a data type readable by the table view
	 * GUI, and sets the view to the provided data.
	 * 
	 * @param table specifies the TableView that will be populated with Invitation
	 *              objects
	 * 
	 */

	public static void loadInto(TableView<Invitation> table) {
		try {
			List<Invitation> list = ModelManageInvitations.loadInvitations();
			table.setItems(FXCollections.observableArrayList(list));
		} catch (Exception ex) {
			showError("Failed to load invitations", ex);
			table.getItems().clear();
		}
	}

	/**********
	 * <p>
	 * Method: {@code handleDelete(Invitation inv, TableView<Invitation> table)}
	 * </p>
	 * 
	 * <p>
	 * Description: This method handles deleting an invitation from the database and
	 * from the view. this method first checks in the invitation provided is valid,
	 * then processes deleting it.
	 * 
	 * @param inv   specifies the Invitation object to be deleted
	 *
	 * @param table specifies the TableView from which the deleted invitation should
	 *              be removed from
	 * 
	 */
	public static void handleDelete(Invitation inv, TableView<Invitation> table) {
		if (inv == null)
			return;

		Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
				"Delete this invitation for " + inv.getEmailAddress() + "?", ButtonType.OK, ButtonType.CANCEL);
		confirm.setHeaderText(null);
		if (confirm.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK)
			return;

		try {
			ModelManageInvitations.deleteInvitation(inv);
			table.getItems().remove(inv);
		} catch (Exception ex) {
			showError("Failed to delete invitation", ex);
		}
	}

	/**********
	 * <p>
	 * Method:
	 * {@code handleExtend(Invitation inv, Stage owner, TableView<Invitation> table) }
	 * </p>
	 * 
	 * <p>
	 * Description: This method handles extending the expiration deadline of a given
	 * invitation.
	 * 
	 * The user is presented with a pop up window in which they can select a new
	 * date in which the the user must register on by 11:59pm
	 * 
	 * @param inv   specifies the Invitation object to be deleted
	 *
	 * @param table specifies the TableView from which the deleted invitation should
	 *              be removed from
	 * 
	 */

	public static void handleExtend(Invitation inv, Stage owner, TableView<Invitation> table) {
		if (inv == null)
			return;

		DatePicker picker = new DatePicker(LocalDate.now().plusDays(7));
		Dialog<LocalDate> dlg = new Dialog<>();
		dlg.setTitle("Extend deadline");
		dlg.initOwner(owner);
		dlg.getDialogPane().setContent(picker);
		dlg.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
		dlg.setResultConverter(bt -> bt == ButtonType.OK ? picker.getValue() : null);

		LocalDate chosen = dlg.showAndWait().orElse(null);
		if (chosen == null)
			return;

		LocalDateTime newDate = LocalDateTime.of(chosen, LocalTime.of(23, 59, 59));

		try {
			ModelManageInvitations.extendDeadline(inv, newDate);
			// TableView refreshes
			Invitation updated = new Invitation(inv.getEmailAddress(), inv.getCode(), inv.getRole(), newDate);
			int idx = table.getItems().indexOf(inv);
			if (idx >= 0)
				table.getItems().set(idx, updated);
		} catch (Exception ex) {
			showError("Failed to extend deadline", ex);
		}
	}
}
