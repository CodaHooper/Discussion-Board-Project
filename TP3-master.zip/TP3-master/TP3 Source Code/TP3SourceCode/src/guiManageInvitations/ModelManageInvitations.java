package guiManageInvitations;

import java.util.List;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;
import database.Database;
import entityClasses.Invitation;
import java.time.LocalDateTime;

public class ModelManageInvitations {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**
	 * <p>
	 * Method: loadInvitations()
	 * </p>
	 * 
	 * <p>
	 * Description: This method retrieves all invitations from the database and puts
	 * them into a list. invitations are created using email address, code, role,
	 * and expiration date,
	 * </p>
	 * 
	 * @return a list of Invitations from the database
	 * @throws SQLException if a database error occurs during fetching the
	 *                      invitations
	 */
	public static List<Invitation> loadInvitations() throws SQLException {
		List<Invitation> invitations = new ArrayList<>();
		List<Map<String, Object>> invitationRows = theDatabase.fetchAllInvitations();
		for (Map<String, Object> row : invitationRows) {
			// Convert Timestamp into LocalDateTime
			Invitation inv = new Invitation((String) row.get("emailAddress"), (String) row.get("code"),
					(String) row.get("role"), (LocalDateTime) row.get("expirationDate"));
			invitations.add(inv);
		}
		return invitations;
	}

	/**********
	 * <p>
	 * Method: deleteInvitation(Invitation inv)
	 * </p>
	 *
	 * <p>
	 * Description: This method deletes an invitation from the database.
	 * 
	 * @param inv specifies the Invitation object to be removed from the database
	 */
	public static void deleteInvitation(Invitation inv) {
		theDatabase.removeInvitation(inv.getCode());
	}

	/**********
	 * <p>
	 * Method: extendDeadline(Invitation inv, LocalDateTime newDate)
	 * </p>
	 *
	 * <p>
	 * Description: This method updates the expiration deadline of a given
	 * invitation in the database.
	 * </p>
	 *
	 * @param inv     specifies the Invitation object whose deadline is being
	 *                extended
	 * @param newDate specifies the new expiration date and time for the invitation
	 */
	public static void extendDeadline(Invitation inv, LocalDateTime newDate) {
		theDatabase.extendInvitationDate(inv.getCode(), newDate);
	}
}
