module TP3Source {
	requires javafx.controls;
	requires java.sql;
	requires javafx.base;
	requires javafx.graphics;
	requires jakarta.mail;
	requires jakarta.activation;
	requires org.junit.jupiter.api;
	
	opens applicationMain to javafx.graphics, javafx.fxml;
	opens guiManageInvitations to javafx.base;
	opens entityClasses to javafx.base;
}