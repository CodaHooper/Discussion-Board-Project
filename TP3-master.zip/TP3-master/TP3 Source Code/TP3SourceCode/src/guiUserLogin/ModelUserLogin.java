package guiUserLogin;

/*
 * <p> Title: ModelUserLogin Class. </p>
 * 
 * <p> Description: The User Login Model. This class is not used as there
 * is no data manipulated by this MVC beyond accepting role information and
 * saving it in the database.</p>
 */
public class ModelUserLogin {

}
