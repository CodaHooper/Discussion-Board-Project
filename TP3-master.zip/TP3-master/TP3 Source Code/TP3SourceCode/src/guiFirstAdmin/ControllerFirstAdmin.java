package guiFirstAdmin;

import java.sql.SQLException;
import database.Database;
import entityClasses.User;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ControllerFirstAdmin {
	/*-********************************************************************************************
	
	The controller attributes for this page
	
	This controller is not a class that gets instantiated.  Rather, it is a collection of protected
	static methods that can be called by the View (which is a singleton instantiated object) and 
	the Model is often just a stub, or will be a singleton instantiated object.
	
	*/

	private static String adminUsername = "";
	private static String adminPassword1 = "";
	private static String adminPassword2 = "";
	protected static Database theDatabase = applicationMain.DiscussionsMain.database;

	/*-********************************************************************************************
	
	The User Interface Actions for this page
	
	*/

	/**********
	 * <p>
	 * Method: setAdminUsername()
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the user adds text to the username
	 * field in the View. A private local copy of what was last entered is kept
	 * here.
	 * </p>
	 * 
	 */
	protected static void setAdminUsername() {
		adminUsername = ViewFirstAdmin.text_AdminUsername.getText();
	}

	/**********
	 * <p>
	 * Method: setAdminPassword1()
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the user adds text to the password 1
	 * field in the View. A private local copy of what was last entered is kept
	 * here.
	 * </p>
	 * 
	 */
	protected static void setAdminPassword1() {
		adminPassword1 = ViewFirstAdmin.text_AdminPassword1.getText();
	}

	/**********
	 * <p>
	 * Method: setAdminPassword2()
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the user adds text to the password 2
	 * field in the View. A private local copy of what was last entered is kept
	 * here.
	 * </p>
	 * 
	 */
	protected static void setAdminPassword2() {
		adminPassword2 = ViewFirstAdmin.text_AdminPassword2.getText();
	}

	/**********
	 * <p>
	 * Method: doSetupAdmin()
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the user presses the button to set up
	 * the Admin account. It start by trying to establish a new user and placing
	 * that user into the database. If that is successful, we proceed to the
	 * UserUpdate page.
	 * </p>
	 * 
	 */
	protected static void doSetupAdmin(Stage ps, int r) {
		// Run validation checks in ModelFirstAdmin
		String userMessage = ModelFirstAdmin.checkForValidUserName(adminUsername);
		String passMessage = ModelFirstAdmin.evaluatePassword(adminPassword1);

		// Display Final Messages

		ViewFirstAdmin.alertUsernamePasswordError = new Alert(AlertType.ERROR);
		ViewFirstAdmin.alertUsernamePasswordError.setTitle("ERROR");
		// Check if the username entered is valid
		if (!userMessage.isEmpty()) {
			ViewFirstAdmin.alertUsernamePasswordError.setHeaderText("Username does not meet requirements");
			ViewFirstAdmin.alertUsernamePasswordError.setContentText(userMessage);
			ViewFirstAdmin.text_AdminUsername.setText("");
			ViewFirstAdmin.text_AdminPassword1.setText("");
			ViewFirstAdmin.text_AdminPassword2.setText("");
			ViewFirstAdmin.alertUsernamePasswordError.showAndWait();
			return;
		}
		// Check if the password entered is valid
		else if (!passMessage.isEmpty()) {
			String errorMessage = buildPassErrorMessage(passMessage);
			ViewFirstAdmin.alertUsernamePasswordError.setHeaderText("Password does not meet requirements");
			ViewFirstAdmin.alertUsernamePasswordError.setContentText(errorMessage);
			ViewFirstAdmin.text_AdminPassword1.setText("");
			ViewFirstAdmin.text_AdminPassword2.setText("");
			ViewFirstAdmin.alertUsernamePasswordError.showAndWait();
			return;
		}

		// Make sure the two passwords are the same
		if (adminPassword1.compareTo(adminPassword2) == 0) {
			// Create the passwords and proceed to the user home page
			User user = new User(adminUsername, adminPassword1, "", "", "", "", "", true, false, false);
			try {
				// Create a new User object with admin role and register in the database
				theDatabase.register(user);
			} catch (SQLException e) {
				System.err.println("*** ERROR *** Database error trying to register a user: " + e.getMessage());
				e.printStackTrace();
				System.exit(0);
			}

			// User was established in the database, so navigate to initial login part of
			// the User Update Page
			guiUserUpdate.ViewUserUpdate.displayUserUpdateFirstLogin(ViewFirstAdmin.theStage, user);
		} else {
			// The two passwords are NOT the same, so clear the passwords, explain the
			// passwords must be the same, and clear the message as soon as the first
			// character is typed.
			ViewFirstAdmin.alertUsernamePasswordError.setHeaderText("Passwords do not match");
			ViewFirstAdmin.alertUsernamePasswordError.setContentText("Your passwords do not match.");
			ViewFirstAdmin.text_AdminPassword1.setText("");
			ViewFirstAdmin.text_AdminPassword2.setText("");
			ViewFirstAdmin.alertUsernamePasswordError.showAndWait();
		}
	}

	/**********
	 * <p>
	 * 
	 * Method: buildPassErrorMessage().
	 * </p>
	 * 
	 * <p>
	 * Description: Public static method that generates a user-friendly error
	 * message describing why a given password input is invalid. this method
	 * converts the error message into more meaningful feedback for the user, such
	 * as whether the password is empty, does not match confirmation input, exceeds
	 * length limits, or is missing certain required character types (uppercase,
	 * lowercase, digit, or special character).
	 * </p>
	 * 
	 * @param passMessage This String contains the raw error message for the
	 *                    password
	 * 
	 * @return String Returns a user-friendly error message that explains the
	 *         problem with the password in plain English. If multiple requirements
	 *         are missing, the message lists each missing element.
	 */

	public static String buildPassErrorMessage(String passMessage) {
		if (passMessage.equals("*** Error *** The password is empty!")) {
			return "Your password cannot be empty";
		}
		if (passMessage.contains("*** Error *** The password exceeded a length of 32 characters!")
				|| passMessage.contains("Long Enough;")) {
			return "Your password must be between 8 and 32 charecters";
		}

		String out = "Your password is missing:\n";
		if (passMessage.contains("\"Upper case;")) {
			out += "Upper case charecter\n";
		}
		if (passMessage.contains("Lower case;")) {
			out += "Lower case charecter\n";
		}
		if (passMessage.contains("Numeric digits;")) {
			out += "A digit 0-9\n";
		}
		if (passMessage.contains("Special character;")) {
			out += "A special charecter: ~`!@#$%^&*()_-+={}[]|\\\\:;\\\"'<>,.?/";
		}
		return out;

	}

	/**********
	 * <p>
	 * Method: performQuit()
	 * </p>
	 * 
	 * <p>
	 * Description: This method terminates the execution of the program. It leaves
	 * the database in a state where the normal login page will be displayed when
	 * the application is restarted.
	 * </p>
	 * 
	 */
	protected static void performQuit() {
		System.out.println("Perform Quit");
		System.exit(0);
	}
}
