package guiFirstAdmin;

import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.Scene;

/*******
 * <p>
 * Title: ViewFirstAdmin Class
 * </p>
 * 
 * <p>
 * Description: The FirstAdmin Page View. This class is used to require the very
 * first user of the system to specify an Admin Username and Password when there
 * is no database for the application. This avoids the common weakness practice
 * of hard coding credentials into the application.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2025
 * </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 1.00 2025-08-15 Initial version
 * 
 */

public class ViewFirstAdmin {

	/*-********************************************************************************************
	
	Attributes
	
	 */

	// These are the application values required by the user interface

	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// These are the widget attributes for the GUI

	// The GUI informs the user about the purpose of this page, provides three text
	// inputs fields
	// for the user to specify a username for this account and two copies of the
	// password to be
	// used (they must match), a button to request that the account be established,
	// and a quit
	// but to abort the action and stop the application.
	private static Label label_TitleLine = new Label("Discussions");
	private static Label label_TitleLine1 = new Label("You are the first user - Create an Admin Account");

	protected static TextField text_AdminUsername = new TextField();
	protected static PasswordField text_AdminPassword1 = new PasswordField();
	protected static PasswordField text_AdminPassword2 = new PasswordField();

	private static Button button_Quit = new Button("Quit");
	private static Button button_AdminSetup = new Button("Setup Admin Account");

	// This alert is used should the user enter two passwords that do not match
	protected static Alert alertUsernamePasswordError = new Alert(AlertType.INFORMATION);

	// These attributes are used to configure the page and populate it with this
	// user's information
	protected static Stage theStage;
	private static Pane theRootPane;
	private static Scene theFirstAdminScene = null;
	private static final int theRole = 1; // Admin: 1; Staff: 2; Student: 3

	/*-********************************************************************************************
	
	Constructor
	
	 */

	/**********
	 * <p>
	 * Method: public displayFirstAdmin(Stage ps)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is called when the application first starts. It
	 * create an an instance of the View class.
	 * 
	 * NOTE: As described below, this code does not implement MVC using the
	 * singleton pattern used by most of the pages as the code is written this way
	 * because we know with certainty that it will only be called once. For this
	 * reason, we directly call the private class constructor.
	 * 
	 * @param ps specifies the JavaFX Stage to be used for this GUI and it's methods
	 */
	public static void displayFirstAdmin(Stage ps) {

		// Establish the references to the GUI. There is no user yet.
		theStage = ps; // Establish a reference to the JavaFX Stage

		// This page is only called once so there is no need to save the reference to it
		new ViewFirstAdmin(); // Create an instance of the class

		// Populate the dynamic aspects of the GUI with the data from the user and the
		// current
		// state of the system.
		applicationMain.DiscussionsMain.activeHomePage = theRole; // 1: Admin; 2: Staff; 3 Roles2

		// Set the title for the window, display the page, and wait for the Admin to do
		// something
		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theFirstAdminScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: private ViewFirstAdmin()
	 * </p>
	 * 
	 * <p>
	 * Description: This constructor is called when the application first starts. It
	 * must handle when no user has been established. It is never called again,
	 * either during the first run of the program after reboot or during normal
	 * operations of the program. (This page is only used when there is no database
	 * for the application or there is a database, but there no users in the
	 * database.
	 * 
	 * If there is no database or there is a database, but there are no users, it
	 * means that the person starting the system is an administrator, so a special
	 * GUI is provided to allow this Admin to create an account by setting a
	 * username and password.
	 * 
	 * If there is at least one user, this page is not called. Since this is only
	 * used one when the system is being set up, this MVC code does not use a
	 * singleton protocol. For this reason, do not use this as a typical MVC
	 * pattern.
	 * </p>
	 * 
	 * This is the View of the Model, View, Controller architectural pattern. Due to
	 * how it is called, it does not follow the usual singleton implementation
	 * pattern as explained above.
	 * 
	 * The view sets up the window and all of the Graphical User Interface (GUI)
	 * widgets. Once they are all set, the window is displayed to the user, the View
	 * returns to the starting main method, and that execution thread ends. The
	 * JavaFX thread continues to "execute" waiting for the user to interact with
	 * the GUI. Based on which widget is used, changes to the display are made
	 * and/or a Controller method is called to perform some action.
	 * 
	 */
	private ViewFirstAdmin() {
		// Create the Pane for the list of widgets and the Scene for the window
		theRootPane = new Pane();
		theFirstAdminScene = new Scene(theRootPane, width, height);

		// Add the 'guiFirstAdmin.css" style sheet to the scene (which is located in the
		// css folder).
		theFirstAdminScene.getStylesheets().add(getClass().getResource("/css/guiFirstAdmin.css").toExternalForm());

		// Set up the label to display the application name.
		label_TitleLine.getStyleClass().add("title-1");
		label_TitleLine.setAlignment(Pos.CENTER);
		label_TitleLine.setMinWidth(width);
		label_TitleLine.setLayoutX(0);
		label_TitleLine.setLayoutY(20);

		// Set up the label to display the welcome message for the first user.
		label_TitleLine1.getStyleClass().add("title-2");
		label_TitleLine1.setAlignment(Pos.CENTER);
		label_TitleLine1.setMinWidth(width);
		label_TitleLine1.setLayoutX(0);
		label_TitleLine1.setLayoutY(80);

		// Set up the text input field for the Admin username.
		text_AdminUsername.getStyleClass().add("username-text-field");
		text_AdminUsername.setPromptText("Username");
		text_AdminUsername.textProperty().addListener((observable, oldValue, newValue) -> {
			ControllerFirstAdmin.setAdminUsername();
		});
		text_AdminUsername.setAlignment(Pos.BASELINE_LEFT);
		text_AdminUsername.setMinWidth(300);
		text_AdminUsername.setLayoutX(50);
		text_AdminUsername.setLayoutY(160);
		text_AdminUsername.setEditable(true);

		// Set up the text input field for the password.
		text_AdminPassword1.getStyleClass().add("password-text-field-1");
		text_AdminPassword1.setPromptText("Password");
		text_AdminPassword1.textProperty().addListener((observable, oldValue, newValue) -> {
			ControllerFirstAdmin.setAdminPassword1();
		});
		text_AdminPassword1.setAlignment(Pos.BASELINE_LEFT);
		text_AdminPassword1.setMinWidth(300);
		text_AdminPassword1.setLayoutX(50);
		text_AdminPassword1.setLayoutY(210);
		text_AdminPassword1.setEditable(true);

		// Set up the second text input field for the password.
		text_AdminPassword2.getStyleClass().add("password-text-field-2");
		text_AdminPassword2.setPromptText("Verify Password");
		text_AdminPassword2.textProperty().addListener((observable, oldValue, newValue) -> {
			ControllerFirstAdmin.setAdminPassword2();
		});
		text_AdminPassword2.setAlignment(Pos.BASELINE_LEFT);
		text_AdminPassword2.setMinWidth(300);
		text_AdminPassword2.setLayoutX(50);
		text_AdminPassword2.setLayoutY(260);
		text_AdminPassword2.setEditable(true);

		// Set up the 'Setup Admin Account' button.
		button_AdminSetup.getStyleClass().add("log-in-button");
		button_AdminSetup.setOnAction((event) -> {
			ControllerFirstAdmin.doSetupAdmin(theStage, 1);
		});
		button_AdminSetup.setAlignment(Pos.CENTER);
		button_AdminSetup.setLayoutX(475);
		button_AdminSetup.setLayoutY(210);

		// Set up the 'Quit' button.
		button_Quit.getStyleClass().add("quit-button");
		button_Quit.setOnAction((event) -> {
			ControllerFirstAdmin.performQuit();
		});
		button_Quit.setAlignment(Pos.CENTER);
		button_Quit.setMinWidth(250);
		button_Quit.setLayoutX(width / 2 - 150);
		button_Quit.setLayoutY(500);

		// Place all of the just-initialized GUI elements into the pane.
		theRootPane.getChildren().addAll(label_TitleLine, label_TitleLine1, text_AdminUsername, text_AdminPassword1,
				text_AdminPassword2, button_AdminSetup, button_Quit);
	}
}