package guiResetPassword;

import database.Database;
import guiUserLogin.ViewUserLogin;

/**
 * <p>
 * Title: ControllerResetPassword Class
 * </p>
 * 
 * <p>
 * Description: This class serves as the controller for the Reset Password
 * feature in the MVC pattern. It handles validating one-time passwords (OTPs),
 * checking password requirements, and updating the database with the new
 * password.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerResetPassword {

	// Reference to the in-memory database so this package has access
	private static Database database = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: resetPassword()
	 * </p>
	 * 
	 * <p>
	 * Description: Handles the logic for resetting a user's password. Steps:
	 * </p>
	 * 
	 * <p>
	 * 1. Retrieves the username, one-time password, and the two new password
	 * entries from the view.
	 * </p>
	 * <p>
	 * 2. Validates the OTP against the database.
	 * </p>
	 * <p>
	 * 3. Evaluates the new password for strength/requirements.
	 * </p>
	 * <p>
	 * 4. Ensures both password fields match.
	 * </p>
	 * <p>
	 * 5. Updates the password in the database and deletes the OTP if all
	 * validations pass.
	 * </p>
	 * <p>
	 * 6. Displays appropriate alerts for errors or success.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 */
	protected static void resetPassword() {
		String userName = ViewResetPassword.text_Username.getText();
		String otp = ViewResetPassword.text_OneTimePassword.getText();
		String password1 = ViewResetPassword.text_Password1.getText();
		String password2 = ViewResetPassword.text_Password2.getText();

		// Verify that the provided one-time password is the correct one
		// associated with the user's account.
		if (database.validateOneTimePassword(userName, otp)) {
			String passMessage = ModelResetPassword.evaluatePassword(password1);

			if (passMessage.isEmpty()) {
				if (password1.compareTo(password2) == 0) {
					// The user name, one-time password, and both passwords have passed
					// all of the validation checks, so update the password.
					database.updatePassword(userName, password1);

					// Delete the one-time password so it can't be used again.
					database.deleteOneTimePassword(userName);

					ViewResetPassword.alertSuccessfulReset.setHeaderText("Account Recovery Successful");
					ViewResetPassword.alertSuccessfulReset
							.setContentText("You have successfully reset your password - Please log in again");
					ViewResetPassword.alertSuccessfulReset.showAndWait();
					ViewUserLogin.displayUserLogin(ViewResetPassword.theStage);
				} else {
					// Error indicating both entered passwords are not the same
					ViewResetPassword.alertUsernamePasswordError.setHeaderText("Password does not meet requirements");
					ViewResetPassword.alertUsernamePasswordError.setContentText("The two passwords are not the same");
					ViewResetPassword.text_Password1.setText("");
					ViewResetPassword.text_Password2.setText("");
					ViewResetPassword.alertUsernamePasswordError.showAndWait();
					return;
				}
			} else {
				// Error indicating provided password does not meet specifications
				ViewResetPassword.alertUsernamePasswordError.setHeaderText("Password does not meet requirements");
				ViewResetPassword.alertUsernamePasswordError.setContentText(passMessage);
				ViewResetPassword.text_Password1.setText("");
				ViewResetPassword.text_Password2.setText("");
				ViewResetPassword.alertUsernamePasswordError.showAndWait();
				return;
			}
		} else {
			// Error indicating the otp is not correct.
			ViewResetPassword.alertUsernamePasswordError.setHeaderText("One-Time Password Error");
			ViewResetPassword.alertUsernamePasswordError
					.setContentText("The one-time password is incorrect or does not exist");
			ViewResetPassword.text_Password1.setText("");
			ViewResetPassword.text_Password2.setText("");
			ViewResetPassword.text_Username.setText("");
			ViewResetPassword.text_OneTimePassword.setText("");
			ViewResetPassword.alertUsernamePasswordError.showAndWait();
			return;
		}
	}
}