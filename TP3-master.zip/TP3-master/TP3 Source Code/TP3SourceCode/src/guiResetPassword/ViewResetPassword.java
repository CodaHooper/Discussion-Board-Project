package guiResetPassword;

import entityClasses.User;
import guiUserLogin.ViewUserLogin;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class ViewResetPassword {

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	protected static User theUser;

	// GUI Labels
	private static Label label_ApplicationTitle = new Label("Account Recovery");
	private static Label label_Instructions = new Label(
			"You need a one-time password from an Admin to reset your password");

	// Input fields
	protected static TextField text_Username = new TextField();
	protected static TextField text_OneTimePassword = new TextField();
	protected static PasswordField text_Password1 = new PasswordField();
	protected static PasswordField text_Password2 = new PasswordField();

	// Buttons
	private static Button button_ResetPassword = new Button("Reset Password");
	private static Button button_Return = new Button("Return");

	// Alerts
	protected static Alert alertInvalidOTP = new Alert(AlertType.ERROR);
	protected static Alert alertUsernamePasswordError = new Alert(AlertType.ERROR);
	protected static Alert alertSuccessfulReset = new Alert(AlertType.INFORMATION);

	private static ViewResetPassword theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static Pane theRootPane; // The Vbox that holds all the GUI widgets

	public static Scene theResetPasswordScene = null;

	/**********
	 * <p>
	 * Method: displayResetPassword(Stage ps, String otp)
	 * </p>
	 * 
	 * <p>
	 * Description: Entry point to display the Reset Password page. Sets up
	 * references, initializes the view if needed, clears all text fields, and
	 * populates the GUI components.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT
	 * 
	 * @param ps  the Stage used for displaying the GUI
	 * @param otp the one-time password (optional, not used directly here)
	 */
	public static void displayResetPassword(Stage ps, String otp) {
		theStage = ps;

		if (theView == null) {
			theView = new ViewResetPassword();
		}

		text_Username.setText("");
		text_OneTimePassword.setText("");
		text_Password1.setText("");
		text_Password2.setText("");

		theRootPane.getChildren().clear();
		theRootPane.getChildren().addAll(label_ApplicationTitle, label_Instructions, text_Username,
				text_OneTimePassword, text_Password1, text_Password2, button_ResetPassword, button_Return);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theResetPasswordScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewResetPassword()
	 * </p>
	 * 
	 * <p>
	 * Description: Initializes all GUI elements (labels, text fields, buttons,
	 * alerts) and sets their positions, sizes, and event handlers. This method is
	 * called only once (singleton).
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT
	 */
	private ViewResetPassword() {
		theRootPane = new Pane();
		theResetPasswordScene = new Scene(theRootPane, width, height);

		theResetPasswordScene.getStylesheets()
				.add(getClass().getResource("/css/guiResetPassword.css").toExternalForm());

		setupLabelUI(label_ApplicationTitle, width, Pos.CENTER, 0, 10);
		label_ApplicationTitle.getStyleClass().add("title");

		setupLabelUI(label_Instructions, width, Pos.CENTER, 0, 60);
		label_Instructions.getStyleClass().add("instructions");

		setupTextUI(text_Username, 300, Pos.BASELINE_LEFT, 87.5, 200, true);
		text_Username.setPromptText("Username");
		text_Username.getStyleClass().add("text-field");

		setupTextUI(text_OneTimePassword, 300, Pos.BASELINE_LEFT, 87.5, 250, true);
		text_OneTimePassword.setPromptText("One-Time Password");
		text_OneTimePassword.getStyleClass().add("text-field");

		setupTextUI(text_Password1, 300, Pos.BASELINE_LEFT, 87.5, 300, true);
		text_Password1.setPromptText("New Password");
		text_Password1.getStyleClass().add("text-field");

		setupTextUI(text_Password2, 300, Pos.BASELINE_LEFT, 87.5, 350, true);
		text_Password2.setPromptText("Verify New Password");
		text_Password1.getStyleClass().add("text-field");

		setupButtonUI(button_ResetPassword, 200, Pos.CENTER, 512.5, 275);
		button_ResetPassword.setOnAction((event) -> {
			ControllerResetPassword.resetPassword();
		});
		button_ResetPassword.getStyleClass().add("button");

		setupButtonUI(button_Return, 250, Pos.CENTER, 87.5, 520);
		button_Return.getStyleClass().add("button");
		button_Return.setOnAction((event) -> {
			ViewUserLogin.displayUserLogin(theStage);
		});
	}

	private void setupLabelUI(Label l, double w, Pos p, double x, double y) {
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, double w, Pos p, double x, double y) {
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	private void setupTextUI(TextField t, double w, Pos p, double x, double y, boolean e) {
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
}