package guiListDiscussions;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import entityClasses.Post;
import entityClasses.Reply;

import database.Database;

/**
 * <p>
 * Title: ModelListAllThreads Class
 * </p>
 * 
 * <p>
 * Description: The ModelListAllThreads class is part of the MVC structure for
 * the List All Threads feature. It currently contains no functionality, since
 * data access and retrieval are managed elsewhere in the system.
 * </p>
 * 
 * <p>
 * This class is included for completeness and future scalability, allowing for
 * the addition of thread-related data handling or database interaction if
 * needed in later updates.
 * </p>
 */
public class ModelListDiscussions {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: getTopLevelPosts(int threadID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This method retrieves all top-level posts associated with a
	 * given thread. It calls the getTopLevelPostsByThread method from the database
	 * and returns a list of Post objects for the specified user and thread.
	 * </p>
	 * 
	 * @param threadID Specifies the unique identifier of the thread.
	 * @param username Specifies the username of the user requesting the posts.
	 * 
	 * @return A List<Post> containing all top-level posts within the given thread.
	 */
	protected static List<Post> getTopLevelPosts(int threadID, String username) {
		List<Post> topLevelPosts = new ArrayList<Post>();
		try {
			topLevelPosts = theDatabase.getTopLevelPostsByThread(threadID, username);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return topLevelPosts;
	}

	/**********
	 * <p>
	 * Method: getPostReplies(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies for a given post. If a database exception
	 * occurs, returns an empty list.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param postID   The id of the parent post.
	 * @param username The username of the user requesting replies.
	 * 
	 * @return A List<Reply> containing all direct replies to the specified post.
	 */
	protected static List<Reply> getPostReplies(int postID, String username) {
		try {
			return theDatabase.getRepliesForPost(postID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}

	/**********
	 * <p>
	 * Method: getReplyReplies(int replyID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies to a given reply. If any database
	 * exception occurs, returns an empty list.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param replyID  The unique identifier of the parent reply.
	 * @param username The user requesting replies.
	 * 
	 * @return A List<Reply> containing all direct replies to the specified reply.
	 */
	protected static List<Reply> getReplyReplies(int replyID, String username) {
		try {
			return theDatabase.getRepliesForPost(replyID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}

	/**
	 * <p>
	 * Method: protected static String getThreadTitle(int threadID)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies to a given reply. If any database
	 * exception occurs, returns an empty list.
	 * </p>
	 * 
	 * 
	 * @param threadID
	 * @return
	 */
	protected static String getThreadTitle(int threadID) {
		return (String) (theDatabase.readThread(threadID)).get("title");
	}

	/**********
	 * <p>
	 * Method: createReplyDB(int threadID, int postID, String username, String
	 * replyTitle, String reply, int type)
	 * </p>
	 * 
	 * <p>
	 * Description: Creates a new reply in the database. After creation, it clears
	 * the corresponding reply feilds in the view based on the type:
	 * </p>
	 * <p>
	 * type = 1 => Reply to POST
	 * </p>
	 * <p>
	 * type = 2 => Reply to REPLY
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param threadID   The ID of the thread the reply belongs to.
	 * @param postID     The ID of the parent post or reply.
	 * @param username   The username of the author of the reply.
	 * @param replyTitle The title of the reply.
	 * @param reply      The body of the reply.
	 * @param type       The type of reply dialog 1 = Post, 2 = Reply
	 * 
	 * @return true if the reply was successfully created, false if a SQLException
	 *         occurred.
	 */
	protected static boolean createReplyDB(int threadID, int postID, String username, String replyTitle, String reply,
			int type) {
		try {
			theDatabase.createPost(threadID, postID, username, replyTitle, reply);
			if (type == 1) // post
				ViewListDiscussions.replyContent1.clear();
			if (type == 2) // reply
				ViewListDiscussions.replyContent2.clear();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	/**********
	 * <p>
	 * Method: setReadDB(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Marks a post or reply as read for the given user.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param postID   The ID of the post or reply to mark as read.
	 * @param username The user reading the post or reply
	 */
	protected static void setReadDB(int postID, String username) {
		theDatabase.setReadPost(postID, username);
	}
}
