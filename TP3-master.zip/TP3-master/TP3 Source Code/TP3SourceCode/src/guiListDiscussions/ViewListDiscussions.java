package guiListDiscussions;

import entityClasses.User;
import entityClasses.Post;
import entityClasses.Reply;
import entityClasses.Thread;
import entityClasses.ThreadsCollection;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import database.Database;

/**
 * <p>
 * Title: ViewListAllThreads Class
 * </p>
 *
 * <p>
 * Description: The ViewListAllThreads class is responsible for displaying all
 * discussion threads within the system. It provides a hierarchical view of
 * threads, their associated posts, and replies using a {@code TreeTableView}.
 * </p>
 *
 * <p>
 * This class serves as the main graphical user interface (GUI) component for
 * listing and browsing all discussion threads. It allows users to view thread
 * and post details, open posts to read their content, and create replies
 * dynamically. Replies are loaded lazily to improve performance and
 * scalability.
 * </p>
 */
public class ViewListDiscussions {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// Placeholder for mark reply branches that aren't loaded yet
	private static final Object LAZY_PLACEHOLDER = new Object();

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of threads, posts, and replies using a treetableview
	private static TreeTableView<Object> threadsTree;

	// Alert error for discussion errors
	protected static Alert alertDiscussions = new Alert(Alert.AlertType.ERROR);

	protected static TextArea postContent1; // -> postContentInPostDialog
	protected static TextArea replyContent1; // -> replyInputInPostDialog
	protected static TextArea postContent2; // -> replyContentInReplyDialog
	protected static TextArea replyContent2; // -> replyInputInReplyDialog

	// GUI Area 3: This area is used to enable the student to return to the student
	// home
	// screen
	protected static Button button_StudentHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewListDiscussions theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theListDiscussionsScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayListDiscussions(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View List Discussions Threads page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the tree
	 * table view with the appropriate information for the users and their
	 * respective threads, posts, and replies.
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayListDiscussions(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewListDiscussions(); // Instantiate singleton if needed
		}

		// GUI Area 2
		ThreadsCollection tc = new ThreadsCollection(theDatabase);
		List<Thread> threads = tc.getThreads();
		populateThreads(threads);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theListDiscussionsScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewListAllThreads()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayListAllThreads method.
	 * </p>
	 * 
	 */
	private ViewListDiscussions() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theListDiscussionsScene = new Scene(theRoot, width, height);

		theListDiscussionsScene.getStylesheets()
				.add(getClass().getResource("/css/guiListDiscussions.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Discussions: Threads");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		threadsTree = buildThreadsTree();

		// GUI Area 3
		setupButtonUI(button_StudentHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StudentHomeScreen.setOnAction((event) -> {
			guiStudentHome.ViewStudentHome.displayStudentHome(theStage, user);
		});
		button_StudentHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, threadsTree, button_StudentHomeScreen);
	}

	/****
	 * <p>
	 * Method: TreeTableView<Object> buildThreadsTree()
	 * </p>
	 *
	 * <p>
	 * Description: Builds and configures the tree table used to display the
	 * hierarchy of Threads → Posts → Replies. Defines Title, Author, and Actions
	 * columns and returns the initialized TreeTableView.
	 * </p>
	 *
	 * @return a configured TreeTableView that displays threads, posts, and replies
	 */
	private TreeTableView<Object> buildThreadsTree() {
		TreeTableColumn<Object, String> colTitle = new TreeTableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> {
			Object row = cd.getValue().getValue();
			String title;
			if (row instanceof Thread t)
				title = t.getTitle();
			else if (row instanceof Post p)
				title = p.getTitle();
			else if (row instanceof Reply r)
				title = r.getTitle();
			else
				title = "";
			return new ReadOnlyStringWrapper(title == null || title.isBlank() ? "(untitled)" : title);
		});
		colTitle.setPrefWidth(width * 0.50);

		TreeTableColumn<Object, String> colAuthor = new TreeTableColumn<>("Author");
		colAuthor.setCellValueFactory(cd -> {
			Object row = cd.getValue().getValue();
			String author;
			if (row instanceof Thread t)
				author = t.getAuthor();
			else if (row instanceof Post p)
				author = p.getAuthor();
			else if (row instanceof Reply r)
				author = r.getAuthor();
			else
				author = "";
			return new ReadOnlyStringWrapper(author);
		});
		colAuthor.setPrefWidth(width * 0.16);

		TreeTableColumn<Object, String> colReplyCount = new TreeTableColumn<>("Replies");
		colReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyCount()); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colReplyCount.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, String> colUnreadReplyCount = new TreeTableColumn<>("Unread Replies");
		colUnreadReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyUnread(theDatabase, user.getUserName())); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colUnreadReplyCount.setPrefWidth(width * 0.10);

		TreeTableColumn<Object, String> colRead = new TreeTableColumn<>("Read");
		colRead.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = p.getIsRead(); // only meaningful for posts/replies
			else if (o instanceof Reply r)
				v = r.getIsRead();
			return new ReadOnlyStringWrapper(v);
		});
		colRead.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, Object> colActions = new TreeTableColumn<>("Actions");
		colActions.setCellValueFactory(
				param -> new ReadOnlyObjectWrapper<>(param.getValue() == null ? null : param.getValue().getValue()));
		colActions.setCellFactory(col -> new TreeTableCell<Object, Object>() {
			private final MenuItem open = new MenuItem("Open");
			private final MenuButton menu = new MenuButton("⋮", null, open);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
				open.setOnAction(e -> {
					Object o = getItem();
					ControllerListDiscussions.openObject(o);
				});
			}

			@Override
			protected void updateItem(Object item, boolean empty) {
				super.updateItem(item, empty);
				if (empty) {
					setGraphic(empty ? null : menu);
					return;
				}

				Object v = getTreeTableView().getTreeItem(getIndex()).getValue();

				// reset menu items per row
				menu.getItems().setAll(open);
				
				setGraphic(menu);
			}
		});
		colActions.setPrefWidth(width * 0.10);
		colActions.setSortable(false);

		TreeItem<Object> root = new TreeItem<>();
		root.setExpanded(true);

		TreeTableView<Object> table = new TreeTableView<>(root);
		table.getColumns().addAll(colTitle, colAuthor, colReplyCount, colUnreadReplyCount, colRead, colActions);
		table.setShowRoot(false);
		table.setColumnResizePolicy(TreeTableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
		table.setPrefHeight(height - 100);
		return table;
	}

	/****
	 * <p>
	 * Method: void populateThreads(List<Thread> threads)
	 * </p>
	 *
	 * <p>
	 * Description: Populates the root of the tree with thread rows and adds each
	 * thread’s top-level posts. Reply children are attached lazily.
	 * </p>
	 *
	 * @param threads the list of Thread objects to render at the root level
	 */
	protected static void populateThreads(List<Thread> threads) {
		if (threadsTree == null)
			return;
		TreeItem<Object> root = threadsTree.getRoot();
		root.getChildren().clear();

		if (threads == null)
			return;

		for (Thread t : threads) {
			TreeItem<Object> threadItem = new TreeItem<>(t);
			root.getChildren().add(threadItem);

			List<Post> topLevelPosts = new ArrayList<Post>();
			topLevelPosts = ModelListDiscussions.getTopLevelPosts(t.getThreadID(), user.getUserName());
			if (topLevelPosts != null) {
				for (Post p : topLevelPosts) {
					TreeItem<Object> postItem = new TreeItem<>(p);
					threadItem.getChildren().add(postItem);
					lazyReplyForPost(postItem, p.getPostID());
				}
			}
		}
	}

	/****
	 * <p>
	 * Method: void lazyReplyForPost(TreeItem<Object> postItem, int postId)
	 * </p>
	 *
	 * <p>
	 * Description: Attaches a lazy loader to a post row. When the post node is
	 * expanded, this method fetches its direct replies and inserts them as
	 * children. Each reply child is itself wired for further lazy loading.
	 * </p>
	 *
	 * @param postItem the TreeItem representing the parent post in the tree
	 * 
	 * @param postId   the database ID of the parent post whose replies are loaded
	 */
	protected static void lazyReplyForPost(TreeItem<Object> postItem, int postId) {
		postItem.getChildren().setAll(new TreeItem<>(LAZY_PLACEHOLDER));
		postItem.expandedProperty().addListener((obs, was, is) -> {
			if (!is)
				return;
			if (postItem.getChildren().size() == 1 && postItem.getChildren().get(0).getValue() == LAZY_PLACEHOLDER) {
				postItem.getChildren().clear();
				List<Reply> replies;
				replies = ModelListDiscussions.getPostReplies(postId, user.getUserName());
				for (Reply r : replies) {
					TreeItem<Object> replyItem = new TreeItem<>(r);
					postItem.getChildren().add(replyItem);
					lazyReplyForReply(replyItem, r.getPostID());
				}
			}
		});
	}

	/****
	 * <p>
	 * Method: void lazyReplyForReply(TreeItem<Object> replyItem, int replyId)
	 * </p>
	 *
	 * <p>
	 * Description: Attaches a lazy loader to a reply row. When expanded, it loads
	 * the reply’s direct children (nested replies) and adds them to the tree,
	 * enabling unbounded nesting.
	 * </p>
	 *
	 * @param replyItem the TreeItem representing the parent reply in the tree
	 * 
	 * @param replyId   the database ID of the reply whose child replies are loaded
	 */
	protected static void lazyReplyForReply(TreeItem<Object> replyItem, int replyId) {
		replyItem.getChildren().setAll(new TreeItem<>(LAZY_PLACEHOLDER));
		replyItem.expandedProperty().addListener((obs, was, is) -> {
			if (!is)
				return;
			if (replyItem.getChildren().size() == 1 && replyItem.getChildren().get(0).getValue() == LAZY_PLACEHOLDER) {
				replyItem.getChildren().clear();
				List<Reply> replies;
				replies = ModelListDiscussions.getReplyReplies(replyId, user.getUserName());
				for (Reply r : replies) {
					TreeItem<Object> child = new TreeItem<>(r);
					replyItem.getChildren().add(child);
					lazyReplyForReply(child, r.getPostID());
				}
			}
		});
	}

	/****
	 * <p>
	 * Method: void openThread(Thread t)
	 * </p>
	 *
	 * <p>
	 * Description: Opens a read-only dialog showing the selected thread’s title,
	 * author, and content.
	 * </p>
	 *
	 * @param t the Thread to display
	 */
	protected static void openThread(Thread t) {
		Stage dialog = new Stage();
		dialog.setTitle("Thread: " + t.getTitle());

		Label title = new Label(t.getTitle());
		Label author = new Label("By: " + t.getAuthor());

		TextArea content = new TextArea(t.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(10);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new Separator(), new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 300);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openPost(Post p)
	 * </p>
	 *
	 * <p>
	 * Description: Opens a dialog showing a post (title, author, content) and
	 * provides an input area to create a direct reply to that post.
	 * </p>
	 *
	 * @param p the Post to display and reply to
	 */
	protected static void openPost(Post p) {
		Stage dialog = new Stage();
		dialog.setTitle("Post");

		Label titleLabel = new Label(p.getTitle() == null || p.getTitle().isBlank() ? "(untitled)" : p.getTitle());
		Label authorLabel = new Label("By: " + p.getAuthor());

		postContent1 = new TextArea(p.getContent());
		postContent1.setEditable(false);
		postContent1.setWrapText(true);
		postContent1.setPrefRowCount(10);

		ModelListDiscussions.setReadDB(p.getPostID(), user.getUserName());

		replyContent1 = new TextArea();
		replyContent1.setPromptText("Reply...");
		replyContent1.setWrapText(true);
		replyContent1.setPrefRowCount(10);

		Button sendBtn = new Button("Create Reply");
		sendBtn.setOnAction(e -> {
			String reply = replyContent1.getText().trim();
			String threadTitle = ModelListDiscussions.getThreadTitle(p.getThreadID());
			String replyTitle = "Reply to: " + p.getTitle() + " by " + p.getAuthor() + " in " + threadTitle;
			if (ControllerListDiscussions.doCreateReply(p.getThreadID(), p.getPostID(), user.getUserName(), replyTitle,
					reply, 1)) {
				new Alert(Alert.AlertType.INFORMATION, "Reply created.").showAndWait();
				dialog.close();
			} else {
				new Alert(Alert.AlertType.ERROR, "Failed to create reply.").showAndWait();
			}
		});

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, titleLabel, authorLabel, new Separator(), postContent1, new Separator(),
				replyContent1, new HBox(10, sendBtn, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 325);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openReply(Reply r)
	 * </p>
	 *
	 * <p>
	 * Description: Opens a dialog showing a reply (author, content) and provides an
	 * input area to create a nested reply to that reply.
	 * </p>
	 *
	 * @param r the Reply to display and reply to
	 */
	protected static void openReply(Reply r) {
		Stage dialog = new Stage();
		dialog.setTitle("Reply");

		Label by = new Label("By: " + r.getAuthor());
		postContent2 = new TextArea(r.getContent());
		postContent2.setEditable(false);
		postContent2.setWrapText(true);
		postContent2.setPrefRowCount(10);

		ModelListDiscussions.setReadDB(r.getPostID(), user.getUserName());

		replyContent2 = new TextArea();
		replyContent2.setPromptText("Your reply…");
		replyContent2.setWrapText(true);
		replyContent2.setPrefRowCount(8);

		Button sendBtn = new Button("Create Reply");
		sendBtn.setOnAction(e -> {
			String reply = replyContent2.getText().trim();
			String threadTitle = ModelListDiscussions.getThreadTitle(r.getThreadID());
			String replyTitle = "Reply to: Reply by " + r.getAuthor() + " in " + threadTitle;
			if (ControllerListDiscussions.doCreateReply(r.getThreadID(), r.getPostID(), user.getUserName(), replyTitle,
					reply, 2)) {
				new Alert(Alert.AlertType.INFORMATION, "Reply created.").showAndWait();
				dialog.close();
			} else {
				new Alert(Alert.AlertType.ERROR, "Failed to create reply.").showAndWait();
			}
		});

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, by, new Separator(), postContent2, new Separator(), replyContent2, new Separator(),
				new HBox(10, sendBtn, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 325);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
