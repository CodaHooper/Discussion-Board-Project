package guiListDiscussions;

/**
 * <p>
 * Title: ControllerListAllThreads Class
 * </p>
 * 
 * <p>
 * Description: The ControllerListAllThreads class is part of the MVC structure
 * for the List All Threads feature. It currently has no logic implemented, as
 * all operations are handled directly within the view.
 * </p>
 * 
 * <p>
 * This class exists to maintain proper MVC separation and may be expanded in
 * the future to manage user interaction or control logic for thread listing
 * functionality.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerListDiscussions {

	/**********
	 * <p>
	 * Method: openObject(Object o)
	 * </p>
	 * 
	 * <p>
	 * Description: This method determines the type of the object selected by the
	 * user. Depending on the type, this method will pass the cast and pass the
	 * object to the appropriate view.
	 * </p>
	 * 
	 * <p>
	 * Depending on whether the selected object is a Thread, Post, or Reply, the
	 * method calls a different display function from ViewListDiscussions
	 * </p>
	 *
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param the object selected by the user, which can be an instance of a Thread,
	 *            Post, or Reply
	 * 
	 */
	protected static void openObject(Object o) {
		if (o instanceof entityClasses.Thread t)
			ViewListDiscussions.openThread(t);
		else if (o instanceof entityClasses.Post p)
			ViewListDiscussions.openPost(p);
		else if (o instanceof entityClasses.Reply r)
			ViewListDiscussions.openReply(r);
	}

	/**********
	 * <p>
	 * Method: doCreateReply(int threadID, int postID, String username, String
	 * replyTitle, String reply, int type)
	 * </p>
	 * 
	 * <p>
	 * Description: This method validates user input and creates a new reply to a
	 * post or thread. It ensures that the reply body is not empty and does not
	 * exceed 10,000 characters. If validation fails, the relevant text fields are
	 * cleared and an alert message is shown to the user.
	 * </p>
	 * 
	 * <p>
	 * If the input passes validation, the method inserts the new reply into the
	 * database.
	 * </p>
	 * 
	 * <p>
	 * This method handles creating replies to replies and to posts, the type field
	 * specifies which. For replies to post, pass TYPE = 1 and for replies to other
	 * replies, pass TYPE = 2
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param threadID   the thread to which the reply belongs
	 * 
	 * @param postID     the post that the reply is responding to
	 * 
	 * @param username   the username of the user creating the reply
	 * 
	 * @param replyTitle the title of the reply, if applicable
	 * 
	 * @param reply      the body text of the reply entered by the user
	 * 
	 * @param type       which input field is being used to enter the reply 1=POST,
	 *                   2=REPLY
	 * 
	 * @return true if the reply creation succeeded, otherwise false
	 * 
	 */
	protected static boolean doCreateReply(int threadID, int postID, String username, String replyTitle, String reply,
			int type) {
		if (reply.isEmpty()) {
			if (type == 1) // reply to post
				ViewListDiscussions.replyContent1.clear();
			if (type == 2) // reply to reply
				ViewListDiscussions.replyContent2.clear();
			ViewListDiscussions.alertDiscussions.setContentText("Reply body cannot be empty.");
			ViewListDiscussions.alertDiscussions.showAndWait();
			return false;
		} else if (reply.length() > 10000) {
			if (type == 1) // reply to post
				ViewListDiscussions.replyContent1.clear();
			if (type == 2) // reply to reply
				ViewListDiscussions.replyContent2.clear();
			ViewListDiscussions.replyContent1.clear();
			ViewListDiscussions.alertDiscussions.setContentText("Reply body cannot exceed 10,000 characters.");
			ViewListDiscussions.alertDiscussions.showAndWait();
			return false;
		} else
			return ModelListDiscussions.createReplyDB(threadID, postID, username, replyTitle, reply, type);
	}
}
