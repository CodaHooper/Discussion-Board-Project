package guiPendingRequests;

import java.sql.SQLException;

import entityClasses.Request;
import javafx.scene.control.TableView;

public class ControllerPendingRequests {
	public static void handleComplete(Request req, TableView<Request> table) throws SQLException {
		if (req == null) {
			return;
		}
		
		// Calls the ModelActiveRequests database method "completeRequest" to update
		// the item in the database to reflect it's new "Complete" status.
		ModelPendingRequests.completeRequest(req);
		
		// Removes the request from the list since it is now marked as "Complete"
		table.getItems().remove(req);
	}
	
	public static void handleDeny(Request req, TableView<Request> table) throws SQLException {
		if (req == null) {
			return;
		}
		
		// Calls the ModelActiveRequests database method "denyRequest" to update
		// the item in the database to reflect it's new "Denied" status.
		ModelPendingRequests.denyRequest(req);
		
		// Removes the request from the list since it is now marked as "Denied"
		table.getItems().remove(req);
	}
}