package guiPendingRequests;

import java.sql.SQLException;
import database.Database;
import entityClasses.Request;

public class ModelPendingRequests {
	private static Database theDatabase = applicationMain.DiscussionsMain.database;
	
	public static void completeRequest(Request req) throws SQLException {
		// Updates the items status field in the database to 'Complete'
		theDatabase.completeRequest(req.getUUID());
	}
	
	public static void denyRequest(Request req) throws SQLException {
		// Updates the items status field in the database to 'Denied"
		theDatabase.denyRequest(req.getUUID());
	}
}