package guiInactiveRequests;

import entityClasses.Request;
import entityClasses.RequestsCollection;
import entityClasses.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.sql.SQLException;

import database.Database;

public class ViewInactiveRequests {
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;
	
	private static Stage theStage;
	private static VBox theRoot;
	
	private static User user;
	
	public static Scene theInactiveRequestsScene = null;
	private static ViewInactiveRequests theView = null;
	
	protected static Label label_title = new Label();
	public static TableView<Request> table = new TableView<Request>();
	protected static Button button_Return = new Button("Return");
	
	private static Database database = applicationMain.DiscussionsMain.database;
	
	public static RequestsCollection requests = null;
	
	@SuppressWarnings("unchecked")
	public static void displayActiveRequests(Stage ps, User theUser) {
		theStage = ps;
		user = theUser;
		
		if (theView == null) {
			theView = new ViewInactiveRequests();
		}
		
		try {
			requests = database.retrieveCompletedRequests();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ObservableList<Request> requestList = FXCollections.observableArrayList(requests.ActiveRequests);
		table.setItems(requestList);
		
		TableColumn<Request,String> titleCol = new TableColumn<Request,String>("Request Title");
		TableColumn<Request,String> descriptionCol = new TableColumn<Request,String>("Request Description");
		TableColumn<Request,String> authorCol = new TableColumn<Request,String>("Created By");
		TableColumn<Request,String> statusCol = new TableColumn<Request,String>("Status");
		TableColumn<Request,Void> actionCol = new TableColumn<Request,Void>("");

		titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
		descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
		authorCol.setCellValueFactory(new PropertyValueFactory<>("author"));
		statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
		actionCol.setCellFactory(col -> new TableCell<Request, Void>() {

			private final MenuButton menu = new MenuButton("⋮");

			{
				MenuItem reopen = new MenuItem("Reopen");
				menu.getItems().addAll(reopen);
				
				reopen.setOnAction(e -> {
					Request request = getTableView().getItems().get(getIndex());
					try {
						ControllerInactiveRequests.handleReopen(request, table);
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				});
			}
			
			@Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(menu);
                }
            }
		});
		
		titleCol.setPrefWidth(152);
		descriptionCol.setPrefWidth(368);
		authorCol.setPrefWidth(114);
		statusCol.setPrefWidth(76);
		actionCol.setPrefWidth(50);
		
		table.getColumns().setAll(titleCol, descriptionCol, authorCol, statusCol, actionCol);
		
		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theInactiveRequestsScene);
		theStage.show();
	}
	
	private ViewInactiveRequests() {
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theInactiveRequestsScene = new Scene(theRoot, width, height);
		
		theInactiveRequestsScene.getStylesheets().add(getClass().getResource("/css/guiInactiveRequests.css").toExternalForm());
		
		VBox.setVgrow(table, Priority.ALWAYS);
		
		label_title.setText("Inactive Requests");
		setupLabelUI(label_title, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_title.getStyleClass().add("title");
		
		setupButtonUI(button_Return, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		// Since both Staff and Admin have access to this view, we need to determine
		// which home-page to send the user back to when they click the "Return" button.
		// We can access the activeHomePage variable of 'DiscussionsMain' to determine this.
		button_Return.setOnAction((event) -> {
			if (applicationMain.DiscussionsMain.activeHomePage == 1) {
				guiAdminHome.ViewAdminHome.displayAdminHome(theStage, user);
			} else if (applicationMain.DiscussionsMain.activeHomePage == 2) {
				guiStaffHome.ViewStaffHome.displayStaffHome(theStage, user);
			}
		});
		button_Return.getStyleClass().add("bottom-button");
		
		theRoot.getChildren().addAll(label_title, table, button_Return);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
	
	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}
}