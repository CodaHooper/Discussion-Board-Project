package guiInactiveRequests;

import java.sql.SQLException;

import database.Database;
import entityClasses.Request;

public class ModelInactiveRequests {
	private static Database theDatabase = applicationMain.DiscussionsMain.database;
	
	public static void reopenRequest(Request req) throws SQLException {
		// Updates the items status field in the database to 'Pending'
		theDatabase.reopenRequest(req.getUUID());
	}
}