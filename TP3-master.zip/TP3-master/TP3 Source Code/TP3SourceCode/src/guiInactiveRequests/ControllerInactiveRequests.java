package guiInactiveRequests;

import java.sql.SQLException;

import entityClasses.Request;
import javafx.scene.control.TableView;

public class ControllerInactiveRequests {
	public static void handleReopen(Request req, TableView<Request> table) throws SQLException {
		if (req == null) {
			return;
		}
		
		// Calls the ModelInactiveRequests database method "reopenRequest" to update
		// the item in the database to reflect it's new "Pending" status.
		ModelInactiveRequests.reopenRequest(req);
		
		// Removes the request from the inactive list since it is now marked as "Pending"
		table.getItems().remove(req);
	}
}