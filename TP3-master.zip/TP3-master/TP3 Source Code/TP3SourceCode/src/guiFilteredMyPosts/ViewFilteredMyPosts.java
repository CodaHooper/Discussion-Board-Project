package guiFilteredMyPosts;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import database.Database;
import entityClasses.Post;
import entityClasses.PostsCollection;
import entityClasses.Reply;
import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ViewFilteredMyPosts {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of posts to the title, author, and actions columns
	private static TreeTableView<Object> postsTable;
	private static final Object LAZY = new Object();

	// Alerts for deletion confirmation and edit errors
	protected static Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
	protected static Alert alertEditError = new Alert(Alert.AlertType.ERROR);

	// Edit attributes
	protected static TextField postTitle;
	protected static TextArea postContent;

	// GUI Area 3: This area is used to enable the student to return to the student
	// home screen and the guiMyPosts screen
	protected static Button button_StudentHomeScreen = new Button("Return");
	protected static Button button_AllPosts = new Button("All Replies");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewFilteredMyPosts theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theFilteredMyPostsScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayFilteredMyPosts(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View Filtered My Posts page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * posts
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayFilteredMyPosts(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewFilteredMyPosts(); // Instantiate singleton if needed
		}

		// GUI Area 2
		PostsCollection pc = new PostsCollection(theDatabase, theUser.getUserName());
		List<Post> posts = pc.getMyPosts(user.getUserName());
		populatePosts(posts);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theFilteredMyPostsScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewFilteredMyPosts()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayFilteredMyPosts method.
	 * </p>
	 * 
	 */
	private ViewFilteredMyPosts() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theFilteredMyPostsScene = new Scene(theRoot, width, height);

		theFilteredMyPostsScene.getStylesheets().add(getClass().getResource("/css/guiFilteredMyPosts.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Discussions: My Posts (Unread Replies)");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		postsTable = buildPostsTable();

		// GUI Area 3
		setupButtonUI(button_StudentHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StudentHomeScreen.setOnAction((event) -> {
			guiStudentHome.ViewStudentHome.displayStudentHome(theStage, user);
		});
		button_StudentHomeScreen.getStyleClass().add("bottom-button");
		
		setupButtonUI(button_AllPosts, "Dialog", 16, 250, Pos.CENTER, 0, 0);
		button_AllPosts.setOnAction((event) -> {
			guiMyPosts.ViewMyPosts.displayMyPosts(theStage, user);
		});
		button_AllPosts.getStyleClass().add("bottom-button");

		// Make buttons go to the far left and right
		HBox buttons = new HBox(16);
		Button btnReturn = button_StudentHomeScreen;
		Button btnUnread = button_AllPosts;

		Region spacer = new Region();
		HBox.setHgrow(spacer, Priority.ALWAYS); 

		buttons.getChildren().addAll(btnReturn, spacer, btnUnread);
		buttons.setAlignment(Pos.CENTER);
		VBox.setMargin(buttons, new Insets(5, 5, 0, 5));
		
		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, postsTable, buttons);
	}

	/****
	 * <p>
	 * Method: TableView<Post> buildPostsTable()
	 * </p>
	 * 
	 * <p>
	 * Description: Creates and configures a TableView for displaying posts. It
	 * defines columns for title, author, and actions, and sets up the table’s
	 * appearance and behavior.
	 * </p>
	 * 
	 * @return a configured TableView for Post objects
	 */
	private TreeTableView<Object> buildPostsTable() {
		TreeItem<Object> root = new TreeItem<>();
		root.setExpanded(true);

		TreeTableView<Object> table = new TreeTableView<>(root);
		table.setPrefHeight(height - 100);
		table.setColumnResizePolicy(TreeTableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
		table.setShowRoot(false);

		TreeTableColumn<Object, String> colTitle = new TreeTableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String title = "";
			if (o instanceof Post p)
				title = p.getTitle();
			else if (o instanceof Reply r)
				title = r.getTitle();
			return new ReadOnlyStringWrapper(title);
		});
		colTitle.setPrefWidth(width * 0.50);

		TreeTableColumn<Object, String> colAuthor = new TreeTableColumn<>("Author");
		colAuthor.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String author = "";
			if (o instanceof Post p)
				author = p.getAuthor();
			else if (o instanceof Reply r)
				author = r.getAuthor();
			return new ReadOnlyStringWrapper(author);
		});
		colAuthor.setPrefWidth(width * 0.16);

		TreeTableColumn<Object, String> colReplyCount = new TreeTableColumn<>("Replies");
		colReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyCount()); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colReplyCount.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, String> colUnreadReplyCount = new TreeTableColumn<>("Unread Replies");
		colUnreadReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyUnread(theDatabase, user.getUserName())); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colUnreadReplyCount.setPrefWidth(width * 0.10);

		TreeTableColumn<Object, String> colRead = new TreeTableColumn<>("Read");
		colRead.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = p.getIsRead(); // only meaningful for posts/replies
			else if (o instanceof Reply r)
				v = r.getIsRead();
			return new ReadOnlyStringWrapper(v);
		});
		colRead.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, Object> colActions = new TreeTableColumn<>("Actions");
		colActions.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		colActions.setCellFactory(col -> new TreeTableCell<Object, Object>() {
			private final MenuItem openItem = new MenuItem("Open Post");
			private final MenuItem editItem = new MenuItem("Edit Post");
			private final MenuItem deleteItem = new MenuItem("Delete Post");
			private final MenuItem viewScoreItem = new MenuItem("View Score");
			private final MenuButton menu = new MenuButton("⋮", null, openItem);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

				openItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) {
						ModelFilteredMyPosts.setReadDB(p.getPostID(), user.getUserName());
						ControllerFilteredMyPosts.doOpenPost(p);
					}

					else if (o instanceof Reply r) {
						ModelFilteredMyPosts.setReadDB(r.getPostID(), user.getUserName());
						ControllerFilteredMyPosts.doOpenReply(r);
					}
				});

				editItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) {
						ControllerFilteredMyPosts.doOpenEditPost(p);
					}
				});

				deleteItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) {
						if (ControllerFilteredMyPosts.deletePostButton(p)) {
							TreeItem<Object> currentItem = getTreeTableView().getTreeItem(getIndex());
							getTreeTableView().getRoot().getChildren().remove(currentItem);
							new Alert(Alert.AlertType.INFORMATION, "Post deleted.").showAndWait();
						} else
							new Alert(Alert.AlertType.ERROR, "Failed to delete post.").showAndWait();
					}
				});
				
				viewScoreItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) {
						showScoreDialog(p.getAuthor(), p.getPostID());
					}
					if (o instanceof Reply r) 
						showScoreDialog(r.getAuthor(), r.getPostID());
				});
			}

			@Override
			protected void updateItem(Object item, boolean empty) {
				super.updateItem(item, empty);
				if (empty) {
					setGraphic(empty ? null : menu);
					return;
				}

				Object v = getTreeTableView().getTreeItem(getIndex()).getValue();

				// reset menu items per row
				menu.getItems().setAll(openItem);
				if (v instanceof Post) {
					menu.getItems().addAll(editItem, deleteItem);
				}
				if (v instanceof Post || v instanceof Reply) {
					menu.getItems().addAll(viewScoreItem);
				}
				setGraphic(menu);
			}
		});
		colActions.setPrefWidth(width * 0.10);
		colActions.setSortable(false);

		table.getColumns().addAll(colTitle, colAuthor, colReplyCount, colUnreadReplyCount, colRead, colActions);
		return table;
	}

	/****
	 * <p>
	 * Method: void populatePosts(List<Post> posts)
	 * </p>
	 * 
	 * <p>
	 * Description: Populates the posts table with a list of Post objects. It first
	 * clears existing rows and then adds the provided posts.
	 * </p>
	 * 
	 * @param posts a list of Posts objects to display in the table
	 */
	protected static void populatePosts(List<Post> posts) {
		if (postsTable == null)
			return;

		postsTable.getRoot().getChildren().clear();
		if (posts == null || posts.isEmpty())
			return;

		for (Post p : posts) {
			TreeItem<Object> postItem = new TreeItem<>((Object) p);

			// Make expandable only if the post has replies
			if (p.getReplyCount() > 0) {
				postItem.getChildren().add(new TreeItem<>(LAZY));
			}

			// Lazy load replies the first time it is expanded
			postItem.expandedProperty().addListener((obs, was, is) -> {
				if (!is)
					return;
				if (postItem.getChildren().size() == 1 && postItem.getChildren().get(0).getValue() == LAZY) {
					postItem.getChildren().clear();
					addRepliesRecursively(postItem, p.getPostID());
				}
			});

			postsTable.getRoot().getChildren().add(postItem);
		}
	}

	/****
	 * <p>
	 * Method: void addRepliesRecursively(TreeItem<Object> parentItem, int
	 * parentPostID)
	 * </p>
	 * 
	 * <p>
	 * Description: Recursively adds every reply under a parent post
	 * </p>
	 * 
	 * @param posts a list of Posts objects to display in the table
	 */
	private static void addRepliesRecursively(TreeItem<Object> parentItem, int parentPostID) {
		List<Reply> replies = ModelFilteredMyPosts.getUnreadPostReplies(parentPostID, user.getUserName());
		for (Reply r : replies) {
			TreeItem<Object> child = new TreeItem<>((Object) r);
			parentItem.getChildren().add(child);
			addRepliesRecursively(child, r.getPostID());
		}
	}

	/****
	 * <p>
	 * Method: void openPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a post. The
	 * post includes a title and content input area.
	 * </p>
	 * 
	 * @param p the Post object where the post will be created
	 * 
	 */
	protected static void openPost(Post p) {
		Stage dialog = new Stage();
		dialog.setTitle("Post");
		Label title = new Label(p.getTitle() == null || p.getTitle().isBlank() ? "(untitled)" : p.getTitle());
		Label author = new Label("By: " + p.getAuthor());

		TextArea content = new TextArea(p.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openReply(Reply r)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a reply. The
	 * reply includes a title and content input area.
	 * </p>
	 * 
	 * @param r the Reply object where the reply will be created
	 * 
	 */
	protected static void openReply(Reply r) {
		Stage dialog = new Stage();
		dialog.setTitle("Reply");
		Label title = new Label(r.getTitle() == null || r.getTitle().isBlank() ? "(untitled)" : r.getTitle());
		Label author = new Label("By: " + r.getAuthor());

		TextArea content = new TextArea(r.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openEditPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to edit a post's
	 * title and content.
	 * </p>
	 * 
	 * @param p the Post object where the post will be created
	 * 
	 */
	protected static void openEditPost(Post p) {
		Stage dialog = new Stage();
		dialog.setTitle("Edit Post");

		Label titleLabel = new Label("Title:");
		postTitle = new TextField(p.getTitle());

		Label contentLabel = new Label("Content:");
		postContent = new TextArea(p.getContent());
		postContent.setWrapText(true);
		postContent.setPrefRowCount(12);

		Button saveBtn = new Button("Save");
		saveBtn.setOnAction(e -> {
			String title = postTitle.getText().trim();
			String content = postContent.getText().trim();
			if (ControllerFilteredMyPosts.editPostLogic(title, content, p)) {
				// Update the in-memory object so the table shows the changes
				p.setTitle(title);
				p.setContent(content);
				// Refresh table
				postsTable.refresh();
				new Alert(Alert.AlertType.INFORMATION, "Post updated.").showAndWait();
				dialog.close();
			} else
				new Alert(Alert.AlertType.ERROR, "Failed to update post.").showAndWait();
		});

		Button cancelBtn = new Button("Cancel");
		cancelBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, titleLabel, postTitle, contentLabel, postContent, new HBox(10, saveBtn, cancelBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 500);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}
	
	/****
	 * <p>
	 * Method: showScoreDialog()
	 * </p>
	 * 
	 * <p>
	 * Description: Displays the grade a post received.
	 * </p>
	 */
	private static void showScoreDialog(String author, int postID) {
		if (!author.equals(user.getUserName())) {
			Alert err = new Alert(Alert.AlertType.ERROR);
			err.setHeaderText("Error");
			err.setContentText("You do not have access to this post's score.");
			err.showAndWait();
			return;
		}
		
	    try {
	        Map<String, Object> score = theDatabase.readScore(author, postID);
	
	        String msg;
	        if (score == null) {
	            msg = "No score has been recorded yet for this post.";
	        } else {
	        	Timestamp ts = (Timestamp) score.get("gradedAt");
		        LocalDateTime dt = ts.toLocalDateTime();
		        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy 'at' hh:mm a");
		        String formattedTime = dt.format(formatter);
		        
	            msg = "Current score for " + author +
	                  " on this post: " + score.get("score") + " / 5\n\n" +
	                  "Graded by " + score.get("evaluator") + "\n" + 
	                  "On " + formattedTime;
	        }

	        Alert a = new Alert(Alert.AlertType.INFORMATION);
	        a.setHeaderText("Post Score");
	        a.setContentText(msg);
	        a.showAndWait();

	    } catch (Exception e) {
	        Alert err = new Alert(Alert.AlertType.ERROR);
	        err.setHeaderText("Error");
	        err.setContentText("Failed to read score: " + e.getMessage());
	        err.showAndWait();
	    }
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}	
}
