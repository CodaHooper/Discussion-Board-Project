package guiFilteredMyPosts;

import entityClasses.Post;
import entityClasses.Reply;
import guiMyPosts.ModelMyPosts;
import guiMyPosts.ViewMyPosts;
import javafx.scene.control.ButtonType;

public class ControllerFilteredMyPosts {

	/**********
	 * <p>
	 * Method: doOpenPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a view of the specified Post.
	 * </p>
	 * 
	 * @param p The Post object to display
	 */
	protected static void doOpenPost(Post p) {
		if (p != null)
			ViewFilteredMyPosts.openPost(p);
	}
	
	/**********
	 * <p>
	 * Method: doOpenReply(Reply r)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a view of the specified Reply.
	 * </p>
	 * 
	 * @param r The Reply object to display
	 */
	protected static void doOpenReply(Reply r) {
		if (r != null)
			ViewFilteredMyPosts.openReply(r);
	}
	
	/**********
	 * <p>
	 * Method: doOpenEditPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens the interface to update a specified Post.
	 * </p>
	 * 
	 * @param p The Post object to edit
	 */
	protected static void doOpenEditPost(Post p) {
		if (p != null)
			ViewFilteredMyPosts.openEditPost(p);
	}
	
	/**********
	 * <p>
	 * Method: deletePostButton(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Prompt a user to confirm they want to delete the specified post.
	 * If the user confirms, the post's status is updated to deleted in the
	 * database.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * 
	 * @param p The Post object to delete
	 * 
	 * @return true if deletion was successful, false otherwise
	 */
	protected static boolean deletePostButton(Post p) {
		if (p == null)
			return false;

		ViewFilteredMyPosts.confirm.setContentText("Are you sure you want to delete this Post?");
		ViewFilteredMyPosts.confirm.setHeaderText("Confirm Delete");
		if (ViewFilteredMyPosts.confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
			return ModelFilteredMyPosts.deletePostDB(p);
		}
		return false;
	}
	
	/**********
	 * <p>
	 * Method: editPostLogic(String title, String content, Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Validates input for updating a post in the database. Posts must
	 * not have empty fields and are held to length constraints. Displays error
	 * message if validation fails.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param title   The new title for the post
	 * @param content The new body for the post
	 * @param p       The Post to update
	 * @return true if the post was successfully updated, otherwise false
	 */
	protected static boolean editPostLogic(String title, String content, Post p) {
		if (title.isEmpty()) { // Post title cannot be empty.
			ViewFilteredMyPosts.postTitle.setText(p.getTitle());
			ViewFilteredMyPosts.postContent.setText(p.getContent());
			ViewFilteredMyPosts.alertEditError.setContentText("Post title cannot be empty.");
			ViewFilteredMyPosts.alertEditError.showAndWait();
			return false;
		} else if (content.isEmpty()) { // Post body cannot be empty.
			ViewFilteredMyPosts.postTitle.setText(p.getTitle());
			ViewFilteredMyPosts.postContent.setText(p.getContent());
			ViewFilteredMyPosts.alertEditError.setContentText("Post body cannot be empty.");
			ViewFilteredMyPosts.alertEditError.showAndWait();
			return false;
		} else if (title.length() > 200) { // Post title cannot exceed 200 characters
			ViewFilteredMyPosts.postTitle.setText(p.getTitle());
			ViewFilteredMyPosts.postContent.setText(p.getContent());
			ViewFilteredMyPosts.alertEditError.setContentText("Post title cannot exceed 200 characters.");
			ViewFilteredMyPosts.alertEditError.showAndWait();
			return false;
		} else if (content.length() > 10000) { // Post body cannot exceed 10,000 characters. 
			ViewFilteredMyPosts.postTitle.setText(p.getTitle());
			ViewFilteredMyPosts.postContent.setText(p.getContent());
			ViewFilteredMyPosts.alertEditError.setContentText("Post body cannot exceed 10,000 characters.");
			ViewFilteredMyPosts.alertEditError.showAndWait();
			return false;
		} else {
			return ModelFilteredMyPosts.editPostDB(title, content, p);
		}
	}
}
