package entityClasses;

import java.sql.SQLException;
import java.util.List;

import database.Database;

/*******
 * <p>
 * Title: Post Class
 * </p>
 * 
 * <p>
 * Description: This post class represents an individual post in the system. It
 * contains the post's details such as post id, thread id, author, title,
 * content, and whether or not the post is deleted.
 * </p>
 * 
 */
public class Post {
	// These are the private attributes for this entity object
	private final int postID;
	private final int threadID;
	private final String author;
	private String title;
	private String content;
	private boolean isDeleted;
	private int replyCount;
	private boolean isRead;

	/**
	 * <p>
	 * Method: Post(int postID, int threadID, String author, String title, String
	 * content, boolean isDeleted)
	 * </p>
	 * 
	 * @param postID     is the postID of the post instance
	 * 
	 * @param threadID   is the threadID of the thread the post instance is under
	 * 
	 * @param author     is the author of the post instance
	 * 
	 * @param title      is the title of the post instance
	 * 
	 * @param content    is the contents of the post instance
	 * 
	 * @param isDeleted  is true if the post is soft-deleted
	 * 
	 * @param replyCount is the number of replies to a given post
	 * 
	 * @param isRead     is true is this post has already been read
	 */
	// Constructor to initialize a new Post object with postID, threadID,
	// author, title, content, and isDeleted attributes
	public Post(int postID, int threadID, String author, String title, String content, boolean isDeleted,
			int replyCount, boolean isRead) {
		this.postID = postID;
		this.threadID = threadID;
		this.author = author;
		this.title = title;
		this.content = content;
		this.isDeleted = isDeleted;
		this.replyCount = replyCount;
		this.isRead = isRead;
	}

	// Getter methods

	/****
	 * <p>
	 * Method: int getPostID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the postID.
	 * </p>
	 * 
	 * @return the ID number of the post
	 */
	public int getPostID() {
		return this.postID;
	}

	/****
	 * <p>
	 * Method: int getThreadID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the threadID.
	 * </p>
	 * 
	 * @return the ID number of the thread
	 */
	public int getThreadID() {
		return this.threadID;
	}

	/****
	 * <p>
	 * Method: String getAuthor()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the author of the post.
	 * </p>
	 * 
	 * @return a String containing the author’s username
	 */
	public String getAuthor() {
		return this.author;
	}

	/****
	 * <p>
	 * Method: String getTitle()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the title of the post.
	 * </p>
	 * 
	 * @return a String containing the title
	 */
	public String getTitle() {
		return this.title;
	}

	/****
	 * <p>
	 * Method: String getContent()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the content of the post.
	 * </p>
	 * 
	 * @return a String containing the post content
	 */
	public String getContent() {
		return this.content;
	}

	/****
	 * <p>
	 * Method: boolean getIsDeleted()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns whether the post is deleted.
	 * </p>
	 * 
	 * @return true if the post is deleted, false otherwise
	 */
	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	/****
	 * <p>
	 * Method: int getReplyCount()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the number of replies under a post
	 * </p>
	 * 
	 * @return number of replies under a post
	 */
	public int getReplyCount() {
		return this.replyCount;
	}

	/****
	 * <p>
	 * Method: String getIsRead(String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns whether or not a post is read or not
	 * </p>
	 * 
	 * @return a message indicating read status
	 */
	public String getIsRead() {
		// used later to determine whether or not to show this post in a user's feed
		if (this.isRead)
			return "Read";
		else
			return "Unread";
	}

	/****
	 * <p>
	 * Method: int getReplyUnread(Database db, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the number of unread replies under a post by
	 * iterating through each reply and checking if it has been read or not
	 * </p>
	 * 
	 * @return number of unread replies
	 */
	public int getReplyUnread(Database db, String username) {
		List<Reply> replies;
		int count = 0;
		try {
			replies = db.getRepliesForPost(this.postID, username);
			for (Reply reply : replies) {
				// for every reply
				if (!reply.getIsRead().equals("Read")) {
					// check to see if the reply is read
					count++;
					// and increment the unread counter.
				}
			}
			return count;
		} catch (SQLException e) {
			// error loading post from DB
			e.printStackTrace();
		}
		return count;
	}

	// Setter methods

	/****
	 * <p>
	 * Method: void setTitle(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the title of the post.
	 * </p>
	 * 
	 * @param title the new title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/****
	 * <p>
	 * Method: void setContent(String content)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the content of the post.
	 * </p>
	 * 
	 * @param content the new content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/****
	 * <p>
	 * Method: void setIsDeleted(boolean isDeleted)
	 * </p>
	 * 
	 * <p>
	 * </p>
	 * Description: This setter sets whether or not the post should be marked as
	 * deleted. This has no effect on the replies allowing them to still be read.
	 * 
	 * @param isDeleted true if the post is deleted, false otherwise
	 */
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
