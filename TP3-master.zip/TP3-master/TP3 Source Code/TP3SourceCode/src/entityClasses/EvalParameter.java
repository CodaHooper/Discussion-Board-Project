package entityClasses;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

/*******
 * <p>
 * Title: EvalParameter Class
 * </p>
 * 
 * <p>
 * Description: This Evaluation Parameter class represents a category staff
 * members may use to grade a submission. It contains the Evaluation Parameter
 * details such as title and the description.
 * </p>
 * 
 * 
 */
public class EvalParameter {
	// These are the private attributes for this entity object

	/**
	 * The title of the evaluation parameter staff may use in their grading
	 */
	private String title;
	/**
	 * The longer and more accurate description of the evaluation parameter staff
	 * should use as they complete grading of a submission
	 */
	private String description;
  private IntegerProperty score; // this is for UI scoring
  
	/**
	 * <p>
	 * Method: EvalParameter(String title, String description)
	 * </p>
	 * 
	 * <p>
	 * Description: The constructor of an evaluation parameter. An evaluation
	 * parameter requires both a title and a description to be passed, both of which
	 * are stored in fields which can be accessed by a user or by the system at a
	 * later point.
	 * </p>
	 * 
	 * @param title       the main point or title of the evaluation parameter
	 * @param description the longer and more precise description of the evaluation
	 *                    parameter.
	 */
	public EvalParameter(String title, String description) {
		this.title = title;
		this.description = description;
		this.score = new SimpleIntegerProperty(0);
	}

	/**
	 * <p>
	 * Method: String getTitle()
	 * </p>
	 * 
	 * <p>
	 * Returns the title/short description of the evaluation parameter
	 * </p>
	 * 
	 * @return the title/short description of the evaluation parameter
	 */
	public String getTitle() {
		return this.title;
	}

	/**
	 * <p>
	 * Method: String getDescription()
	 * </p>
	 * 
	 * <p>
	 * Returns the longer description of the evaluation parameter
	 * </p>
	 * 
	 * @return the longer description of the evaluation parameter
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * <p>
	 * Method: void setTitle(String title)
	 * </p>
	 * 
	 * <p>
	 * Updates the title/short description of the evaluation parameter to the
	 * provided title
	 * </p>
	 * 
	 * @param title the new title/short description of the evaluation parameter to
	 *              be set
	 * 
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * <p>
	 * Method: void setDescription(String description)
	 * </p>
	 * 
	 * <p>
	 * Updates the longer description of the evaluation parameter to the provided
	 * description
	 * </p>
	 * 
	 * @param description the description of the evaluation parameter to be set
	 * 
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	public int getScore() {return score.get();}
	
	public IntegerProperty scoreProperty() {return score;}
	
	public void setScore(int s) {score.set(s);}
}
