package entityClasses;

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.sql.*;
import database.Database;

/**
 * <p>
 * Title: ThreadsCollection Class
 * </p>
 * 
 * <p>
 * Description: The ThreadsCollection class manages a list of Thread objects
 * within the system. It serves as a container that retrieves, stores, and
 * provides access to all post thread instances from the database. The class
 * supports loading threads into the collection, refreshing the collection, and
 * providing access to the current list of Thread objects.
 * </p>
 */
public class ThreadsCollection {

	private List<Thread> threads;
	private Database db;

	/****
	 * <p>
	 * Method: ThreadsCollection(Database db)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor that initializes the ThreadsCollection object. It
	 * connects the collection to a Database instance and automatically loads all
	 * existing threads.
	 * </p>
	 * 
	 * @param db the Database object used to retrieve thread data
	 */
	public ThreadsCollection(Database db) {
		this.threads = new ArrayList<>();
		this.db = db;
		loadAll();
	}

	/****
	 * <p>
	 * Method: void loadAll()
	 * </p>
	 * 
	 * <p>
	 * Description: Loads all threads from the database into the threads list. This
	 * method clears the current list before reloading data to prevent duplicates.
	 * </p>
	 */
	public void loadAll() {
		try {
			threads.clear(); // clear list in-case of reload
			List<Map<String, Object>> threadsInfo = db.fetchAllThreads();
			for (Map<String, Object> threadInfo : threadsInfo) {
				Thread thread = new Thread((int) threadInfo.get("threadID"), (String) threadInfo.get("author"),
						(String) threadInfo.get("title"), (String) threadInfo.get("content"));
				threads.add(thread);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/****
	 * <p>
	 * Method: {@code List<Thread> getThreads()}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Thread objects currently loaded in the
	 * ThreadsCollection.
	 * </p>
	 * 
	 * @return a list of Thread objects
	 */
	public List<Thread> getThreads() {
		return threads;
	}

	/****
	 * <p>
	 * Method: {@code List<Thread> getThreadsForPosts(List<Post> posts)}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Thread objects that the posts are under.
	 * </p>
	 * 
	 * @return a list of Thread objects
	 */
	public List<Thread> getThreadsForPosts(List<Post> posts) {
		if (posts == null || posts.isEmpty())
			return new ArrayList<>();

		// Get unique thread IDs
		Set<Integer> matchedThreadIDs = new HashSet<>();
		for (Post p : posts) {
			matchedThreadIDs.add(p.getThreadID());
		}

		// Return the thread IDs that are in the set
		List<Thread> result = new ArrayList<>();
		for (Thread t : threads) {
			if (matchedThreadIDs.contains(t.getThreadID())) {
				result.add(t);
			}
		}
		return result;
	}
}
