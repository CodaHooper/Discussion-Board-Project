package entityClasses;

/**
 * 
 * <p>The Request class represents a single request that a Staff member
 * makes for an Admin to perform. It contains the author of the request,
 * the title of the request, and the description of the request.</p>
 * 
 */
public class Request {
	/** <p>The user who created the request.</p> */
	private String author;
	
	/** <p>The title of the request.</p> */
	private String title;
	
	/** <p>The description of the request</p> */
	private String description;
	
	/** <p>The unique identifier of the request.</p> */
	private String uuid;
	
	/** <p>A string value to indicate the status of the request: "Incomplete", "Complete", "Denied".</p> */
	private String status;
	
	/**
	 * 
	 * <p>This constructor is used to create a new Request object</p>
	 * 
	 * @param a The author of the request.
	 * @param t The title of the request.
	 * @param d The description of the request.
	 * @param s The status of the request.
	 */
	public Request(String a, String t, String d, String u, String s) {
		this.author = a;
		this.title = t;
		this.description = d;
		this.uuid = u;
		this.status = s;
	}
	
	/**
	 * 
	 * <p>This method gives you the author of the request.</p>
	 * 
	 * @return a User object representing the author of the request.
	 */
	public String getAuthor() {
		return author;
	}
	
	/**
	 * 
	 * <p>This method gives you the title of the request.</p>
	 * 
	 * @return a String object representing the title of the request.
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * 
	 * <p>This method gives you the description of the request.</p>
	 * 
	 * @return a String object representing the description of the request.
	 */
	public String getDescription() {
		return description;
	}
	
	/**
	 * 
	 * <p>This method gives you the unique identifier of the request.</p>
	 * 
	 * @return a String object representing the unique identifier of the request.
	 */
	public String getUUID() {
		return uuid.toString();
	}
	
	/**
	 * 
	 * <p>This method gives you the status value of the request.</p>
	 * 
	 * @return a String value representing the status of the request (Incomplete, Complete, or Denied).
	 */
	public String getStatus() {
		return status;
	}
}