package entityClasses;

/*******
 * <p>
 * Title: Reply Class
 * </p>
 * 
 * <p>
 * Description: This reply class represents a reply to a post or a reply to
 * another reply in the system. It contains the reply's details such as reply
 * id, thread id, parent id, author, title, content, and whether or not the
 * reply is deleted.
 * </p>
 * 
 */
public class Reply {
	// These are the private attributes for this entity object
	private final int postID;
	private final int threadID;
	private final Integer parentID;
	private final String author;
	private String title;
	private String content;
	private boolean isDeleted;
	private boolean isRead;

	/****
	 * <p>
	 * Method: Reply(int postID, int threadID, int parentID, String author, String
	 * title, String content, boolean isDeleted)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor to initialize a new Reply object with postID,
	 * threadID, parentID, title, author, content, and isDeleted status.
	 * </p>
	 * 
	 * @param postID    is the unique ID of the reply instance
	 * 
	 * @param threadID  is the threadID under which the reply was made
	 * 
	 * @param parentID  is the postID of the parent post or reply
	 * 
	 * @param author    is the username of the reply’s author
	 * 
	 * @param title     is the title/subject of the reply
	 * 
	 * @param content   is the text content of the reply
	 * 
	 * @param isDeleted is true if the reply is soft-deleted
	 * 
	 * @param isRead    is true is this reply has already been read
	 */
	public Reply(int postID, int threadID, Integer parentID, String author, String title, String content,
			boolean isDeleted, boolean isRead) {
		this.postID = postID;
		this.threadID = threadID;
		this.parentID = parentID;
		this.author = author;
		this.title = title;
		this.content = content;
		this.isDeleted = false;
		this.isRead = isRead;
	}

	// Getter methods

	/****
	 * <p>
	 * Method: int getPostID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the postID of the reply.
	 * </p>
	 * 
	 * @return the ID number of the reply
	 */
	public int getPostID() {
		return this.postID;
	}

	/****
	 * <p>
	 * Method: int getThreadID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the threadID of the reply.
	 * </p>
	 * 
	 * @return the ID number of the thread the reply belongs to
	 */
	public int getThreadID() {
		return this.threadID;
	}

	/****
	 * <p>
	 * Method: int getParentID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the parentID of the reply.
	 * </p>
	 * 
	 * @return the ID number of the parent post or reply
	 */
	public Integer getParentID() {
		return this.parentID;
	}

	/****
	 * <p>
	 * Method: int getTitle()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the title of the reply.
	 * </p>
	 * 
	 * @return the title of the reply
	 */
	public String getTitle() {
		return this.title;
	}

	/****
	 * <p>
	 * Method: String getAuthor()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the author of the reply.
	 * </p>
	 * 
	 * @return a String containing the author’s username
	 */
	public String getAuthor() {
		return this.author;
	}

	/****
	 * <p>
	 * Method: String getContent()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the content of the reply.
	 * </p>
	 * 
	 * @return a String containing the reply content
	 */
	public String getContent() {
		return this.content;
	}

	/****
	 * <p>
	 * Method: boolean getIsDeleted()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns whether the reply is deleted.
	 * </p>
	 * 
	 * @return true if the reply is deleted, false otherwise
	 */
	public boolean getIsDeleted() {
		return this.isDeleted;
	}

	/****
	 * <p>
	 * Method: String getIsRead()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns whether the reply is read.
	 * </p>
	 * 
	 * @return a string of "Read" if true and "Unread" if not true
	 */
	public String getIsRead() {
		if (this.isRead)
			return "Read";
		return "Unread";
	}

	// Setter methods

	/****
	 * <p>
	 * Method: void setTitle(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the title of the reply.
	 * </p>
	 * 
	 * @param title the new title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/****
	 * <p>
	 * Method: void setContent(String content)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the content of the reply.
	 * </p>
	 * 
	 * @param content the new content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}

	/****
	 * <p>
	 * Method: void setIsDeleted(boolean isDeleted)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the deletion status of the reply.
	 * </p>
	 * 
	 * @param isDeleted true if the reply is deleted, false otherwise
	 */
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}
}
