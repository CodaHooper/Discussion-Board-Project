package entityClasses;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import database.Database;

/**
 * <p>
 * Title: EvalParametersCollection Class
 * </p>
 * 
 * <p>
 * Description: The EvalParametersCollection class manages a list of Evaluation
 * Parameter objects within the system. It serves as a container that retrieves,
 * stores, and provides access to all evaluation parameter instances from the
 * database. The class supports loading parameters into the collection,
 * refreshing the collection, and providing access to the current list of
 * Evaluation Parameter objects.
 * </p>
 */
public class EvalParametersCollection {

	private List<EvalParameter> evalParameters;
	private Database db;

	/****
	 * <p>
	 * Method: EvalParametersCollection(Database db)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor that initializes the EvalParametersCollection
	 * object. It connects the collection to a Database instance and automatically
	 * loads all existing evaluation parameters.
	 * </p>
	 * 
	 * @param db the Database object used to retrieve thread data
	 */
	public EvalParametersCollection(Database db) {
		this.evalParameters = new ArrayList<>();
		this.db = db;
		loadAll();
	}

	/****
	 * <p>
	 * Method: void loadAll()
	 * </p>
	 * 
	 * <p>
	 * Description: Loads all evaluation parameters from the database into the
	 * evaluation parameters collection. This method clears the current list before
	 * reloading data to prevent duplicates.
	 * </p>
	 */
	public void loadAll() {
		try {
			evalParameters.clear(); // clear list in-case of reload
			List<Map<String, Object>> evalParametersInfo = db.fetchAllParameters();
			for (Map<String, Object> evalParameterInfo : evalParametersInfo) {
				EvalParameter evalParameter = new EvalParameter((String) evalParameterInfo.get("title"),
						(String) evalParameterInfo.get("description"));

				evalParameters.add(evalParameter);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/****
	 * <p>
	 * Method: {@code List<EvalParameter> getEvalParameters() }
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of evaluation parameter objects currently
	 * loaded in the EvalParametersCollection.
	 * </p>
	 * 
	 * @return a list of EvalParameter objects
	 */
	public List<EvalParameter> getEvalParameters() {
		return evalParameters;
	}
}
