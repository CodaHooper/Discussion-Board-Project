package entityClasses;

import java.time.LocalDateTime;

/*******
 * <p>
 * Title: Invitation Class
 * </p>
 * 
 * <p>
 * Description: This Invitation class represents a user invitation in the
 * system. It contains the invitation's details such as emailAddress, code,
 * expirationDate, and role being invited.
 * </p>
 * 
 * 
 */
public class Invitation {

	// These are the private attributes for this entity object
	private final String emailAddress;
	private final String code;
	private final String role;
	private final LocalDateTime expirationDate;

	/**
	 * <p>
	 * Method: Invitation(String email, String code, String role, LocalDateTime
	 * expirationDate)
	 * </p>
	 * 
	 * @param email          specifies the email address associated with the
	 *                       invitation
	 * @param code           specifies the code with which the user is invited to
	 *                       claim their account with
	 * @param role           specifies the role with which the account was invited
	 *                       to the system with
	 * @param expirationDate specifies the expiration date after which the
	 *                       invitation will no longer be valid
	 */
	// Constructor to initialize a new Invitation object with email, code,
	// expiration date, and role.
	public Invitation(String email, String code, String role, LocalDateTime expirationDate) {
		this.emailAddress = email;
		this.code = code;
		this.role = role;
		this.expirationDate = expirationDate;
	}

	/*****
	 * <p>
	 * Method: String getEmailAddress()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the EmailAddress.
	 * </p>
	 * 
	 * @return a String of the email address
	 *
	 */
	// Gets the current value of the EmailAddress.
	public String getEmailAddress() {
		return emailAddress;
	}

	/*****
	 * <p>
	 * Method: String getCode()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the invitation Code.
	 * </p>
	 * 
	 * @return a String of the invitation Code
	 *
	 */
	// Gets the current value of the invitation Code
	public String getCode() {
		return code;
	}

	/*****
	 * <p>
	 * Method: String getRole()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the invited role
	 * </p>
	 * 
	 * @return a String of the invited role
	 *
	 */
	// Gets the current value of the invited role
	public String getRole() {
		return role;
	}

	/*****
	 * <p>
	 * Method: String getExpirationDate()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the invite code expiration date
	 * </p>
	 * 
	 * @return a LocalDateTime of the invite code expiration date
	 *
	 */
	// Gets the current value of the invite code expiration date
	public LocalDateTime getExpirationDate() {
		return expirationDate;
	}
}
