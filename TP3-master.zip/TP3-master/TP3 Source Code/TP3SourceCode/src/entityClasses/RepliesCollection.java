package entityClasses;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.sql.*;
import database.Database;

/**
 * <p>
 * Title: RepliesCollection Class
 * </p>
 * 
 * <p>
 * Description: The RepliesCollection class manages a list of Reply objects
 * within the system. It serves as a container that retrieves, stores, and
 * provides access to all reply instances from the database. The class supports
 * loading all replies, refreshing the collection, and providing access to the
 * current list of Reply objects.
 * </p>
 */
public class RepliesCollection {
	private List<Reply> replies;
	private String username;
	private Database db;

	/****
	 * <p>
	 * Method: RepliesCollection(Database db)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor that initializes the RepliesCollection object. It
	 * connects the collection to a Database instance and automatically loads all
	 * existing replies.
	 * </p>
	 * 
	 * @param db the Database object used to retrieve reply data
	 */
	public RepliesCollection(Database db, String username) {
		this.replies = new ArrayList<>();
		this.username = username;
		this.db = db;
		loadAll();
	}

	/****
	 * <p>
	 * Method: void loadAll()
	 * </p>
	 * 
	 * <p>
	 * Description: Loads all replies from the database into the replies list. This
	 * method clears the current list before reloading data to prevent duplicates.
	 * </p>
	 */
	public void loadAll() {
		try {
			replies.clear(); // clear list in-case of reload
			List<Map<String, Object>> repliesInfo = db.fetchAllPosts();
			Integer parentID;
			int replyID;
			for (Map<String, Object> replyInfo : repliesInfo) {
				parentID = (Integer) replyInfo.get("parentID");
				if (parentID != null) {
					replyID = (int) replyInfo.get("postID");
					Reply reply = new Reply(replyID, (int) replyInfo.get("threadID"), parentID,
							(String) replyInfo.get("author"), (String) replyInfo.get("title"),
							(String) replyInfo.get("content"), (boolean) replyInfo.get("isDeleted"),
							(boolean) db.isAPostRead(replyID, this.username));
					replies.add(reply);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/****
	 * <p>
	 * Method: {@code List<Reply> getReplies()}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Reply objects currently loaded in the
	 * RepliesCollection.
	 * </p>
	 * 
	 * @return a list of Reply objects
	 */
	public List<Reply> getReplies() {
		return replies;
	}
}
