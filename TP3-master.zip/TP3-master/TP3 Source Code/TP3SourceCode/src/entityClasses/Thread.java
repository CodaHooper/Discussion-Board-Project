package entityClasses;

/*******
 * <p>
 * Title: Thread Class
 * </p>
 * 
 * <p>
 * Description: This thread class represents an individual thread in the system.
 * It contains the thread's details such as thread id, author, title, and
 * content.
 * </p>
 * 
 */
public class Thread {
	// These are the private attributes for this entity object
	private final int threadID;
	private final String author;
	private String title;
	private String content;

	/****
	 * <p>
	 * Method: Thread(int threadID, String author, String title, String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor to initialize a new Thread object with its ID,
	 * author, title, and content.
	 * </p>
	 * 
	 * @param threadID is the unique ID of the thread
	 * 
	 * @param author   is the username of the thread’s author
	 * 
	 * @param title    is the title of the thread
	 * 
	 * @param content  is the main body of the thread
	 */
	public Thread(int threadID, String author, String title, String content) {
		this.threadID = threadID;
		this.author = author;
		this.title = title;
		this.content = content;
	}

	// Getter methods

	/****
	 * <p>
	 * Method: int getThreadID()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the threadID of the thread.
	 * </p>
	 * 
	 * @return the unique ID number of the thread
	 */
	public int getThreadID() {
		return this.threadID;
	}

	/****
	 * <p>
	 * Method: String getAuthor()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the author of the thread.
	 * </p>
	 * 
	 * @return a String containing the author’s username
	 */
	public String getAuthor() {
		return this.author;
	}

	/****
	 * <p>
	 * Method: String getTitle()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the title of the thread.
	 * </p>
	 * 
	 * @return a String containing the thread title
	 */
	public String getTitle() {
		return this.title;
	}

	/****
	 * <p>
	 * Method: String getContent()
	 * </p>
	 * 
	 * <p>
	 * Description: This getter returns the content of the thread.
	 * </p>
	 * 
	 * @return a String containing the thread’s content
	 */
	public String getContent() {
		return this.content;
	}

	// Setter methods

	/****
	 * <p>
	 * Method: void setTitle(String title)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the title of the thread.
	 * </p>
	 * 
	 * @param title the new title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/****
	 * <p>
	 * Method: void setContent(String content)
	 * </p>
	 * 
	 * <p>
	 * Description: This setter updates the content of the thread.
	 * </p>
	 * 
	 * @param content the new content to set
	 */
	public void setContent(String content) {
		this.content = content;
	}
}