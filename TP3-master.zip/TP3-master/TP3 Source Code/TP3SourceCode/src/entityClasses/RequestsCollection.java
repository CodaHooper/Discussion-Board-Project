package entityClasses;

import java.util.ArrayList;

/**
 * 
 * <p>The RequestCollection class represents the list of Request objects
 * a Staff member can create to request Admin operations to be performed.</p>
 * 
 */
public class RequestsCollection {
	/** <p>A collection of Request objects that hold all requests in the system.</p> */
	public ArrayList<Request> ActiveRequests = new ArrayList<>();
	
	/** <p>The total number of active requests in the system.</p> */
	private int numberOfActiveRequests = 0;
	
	/**
	 * 
	 * <p>The default constructor for creating a RequestCollection object.</p>
	 * 
	 */
	public RequestsCollection() {
		
	}
	
	/**
	 * 
	 * <p>This method creates a new request and adds it to the requests list.</p>
	 * 
	 * @param user  	  The user who created the request.
	 * @param title 	  The title of the request.
	 * @param description The description of the request.
	 * @param uuid 	      The unique identifier of the request
	 */
	public void createRequest(String author, String title, String description, String uuid, String status) {
		// Create the request
		Request request = new Request(author, title, description, uuid, status);
			
		// Add it to the active requests lists
		ActiveRequests.add(request);
			
		// Increment the number of active requests to reflect the new request added.
		numberOfActiveRequests++;
	}
	
	/**
	 * 
	 * <p>This method removes a request object from the ActiveRequests list.</p>
	 * 
	 * @param uuid the uuid of the request to remove from the list.
	 */
	
	public void removeActiveRequest(String uuid) {
		int index = 0;
		
		// Find the index of the request by a given UUID
		for (int i = 0; i < ActiveRequests.size(); i++) {
			if (ActiveRequests.get(i).getUUID() == uuid) {
				index = i;
				break;
			} else {
				continue;
			}
		}
		
		// Remove the request
		ActiveRequests.remove(index);
		
		// Decrement the number of active requests to reflect the removed request.
		numberOfActiveRequests--;
	}
	
	/**
	 * 
	 * <p>This method gives you the number of active requests in the system.</p>
	 * 
	 * @return an integer object representing the number of active reqeusts in the system.
	 */
	public int getNumberOfActiveRequests() {
		return numberOfActiveRequests;
	}
}