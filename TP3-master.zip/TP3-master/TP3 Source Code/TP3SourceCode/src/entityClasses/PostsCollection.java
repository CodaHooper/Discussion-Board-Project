package entityClasses;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.sql.*;
import database.Database;

/**
 * <p>
 * Title: PostsCollection Class
 * </p>
 * 
 * <p>
 * Description: The PostsCollection class manages a list of Post objects within
 * the system. It acts as a container that retrieves, stores, and provides
 * access to all post instances from the database. The class supports loading
 * all posts, refreshing the collection, and providing access to the current
 * list of Post objects.
 * </p>
 */
public class PostsCollection {
	private List<Post> posts;
	private Database db;
	private String username;

	/****
	 * <p>
	 * Method: PostsCollection(Database db)
	 * </p>
	 * 
	 * <p>
	 * Description: Constructor that initializes the PostsCollection object. It
	 * connects the collection to a Database instance and automatically loads all
	 * existing posts.
	 * </p>
	 * 
	 * @param db the Database object used to retrieve post data
	 */
	public PostsCollection(Database db, String username) {
		this.posts = new ArrayList<>();
		this.db = db;
		this.username = username;
		loadAll();
	}

	/****
	 * <p>
	 * Method: void loadAll()
	 * </p>
	 * 
	 * <p>
	 * Description: Loads all posts from the database into the posts list. This
	 * method clears the current list before reloading data to prevent duplicates.
	 * </p>
	 */
	public void loadAll() {
		try {
			posts.clear(); // clear list in-case of reload
			List<Map<String, Object>> postsInfo = db.fetchAllPosts();
			int postID;
			Integer parentID;
			for (Map<String, Object> postInfo : postsInfo) {
				parentID = (Integer) postInfo.get("parentID");
				if (parentID == null) {
					postID = (int) postInfo.get("postID");
					Post post = new Post(postID, (int) postInfo.get("threadID"), (String) postInfo.get("author"),
							(String) postInfo.get("title"), (String) postInfo.get("content"),
							(boolean) postInfo.get("isDeleted"), (int) db.countReplies(postID),
							(boolean) db.isAPostRead(postID, this.username));
					posts.add(post);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/****
	 * <p>
	 * Method: {@code List<Post> getPosts()}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Post objects currently loaded in the
	 * PostsCollection.
	 * </p>
	 * 
	 * @return a list of Post objects
	 */
	public List<Post> getPosts() {
		return posts;
	}

	/****
	 * <p>
	 * Method: {@code List<Post> getMyPosts()}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Post objects the user authored.
	 * </p>
	 * 
	 * @return a list of Post objects
	 */
	public List<Post> getMyPosts(String author) {
		List<Post> myPosts = new ArrayList<Post>();
		for (Post post : posts) {
			if (author != null && author.equals(post.getAuthor())) {
				myPosts.add(post);
			}
		}
		return myPosts;
	}

	/****
	 * <p>
	 * Method: {@code List<Post> searchPosts(String keywords)}
	 * </p>
	 * 
	 * <p>
	 * Description: Returns the list of Post objects that contain the given
	 * keywords.
	 * </p>
	 * 
	 * @return a list of Post objects
	 */
	public List<Post> searchPosts(String keywords) {
		if (keywords.isEmpty()) {
			return getPosts();
		}

		List<Post> foundPosts = new ArrayList<Post>();
		for (Post post : posts) {
			if (post.getTitle().toLowerCase().contains(keywords.toLowerCase())
					|| post.getContent().toLowerCase().contains(keywords.toLowerCase())) {
				foundPosts.add(post);
			}
		}
		return foundPosts;
	}
}
