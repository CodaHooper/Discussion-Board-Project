package guiNewAccount;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import database.Database;
import entityClasses.User;

/*******
 * <p>
 * Title: ViewNewAccount Class.
 * </p>
 * 
 * <p>
 * Description: The ViewNewAccount Page is used to enable a potential user with
 * an invitation code to establish an account after they have specified an
 * invitation code on the standard login page.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2025
 * </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 1.00 2025-08-19 Initial version
 * 
 */

public class ViewNewAccount {

	/*-********************************************************************************************
	
	Attributes
	
	*/

	// These are the application values required by the user interface

	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// This is a simple GUI login Page, very similar to the FirstAdmin login page.
	// The only real difference is in this case we also know an email address, since
	// it was used to send the invitation to the potential user.
	private static Label label_ApplicationTitle = new Label("Discussions");
	protected static Label label_NewUserCreation = new Label("New User Account Creation");
	protected static Label label_NewUserLine = new Label("Enter a username and a password");
	protected static TextField text_Username = new TextField();
	protected static PasswordField text_Password1 = new PasswordField();
	protected static PasswordField text_Password2 = new PasswordField();
	protected static Button button_UserSetup = new Button("User Setup");
	protected static TextField text_Invitation = new TextField();

	protected static Alert alertUsernamePasswordError = new Alert(AlertType.INFORMATION);

	protected static Button button_Quit = new Button("Quit");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewNewAccount theView; // Is instantiation of the class needed?

	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static Pane theRootPane; // The Pane that holds all the GUI widgets
	protected static User theUser; // The current logged in User

	protected static String theInvitationCode; // The invitation code links to an email address
												// and a role for this user
	protected static String emailAddress; // Established here for use by the controller
	protected static String theRole; // Established here for use by the controller
	public static Scene theNewAccountScene = null; // Access to the User Update page's GUI Widgets

	/*********************************************************************************************
	 * 
	 * Constructors
	 * 
	 */

	/**********
	 * <p>
	 * Method: displayNewAccount(Stage ps, String ic)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is the single entry point from outside this package
	 * to cause the NewAccount page to be displayed.
	 * 
	 * It first sets up very shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the elements that change
	 * based on the user and the system's current state. It then sets the Scene onto
	 * the stage, and makes it visible to the user.
	 * 
	 * @param ps specifies the JavaFX Stage to be used for this GUI and it's methods
	 * 
	 * @param ic specifies the user's invitation code for this GUI and it's methods
	 * 
	 */
	public static void displayNewAccount(Stage ps, String ic) {
		// This is the only way some component of the system can cause a New User
		// Account page to appear. The first time, the class is created and initialized.
		// Every
		// subsequent call it is reused with only the elements that differ being
		// initialized.

		// Establish the references to the GUI and the current user
		theStage = ps; // Save the reference to the Stage for the rest of this package
		theInvitationCode = ic; // Establish the invitation code so it can be easily accessed

		if (theView == null) {
			theView = new ViewNewAccount();
		}

		text_Username.setText(""); // Clear the input fields so previously entered values do not
		text_Password1.setText(""); // appear for a new user
		text_Password2.setText("");

		// Fetch the role for this user
		theRole = theDatabase.getRoleGivenAnInvitationCode(theInvitationCode);

		// Get the email address associated with the invitation code
		emailAddress = theDatabase.getEmailAddressUsingCode(theInvitationCode);

		// Place all of the established GUI elements into the pane
		theRootPane.getChildren().clear();
		theRootPane.getChildren().addAll(label_ApplicationTitle, label_NewUserCreation, label_NewUserLine,
				text_Username, text_Password1, text_Password2, button_UserSetup, button_Quit);

		// Set the title for the window, display the page, and wait for the Admin to do
		// something
		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theNewAccountScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Constructor: ViewNewAccount()
	 * </p>
	 * 
	 * <p>
	 * Description: This constructor is called just once, the first time a new
	 * account needs to be created. It establishes all of the common GUI widgets for
	 * the page so they are only created once and reused when needed.
	 */
	private ViewNewAccount() {

		// Create the Pane for the list of widgets and the Scene for the window
		theRootPane = new Pane();
		theNewAccountScene = new Scene(theRootPane, width, height);

		// Add the 'guiNewAccount.css" style sheet to the scene (which is located in the
		// css folder).
		theNewAccountScene.getStylesheets().add(getClass().getResource("/css/guiNewAccount.css").toExternalForm());

		// Set up the label to display the application name.
		setupLabelUI(label_ApplicationTitle, width, Pos.CENTER, 0, 10);
		label_ApplicationTitle.setId("title");

		// Set up the label to display the second title, indicating the meaning of the
		// page.
		setupLabelUI(label_NewUserCreation, width, Pos.CENTER, 0, 60);
		label_NewUserCreation.setId("title-2");

		// Set up the label to display the instructions above the text fields.
		setupLabelUI(label_NewUserLine, 300, Pos.BASELINE_LEFT, 87.5, 170);
		label_NewUserLine.setId("instructions");

		// Set up the username text field.
		setupTextUI(text_Username, 300, Pos.BASELINE_LEFT, 87.5, 200, true);
		text_Username.setPromptText("Username");
		text_Username.getStyleClass().add("text-field");

		// Set up the first password text field.
		setupTextUI(text_Password1, 300, Pos.BASELINE_LEFT, 87.5, 250, true);
		text_Password1.setPromptText("Password");
		text_Password1.getStyleClass().add("text-field");

		// Set up the second password text field.
		setupTextUI(text_Password2, 300, Pos.BASELINE_LEFT, 87.5, 300, true);
		text_Password2.setPromptText("Verify Password");
		text_Password2.getStyleClass().add("text-field");

		// If the password does not meet the requireemnts, this alert dialog will tell
		// the user. also, if the passwords do not match, this alert dialog will tell
		// the user
		alertUsernamePasswordError.setTitle("Passwords Do Not Match");
		alertUsernamePasswordError.setHeaderText("The two passwords must be identical.");
		alertUsernamePasswordError.setContentText("Correct the passwords and try again.");

		// Set up the 'User Setup' button.
		setupButtonUI(button_UserSetup, 200, Pos.CENTER, 512.5, 250);
		button_UserSetup.setOnAction((event) -> {
			ControllerNewAccount.doCreateUser();
		});
		button_UserSetup.getStyleClass().add("button");

		// Set up the 'Quit' button.
		setupButtonUI(button_Quit, 250, Pos.CENTER, 275, 520);
		button_Quit.setOnAction((event) -> {
			ControllerNewAccount.performQuit();
		});
		button_Quit.getStyleClass().add("button");
	}

	/*********************************************************************************************
	 * 
	 * Helper methods to reduce code length
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 */
	private void setupLabelUI(Label l, double w, Pos p, double x, double y) {
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b The Button object to be initialized
	 * @param w The width of the Button
	 * @param p The alignment (e.g. left, centered, or right)
	 * @param x The location from the left edge (x axis)
	 * @param y The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, double w, Pos p, double x, double y) {
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a text field
	 */
	private void setupTextUI(TextField t, double w, Pos p, double x, double y, boolean e) {
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
}
