package guiSearchPosts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import database.Database;
import entityClasses.Post;
import entityClasses.PostsCollection;
import entityClasses.Reply;
import entityClasses.Thread;
import entityClasses.ThreadsCollection;
import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeTableCell;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ViewSearchPosts {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of posts to the title, author, and actions columns
	private static TreeTableView<Object> postsTable;
	private static final Object LAZY = new Object();
	private static List<Thread> matchedThreads = new ArrayList<>();

	// GUI Area 3: This area is used to enable the student to return to the student
	// home
	// screen
	protected static Button button_StudentHomeScreen = new Button("Return");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewSearchPosts theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theSearchPostsScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displaySearchPosts(Stage ps, User theUser, String keywords)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View Search Posts page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * posts
	 * 
	 * @param ps       specifies the JavaFX Stage to be used for this GUI and it's
	 *                 methods
	 * 
	 * @param theUser  specifies the User for this GUI and it's methods
	 * 
	 * @param keywords specifies the specific keywords the user enter
	 * 
	 */
	public static void displaySearchPosts(Stage ps, User theUser, String keywords) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewSearchPosts(); // Instantiate singleton if needed
		}

		// GUI Area 2
		PostsCollection pc = new PostsCollection(theDatabase, user.getUserName());
		List<Post> posts = pc.searchPosts(keywords);

		ThreadsCollection tc = new ThreadsCollection(theDatabase);
		List<Thread> threads = tc.getThreadsForPosts(posts);
		matchedThreads = threads;

		populatePosts(posts);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theSearchPostsScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewSearchPosts()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displaySearchPosts method.
	 * </p>
	 * 
	 */
	private ViewSearchPosts() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theSearchPostsScene = new Scene(theRoot, width, height);

		theSearchPostsScene.getStylesheets().add(getClass().getResource("/css/guiSearchPosts.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Discussions: Search Results");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		postsTable = buildPostsTable();

		// GUI Area 3
		setupButtonUI(button_StudentHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StudentHomeScreen.setOnAction((event) -> {
			guiStudentHome.ViewStudentHome.displayStudentHome(theStage, user);
		});
		button_StudentHomeScreen.getStyleClass().add("bottom-button");

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, postsTable, button_StudentHomeScreen);
	}

	/****
	 * <p>
	 * Method: TableView<Post> buildPostsTable()
	 * </p>
	 * 
	 * <p>
	 * Description: Creates and configures a TableView for displaying posts. It
	 * defines columns for title, author, and actions, and sets up the table’s
	 * appearance and behavior.
	 * </p>
	 * 
	 * @return a configured TableView for Post objects
	 */
	private TreeTableView<Object> buildPostsTable() {
		TreeItem<Object> root = new TreeItem<>();
		root.setExpanded(true);

		TreeTableView<Object> table = new TreeTableView<>(root);
		table.setPrefHeight(height - 100);
		table.setColumnResizePolicy(TreeTableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
		table.setShowRoot(false);

		TreeTableColumn<Object, String> colTitle = new TreeTableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String title = "";
			if (o instanceof Thread t)
				title = t.getTitle();
			else if (o instanceof Post p)
				title = p.getTitle();
			else if (o instanceof Reply r)
				title = r.getTitle();
			return new ReadOnlyStringWrapper(title);
		});
		colTitle.setPrefWidth(width * 0.50);

		TreeTableColumn<Object, String> colAuthor = new TreeTableColumn<>("Author");
		colAuthor.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String author = "";
			if (o instanceof Thread t)
				author = t.getAuthor();
			else if (o instanceof Post p)
				author = p.getAuthor();
			else if (o instanceof Reply r)
				author = r.getAuthor();
			return new ReadOnlyStringWrapper(author);
		});
		colAuthor.setPrefWidth(width * 0.16);

		TreeTableColumn<Object, String> colReplyCount = new TreeTableColumn<>("Replies");
		colReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyCount()); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colReplyCount.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, String> colUnreadReplyCount = new TreeTableColumn<>("Unread Replies");
		colUnreadReplyCount.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = String.valueOf(p.getReplyUnread(theDatabase, user.getUserName())); // posts show a count
			// If thread/reply, leave blank
			return new ReadOnlyStringWrapper(v);
		});
		colUnreadReplyCount.setPrefWidth(width * 0.10);

		TreeTableColumn<Object, String> colRead = new TreeTableColumn<>("Read");
		colRead.setCellValueFactory(cd -> {
			Object o = cd.getValue().getValue();
			String v = "";
			if (o instanceof Post p)
				v = p.getIsRead(); // only meaningful for posts/replies
			else if (o instanceof Reply r)
				v = r.getIsRead();
			return new ReadOnlyStringWrapper(v);
		});
		colRead.setPrefWidth(width * 0.07);

		TreeTableColumn<Object, Object> colActions = new TreeTableColumn<>("Actions");
		colActions.setCellValueFactory(
				param -> new ReadOnlyObjectWrapper<>(param.getValue() == null ? null : param.getValue().getValue()));
		colActions.setCellFactory(col -> new TreeTableCell<Object, Object>() {
			private final MenuItem openItem = new MenuItem("Open Post");
			private final MenuButton menu = new MenuButton("⋮", null, openItem);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

				openItem.setOnAction(e -> {
					Object o = getTreeTableView().getTreeItem(getIndex()).getValue();
					if (o instanceof Post p) {
						ModelSearchPosts.setReadDB(p.getPostID(), user.getUserName());
						ControllerSearchPosts.openPostButton(p);
					} else if (o instanceof Reply r) {
						ModelSearchPosts.setReadDB(r.getPostID(), user.getUserName());
						ControllerSearchPosts.openReplyButton(r);
					}
				});
			}

			@Override
			protected void updateItem(Object item, boolean empty) {
				super.updateItem(item, empty);
				// Show menu only for posts/replies (threads get no action)
				if (empty || (item instanceof Thread))
					setGraphic(null);
				else
					setGraphic(menu);
			}
		});
		colActions.setPrefWidth(width * 0.10);
		colActions.setSortable(false);

		table.getColumns().addAll(colTitle, colAuthor, colReplyCount, colUnreadReplyCount, colRead, colActions);
		return table;
	}

	/****
	 * <p>
	 * Method: void populatePosts(List<Post> posts)
	 * </p>
	 * 
	 * <p>
	 * Description: Populates the posts table with a list of Post objects. It first
	 * clears existing rows and then adds the provided posts.
	 * </p>
	 * 
	 * @param posts a list of Posts objects to display in the table
	 */
	protected static void populatePosts(List<Post> posts) {
		if (postsTable == null)
			return;

		postsTable.getRoot().getChildren().clear();

		if (posts == null || posts.isEmpty() || matchedThreads == null)
			return;

		Map<Integer, List<Post>> byThread = new HashMap<>();
		for (Post p : posts) {
			byThread.computeIfAbsent(p.getThreadID(), k -> new ArrayList<>()).add(p);
		}

		for (Thread t : matchedThreads) {
			List<Post> postsInThread = byThread.get(t.getThreadID());
			if (postsInThread == null || postsInThread.isEmpty())
				continue;

			TreeItem<Object> threadItem = new TreeItem<>((Object) t); // real Thread row
			threadItem.setExpanded(false);
			postsTable.getRoot().getChildren().add(threadItem);

			// Add each matched post under the thread
			for (Post p : postsInThread) {
				TreeItem<Object> postItem = new TreeItem<>((Object) p);
				threadItem.getChildren().add(postItem);

				// Lazy load all replies for this post when expanded
				postItem.getChildren().setAll(new TreeItem<>(LAZY));
				postItem.expandedProperty().addListener((obs, was, is) -> {
					if (!is)
						return;
					if (postItem.getChildren().size() == 1 && postItem.getChildren().get(0).getValue() == LAZY) {
						postItem.getChildren().clear();
						addRepliesRecursively(postItem, p.getPostID());
					}
				});
			}
		}
	}

	/****
	 * <p>
	 * Method: void addRepliesRecursively(TreeItem<Object> parentItem, int
	 * parentPostID)
	 * </p>
	 * 
	 * <p>
	 * Description: Recursively adds every reply under a parent post
	 * </p>
	 * 
	 * @param posts a list of Posts objects to display in the table
	 */
	private static void addRepliesRecursively(TreeItem<Object> parentItem, int parentPostID) {
		List<Reply> replies = ModelSearchPosts.getPostReplies(parentPostID, user.getUserName());
		for (Reply r : replies) {
			TreeItem<Object> child = new TreeItem<>((Object) r);
			parentItem.getChildren().add(child);
			addRepliesRecursively(child, r.getPostID());
		}
	}

	/****
	 * <p>
	 * Method: void openPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a post. The
	 * post includes a title and content input area.
	 * </p>
	 * 
	 * @param p the Post object where the post will be created
	 * 
	 */
	protected static void openPost(Post p) {
		Stage dialog = new Stage();
		dialog.setTitle("Post");
		Label title = new Label(p.getTitle() == null || p.getTitle().isBlank() ? "(untitled)" : p.getTitle());
		Label author = new Label("By: " + p.getAuthor());

		TextArea content = new TextArea(p.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openReply(Reply r)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a reply. The
	 * reply includes a title and content input area.
	 * </p>
	 * 
	 * @param r the Reply object where the reply will be created
	 * 
	 */
	protected static void openReply(Reply r) {
		Stage dialog = new Stage();
		dialog.setTitle("Reply");
		Label title = new Label(r.getTitle() == null || r.getTitle().isBlank() ? "(untitled)" : r.getTitle());
		Label author = new Label("By: " + r.getAuthor());

		TextArea content = new TextArea(r.getContent());
		content.setEditable(false);
		content.setWrapText(true);
		content.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, author, new Separator(), content, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
