package guiSearchPosts;

import java.util.List;

import database.Database;
import entityClasses.Reply;

/**
 * <p>
 * Title: ModelSearchPosts Class
 * </p>
 * 
 * <p>
 * Description: This class is part of the MVC structure for the Search Posts
 * feature. It handles setting posts as read and retrieving replies associated
 * with a post via the common database.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ModelSearchPosts {

	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: setReadDB(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Marks a post as read for the specified user
	 * </p>
	 * 
	 * @param postID   the id of the post read
	 * @param username the user who has read the post
	 */
	protected static void setReadDB(int postID, String username) {
		theDatabase.setReadPost(postID, username);
	}

	/**********
	 * <p>
	 * Method: getPostReplies(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Reads all replies to a given post from the database.
	 * </p>
	 * 
	 * @param postID   the id of the post getting replies to
	 * @param username the user retrieving the replies
	 * @return a List<Reply> to the given post, or empty list if an error occurs
	 */
	protected static List<Reply> getPostReplies(int postID, String username) {
		try {
			return theDatabase.getRepliesForPost(postID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}
}
