package guiSearchPosts;

/**
 * <p>
 * Title: ControllerSearchPosts Class
 * </p>
 * 
 * <p>
 * Description: This class is part of the MVC structure for the Search Posts
 * feature. It handles reading posts and replies from a search.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerSearchPosts {

	/**********
	 * <p>
	 * Method: openPostButton(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a Post if the given Post is not null.
	 * </p>
	 * 
	 * @param p the Post to be opened
	 */
	protected static void openPostButton(entityClasses.Post p) {
		if (p != null)
			ViewSearchPosts.openPost(p);
	}

	/**********
	 * <p>
	 * Method: openReplyButton(Reply r)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a Reply if the given Reply is not null.
	 * </p>
	 * 
	 * @param r the Reply to be opened
	 */
	protected static void openReplyButton(entityClasses.Reply r) {
		if (r != null)
			ViewSearchPosts.openReply(r);
	}
}
