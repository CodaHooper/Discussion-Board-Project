package guiMyPosts;

import java.sql.SQLException;
import java.util.List;

import database.Database;
import entityClasses.Post;
import entityClasses.Reply;

/**
 * <p>
 * Title: ModelMyPosts Class
 * </p>
 * 
 * <p>
 * Description: This class serves as the model in the MVC pattern for the view
 * My Posts feature. It handles deleting, updating, marking as read, and
 * retrieving replies for posts from the database.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ModelMyPosts {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: deletePostDB(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Deletes the specified post from the database.
	 * </p>
	 * 
	 * @param p The Post to delete
	 * @return true if deletion was successful, otherwise false
	 */
	protected static boolean deletePostDB(entityClasses.Post p) {
		try {
			theDatabase.deletePost(p.getPostID());
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**********
	 * <p>
	 * Method: editPostDB(String title, String content, Object o)
	 * </p>
	 * 
	 * <p>
	 * Description: Updates the title and content of a post or reply in the
	 * database. Checks the type of object to determine whether it is a Post or
	 * Reply.
	 * </p>
	 *
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param title   The new title for the post/reply
	 * @param content The new content/body for the post/reply
	 * @param o       The Post or Reply object to update
	 * @return true if the update was successful, false if an SQLException occurs
	 */
	protected static boolean editPostDB(String title, String content, Object o) {
		try {
			if (o instanceof Post p) // we are updating a POST object
				theDatabase.updatePost(p.getPostID(), title, content);
			else if (o instanceof Reply r)// we are updating a REPLY object
				theDatabase.updatePost(r.getPostID(), title, content);
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**********
	 * <p>
	 * Method: setReadDB(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Marks the specified post as read by the given user.
	 * </p>
	 * 
	 * @param postID   The id of the post to mark as read
	 * @param username The username of the user reading the post
	 */
	protected static void setReadDB(int postID, String username) {
		theDatabase.setReadPost(postID, username);
	}

	/**********
	 * <p>
	 * Method: getPostReplies(int postID, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: Retrieves all replies associated with the specified post.
	 * </p>
	 * 
	 * @param postID   The id of the post requesting replies for
	 * @param username The username of the user requesting the replies
	 * @return A List<Reply> of the replies, or an empty list if an exception occurs
	 */
	protected static List<Reply> getPostReplies(int postID, String username) {
		try {
			return theDatabase.getRepliesForPost(postID, username);
		} catch (Exception exc) {
			exc.printStackTrace();
			return java.util.Collections.emptyList();
		}
	}
}
