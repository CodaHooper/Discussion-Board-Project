package guiMyPosts;

import entityClasses.Post;
import entityClasses.Reply;
import javafx.scene.control.ButtonType;

/**
 * <p>
 * Title: ControllerMyPosts Class
 * </p>
 *
 * <p>
 * Description: This class serves as the controller in the MVC pattern for the
 * view My Posts feature. It handles reading, updating, and deleting posts and
 * replies.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerMyPosts {

	/**********
	 * <p>
	 * Method: doOpenPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a view of the specified Post.
	 * </p>
	 * 
	 * @param p The Post object to display
	 */
	protected static void doOpenPost(Post p) {
		if (p != null)
			ViewMyPosts.openPost(p);
	}

	/**********
	 * <p>
	 * Method: doOpenReply(Reply r)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a view of the specified Reply.
	 * </p>
	 * 
	 * @param r The Reply object to display
	 */
	protected static void doOpenReply(Reply r) {
		if (r != null)
			ViewMyPosts.openReply(r);
	}

	/**********
	 * <p>
	 * Method: doOpenEditPost(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens the interface to update a specified Post.
	 * </p>
	 * 
	 * @param p The Post object to edit
	 */
	protected static void doOpenEditPost(Post p) {
		if (p != null)
			ViewMyPosts.openEditPost(p);
	}

	/**********
	 * <p>
	 * Method: deletePostButton(Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Prompt a user to confirm they want to delete the specified post.
	 * If the user confirms, the post's status is updated to deleted in the
	 * database.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * 
	 * @param p The Post object to delete
	 * 
	 * @return true if deletion was successful, false otherwise
	 */
	protected static boolean deletePostButton(Post p) {
		if (p == null)
			return false;

		ViewMyPosts.confirm.setContentText("Are you sure you want to delete this Post?");
		ViewMyPosts.confirm.setHeaderText("Confirm Delete");
		if (ViewMyPosts.confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
			return ModelMyPosts.deletePostDB(p);
		}
		return false;
	}

	/**********
	 * <p>
	 * Method: editPostLogic(String title, String content, Post p)
	 * </p>
	 * 
	 * <p>
	 * Description: Validates input for updating a post in the database. Posts must
	 * not have empty fields and are held to length constraints. Displays error
	 * message if validation fails.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param title   The new title for the post
	 * @param content The new body for the post
	 * @param p       The Post to update
	 * @return true if the post was successfully updated, otherwise false
	 */
	protected static boolean editPostLogic(String title, String content, Post p) {
		if (title.isEmpty()) { // Post title cannot be empty.
			ViewMyPosts.postTitle.setText(p.getTitle());
			ViewMyPosts.postContent.setText(p.getContent());
			ViewMyPosts.alertEditError.setContentText("Post title cannot be empty.");
			ViewMyPosts.alertEditError.showAndWait();
			return false;
		} else if (content.isEmpty()) { // Post body cannot be empty.
			ViewMyPosts.postTitle.setText(p.getTitle());
			ViewMyPosts.postContent.setText(p.getContent());
			ViewMyPosts.alertEditError.setContentText("Post body cannot be empty.");
			ViewMyPosts.alertEditError.showAndWait();
			return false;
		} else if (title.length() > 200) { // Post title cannot exceed 200 characters
			ViewMyPosts.postTitle.setText(p.getTitle());
			ViewMyPosts.postContent.setText(p.getContent());
			ViewMyPosts.alertEditError.setContentText("Post title cannot exceed 200 characters.");
			ViewMyPosts.alertEditError.showAndWait();
			return false;
		} else if (content.length() > 10000) { // Post body cannot exceed 10,000 characters. 
			ViewMyPosts.postTitle.setText(p.getTitle());
			ViewMyPosts.postContent.setText(p.getContent());
			ViewMyPosts.alertEditError.setContentText("Post body cannot exceed 10,000 characters.");
			ViewMyPosts.alertEditError.showAndWait();
			return false;
		} else {
			return ModelMyPosts.editPostDB(title, content, p);
		}
	}
}
