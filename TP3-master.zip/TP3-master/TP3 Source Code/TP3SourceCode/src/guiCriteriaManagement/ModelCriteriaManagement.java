package guiCriteriaManagement;

import java.sql.SQLException;

import database.Database;

public class ModelCriteriaManagement {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**
	 * <p>
	 * Method: createEvalParameterDB(String title, String description, EvalParameter
	 * ep)
	 * </p>
	 *
	 * <p>
	 * Description: Creates a new evaluation parameter in the evaluation parameter
	 * database using the given title and description.
	 * </p>
	 * 
	 * @param title       The new title of the evaluation parameter
	 * 
	 * @param description The new content of the evaluation parameter
	 * 
	 * @return true if the evaluation parameter was successfully created, otherwise
	 *         false
	 */
	protected static boolean createEvalParameterDB(String title, String description) {
		try {
			theDatabase.createParameter(title, description);
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**
	 * <p>
	 * Method: editEvalParameterDB(String title, String description, EvalParameter
	 * ep)
	 * </p>
	 *
	 * <p>
	 * Description: Updates the title and content of the specified evaluation
	 * parameter in the database. If an SQL exception occurs, print stack trace and
	 * return false.
	 * </p>
	 * 
	 * @param title       The new title of the evaluation parameter
	 * 
	 * @param description The new content of the evaluation parameter
	 * 
	 * @return true if the evaluation parameter was successfully updated, otherwise
	 *         false
	 */
	protected static boolean editEvalParameterDB(String title, String description) {
		try {
			theDatabase.updateParameter(title, description);
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}

	/**
	 * <p>
	 * Method: deleteEvalParameterDB(EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: Deletes the evaluation parameter from the database. If an SQL
	 * exception occurs, print stack trace and return false.
	 * </p>
	 *
	 * @param ep The evaluation parameter to delete
	 * 
	 * @return true if the evaluation parameter was successfully deleted, otherwise
	 *         false.
	 */
	protected static boolean deleteEvalParameterDB(entityClasses.EvalParameter ep) {
		try {
			theDatabase.deleteParameter(ep.getTitle());
			return true;
		} catch (SQLException exc) {
			exc.printStackTrace();
			return false;
		}
	}
}
