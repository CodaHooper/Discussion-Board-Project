package guiCriteriaManagement;

import entityClasses.EvalParameter;
import javafx.scene.control.ButtonType;

public class ControllerCriteriaManagement {

	/**********
	 * <p>
	 * Method: openParameterButton(EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: Opens the selected evaluation parameter in a read-only dialog if
	 * it is not null.
	 * </p>
	 *
	 * @param ep The EvalParameter object to open
	 */
	protected static void openParameterButton(EvalParameter ep) {
		if (ep != null)
			ViewCriteriaManagement.openEvalParameter(ep);
	}

	/**********
	 * <p>
	 * Method: editParameterButton(EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: Opens the update dialog for the specified evaluation parameter
	 * if it is not null.
	 * 
	 * </p>
	 *
	 * @param ep The EvalParameter object to edit
	 */
	protected static void editParameterButton(EvalParameter ep) {
		if (ep != null)
			ViewCriteriaManagement.openEditParameter(ep);
	}

	/**********
	 * <p>
	 * Method: deleteParameterButton(EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: Prompts the user to confirm deletion of a evaluation parameter.
	 * If the user confirms, the parameter is deleted.
	 * </p>
	 * 
	 * @param ep The EvalParameter object to delete
	 * 
	 * @return true if the parameter was successfully deleted, otherwise false
	 */

	protected static boolean deleteParameterButton(EvalParameter ep) {
		if (ep == null) {
			return false;
		}

		ViewCriteriaManagement.confirm.setContentText("Are you sure you want to delete this evaluation parameter?");
		ViewCriteriaManagement.confirm.setHeaderText("Confirm Delete");
		
		if (ViewCriteriaManagement.confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
			return ModelCriteriaManagement.deleteEvalParameterDB(ep);
		}
		
		return false;
	}

	/**********
	 * <p>
	 * Method: boolean editParameterLogic(String title, String description,
	 * EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: The validation logic for editing a parameter.
	 * </p>
	 * 
	 * @param title       the title of the original evaluation parameter
	 * 
	 * @param description the description of the original evaluation parameter
	 * 
	 * @param ep          The EvalParameter object to edit
	 * 
	 * @return true if the evaluation parameter was successfully edited, otherwise false
	 */
	protected static boolean editParameterLogic(String title, String description, EvalParameter ep) {
		String error = parameterInputValidation(title, description);
		
		if (error == null) {
			return ModelCriteriaManagement.editEvalParameterDB(title, description);
		} else {
			ViewCriteriaManagement.parameterTitle.setText(ep.getTitle());
			ViewCriteriaManagement.parameterDescription.setText(ep.getDescription());
			ViewCriteriaManagement.alertEditError.setContentText(error);
			ViewCriteriaManagement.alertEditError.showAndWait();
			return false;
		}
	}

	/**********
	 * <p>
	 * Method: boolean createParameterLogic(String title, String description, EvalParameter ep)
	 * </p>
	 *
	 * <p>
	 * Description: The validation logic for creating a parameter.
	 * </p>
	 * 
	 * @param title       the title of the new evaluation parameter
	 * 
	 * @param description the description of the new evaluation parameter
	 * 
	 * @return true if the parameter was successfully created, otherwise false
	 */
	protected static boolean createParameterLogic(String title, String description) {
		String error = parameterInputValidation(title, description);
		
		if (error == null) {
			return ModelCriteriaManagement.createEvalParameterDB(title, description);
		} else {
			ViewCriteriaManagement.alertEditError.setContentText(error);
			ViewCriteriaManagement.alertEditError.showAndWait();
			return false;
		}
	}
	
	/**
	 * 
	 * <p> Method: parameterInputValidation(String title, String description) </p>
	 * 
	 * <p> Description: The input validation for editing or creating a new parameter. </p>
	 * 
	 * @param  title the title of the parameter.
	 * @param  description the description of the parameter.
	 * 
	 * @return a String object representing the error message associated with the input validation (or null if input validation passes)
	 */
	public static String parameterInputValidation(String title, String description) {
		if (title.isEmpty()) { // EvalParameter title cannot be empty.
			return "Evaluation parameter title cannot be empty.";
		} else if (description.isEmpty()) { // Evaluation parameter description cannot be empty.
			return "Evaluation parameter description cannot be empty.";
		} else if (title.length() > 200) { // Evaluation parameter title cannot exceed 200 characters.
			return "Evaluation parameter title cannot exceed 200 characters.";
		} else if (description.length() > 10000) { // Evaluation parameter description cannot exceed 10,000 characters.
			return "Evaluation parameter description cannot exceed 10,000 characters.";
		} else {
			return null;
		}
	}
}
