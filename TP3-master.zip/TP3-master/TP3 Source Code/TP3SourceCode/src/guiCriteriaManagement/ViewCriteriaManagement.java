package guiCriteriaManagement;

import java.util.List;

import database.Database;
import entityClasses.EvalParameter;
import entityClasses.EvalParametersCollection;
import entityClasses.User;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class ViewCriteriaManagement {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// These are the application values required by the user interface
	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// User object
	private static User user;

	// GUI Area 1: It informs the user about the purpose of this page
	protected static Label label_PageTitle = new Label();

	// GUI Area 2: This area is used to provide an "Infinite Scroll" functionality
	// to add rows of posts to the title, author, and actions columns
	private static TableView<EvalParameter> evalParametersTable;
	protected static TableView<EvalParameter> table;

	// Alerts for deletion confirmation and edit errors
	protected static Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
	protected static Alert alertEditError = new Alert(Alert.AlertType.ERROR);
	protected static Alert alertCreateError = new Alert(Alert.AlertType.ERROR);

	// Edit attributes
	protected static TextField parameterTitle;
	protected static TextArea parameterDescription;

	// GUI Area 3: This area is used to enable the staff member to return to the
	// staff home screen and create a new evaluation parameter
	protected static Button button_StaffHomeScreen = new Button("Return");
	protected static Button button_CreateParameter = new Button("Create Parameter");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewCriteriaManagement theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	private static VBox theRoot; // The Vbox that holds all the GUI widgets

	private static Scene theCriteriaManagementScene; // The shared Scene each invocation populates

	/**********
	 * <p>
	 * Method: displayCriteriaManagement(Stage ps, User theUser)
	 * </p>
	 * 
	 * <p>
	 * Description: Description: This method is the single entry point from outside
	 * this package to cause the View Criteria Management page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the columns for the table
	 * view with the appropriate information for the users and their respective
	 * evalParameters
	 * 
	 * @param ps      specifies the JavaFX Stage to be used for this GUI and it's
	 *                methods
	 * 
	 * @param theUser specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayCriteriaManagement(Stage ps, User theUser) {

		// Establish the references to the GUI
		theStage = ps;
		user = theUser;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewCriteriaManagement(); // Instantiate singleton if needed
		}

		// GUI Area 2
		EvalParametersCollection evc = new EvalParametersCollection(theDatabase);
		List<EvalParameter> evalParameters = evc.getEvalParameters();
		populateEvalParameters(evalParameters);

		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theCriteriaManagementScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewCriteriaManagement()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayCriteriaManagement method.
	 * </p>
	 * 
	 */
	private ViewCriteriaManagement() {

		// Create the VBox for the list of widgets and the Scene for the window
		theRoot = new VBox(10);
		theRoot.setPadding(new Insets(20));
		theCriteriaManagementScene = new Scene(theRoot, width, height);

		theCriteriaManagementScene.getStylesheets()
				.add(getClass().getResource("/css/guiCriteriaManagement.css").toExternalForm());

		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("All Evaluation Parameters");
		setupLabelUI(label_PageTitle, "Arial", 28, width, Pos.CENTER, 0, 0);
		label_PageTitle.getStyleClass().add("title");

		// GUI Area 2
		evalParametersTable = buildEvalParametersTable();

		// GUI Area 3
		setupButtonUI(button_StaffHomeScreen, "Dialog", 16, 250, Pos.CENTER, 20, 0);
		button_StaffHomeScreen.setOnAction((event) -> {
			guiStaffHome.ViewStaffHome.displayStaffHome(theStage, user);
		});
		button_StaffHomeScreen.getStyleClass().add("bottom-button");

		setupButtonUI(button_CreateParameter, "Dialog", 16, 250, Pos.CENTER, 0, 0);
		button_CreateParameter.setOnAction((event) -> {
			openCreateParameter();
		});
		button_CreateParameter.getStyleClass().add("bottom-button");

		// Make buttons go to the far left and right
		HBox buttons = new HBox(16);
		Button btnReturn = button_StaffHomeScreen;
		Button btnUnread = button_CreateParameter;

		Region spacer = new Region();
		HBox.setHgrow(spacer, Priority.ALWAYS);

		buttons.getChildren().addAll(btnReturn, spacer, btnUnread);
		buttons.setAlignment(Pos.CENTER);
		VBox.setMargin(buttons, new Insets(5, 5, 0, 5));

		// Place all of the widget items into the Root VBox's list of children
		theRoot.getChildren().addAll(label_PageTitle, evalParametersTable, buttons);
	}

	/****
	 * <p>
	 * Method: TableView<EvalParameter> buildEvalParametersTable()
	 * </p>
	 * 
	 * <p>
	 * Description: Creates and configures a TableView for displaying evaluation
	 * parameters. It defines columns for title, author, and actions, and sets up
	 * the table’s appearance and behavior.
	 * </p>
	 * 
	 * @return a configured TableView for EvalParameter objects
	 */
	private TableView<EvalParameter> buildEvalParametersTable() {
		table = new TableView<>();
		table.setPrefHeight(height - 100);
		table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);

		TableColumn<EvalParameter, String> colTitle = new TableColumn<>("Title");
		colTitle.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getTitle()));
		colTitle.setPrefWidth(width * 0.3);

		TableColumn<EvalParameter, String> colDescription = new TableColumn<>("Description");
		colDescription.setCellValueFactory(cd -> new ReadOnlyStringWrapper(cd.getValue().getDescription()));
		colDescription.setPrefWidth(width * 0.65);

		TableColumn<EvalParameter, EvalParameter> colActions = new TableColumn<>("Actions");
		colActions.setCellValueFactory(param -> new ReadOnlyObjectWrapper<>(param.getValue()));
		colActions.setCellFactory(col -> new TableCell<EvalParameter, EvalParameter>() {
			private final MenuItem openItem = new MenuItem("Open");
			private final MenuItem editItem = new MenuItem("Edit");
			private final MenuItem deleteItem = new MenuItem("Delete");
			private final MenuButton menu = new MenuButton("⋮", null, openItem, editItem, deleteItem);
			{
				setContentDisplay(ContentDisplay.GRAPHIC_ONLY);

				openItem.setOnAction(e -> {
					EvalParameter ep = getTableView().getItems().get(getIndex());
					ControllerCriteriaManagement.openParameterButton(ep);
				});

				editItem.setOnAction(e -> {
					EvalParameter ep = getTableView().getItems().get(getIndex());
					ControllerCriteriaManagement.editParameterButton(ep);
				});

				deleteItem.setOnAction(e -> {
					EvalParameter ep = getTableView().getItems().get(getIndex());
					if (ControllerCriteriaManagement.deleteParameterButton(ep)) {
						getTableView().getItems().remove(ep);
						new Alert(Alert.AlertType.INFORMATION, "Evaluation parameter deleted.").showAndWait();
					} else
						new Alert(Alert.AlertType.ERROR, "Failed to delete evaluation parameter.").showAndWait();
				});
			}

			@Override
			protected void updateItem(EvalParameter item, boolean empty) {
				super.updateItem(item, empty);
				setGraphic(empty ? null : menu);
			}
		});
		colActions.setPrefWidth(width * 0.15);
		colActions.setSortable(false);

		table.getColumns().addAll(colTitle, colDescription, colActions);
		return table;
	}

	/****
	 * <p>
	 * Method: void populateEvalParameters(List<EvalParameter> evalParameters)
	 * </p>
	 * 
	 * <p>
	 * Description: Populates the evaluation parameters table with a list of
	 * evaluation parameters objects. It first clears existing rows and then adds
	 * the provided parameters to avoid duplication.
	 * </p>
	 * 
	 * @param evalParameters a list of evaluation parameter objects to display in
	 *                       the table
	 */
	protected static void populateEvalParameters(List<EvalParameter> evalParameters) {
		if (evalParametersTable == null)
			return;
		evalParametersTable.getItems().clear();
		if (evalParameters != null) {
			evalParametersTable.getItems().addAll(evalParameters);
		}
	}

	/****
	 * <p>
	 * Method: void openParameter(EvalParameter ep)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to open a
	 * evalParameter. The evaluation parameter includes a title and content input
	 * area.
	 * </p>
	 * 
	 * @param ep the evaluation parameter to be read and opened
	 * 
	 */
	protected static void openEvalParameter(EvalParameter ep) {
		Stage dialog = new Stage();
		dialog.setTitle("Evaluation Parameter");
		Label title = new Label(ep.getTitle() == null || ep.getTitle().isBlank() ? "(untitled)" : ep.getTitle());

		TextArea description = new TextArea(ep.getDescription());
		description.setEditable(false);
		description.setWrapText(true);
		description.setPrefRowCount(12);

		Button closeBtn = new Button("Close");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, title, new Separator(), description, new HBox(10, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 350);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openEditParameter(EvalParameter ep)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to edit an evaluation
	 * parameter' title and content.
	 * </p>
	 * 
	 * @param ep the evaluation parameter object where the post will be created
	 * 
	 */
	protected static void openEditParameter(EvalParameter ep) {
		Stage dialog = new Stage();
		dialog.setTitle("Edit Evalulation Parameter");

		Label titleLabel = new Label("Title:");
		parameterTitle = new TextField(ep.getTitle());

		Label contentLabel = new Label("Content:");
		parameterDescription = new TextArea(ep.getDescription());
		parameterDescription.setWrapText(true);
		parameterDescription.setPrefRowCount(12);

		Button saveBtn = new Button("Save");
		saveBtn.setOnAction(e -> {
			String title = parameterTitle.getText().trim();
			String content = parameterDescription.getText().trim();
			if (ControllerCriteriaManagement.editParameterLogic(title, content, ep)) {
				// Update the in-memory object so the table shows the changes
				ep.setTitle(title);
				ep.setDescription(content);
				// Refresh table
				evalParametersTable.refresh();
				new Alert(Alert.AlertType.INFORMATION, "Evaluation parameter updated.").showAndWait();
				dialog.close();
			} else
				new Alert(Alert.AlertType.ERROR, "Failed to update evaluation parameter.").showAndWait();
		});

		Button cancelBtn = new Button("Cancel");
		cancelBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, titleLabel, parameterTitle, contentLabel, parameterDescription,
				new HBox(10, saveBtn, cancelBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 500);
		dialog.setScene(scene);
		dialog.initOwner(theStage);
		dialog.showAndWait();
	}

	/****
	 * <p>
	 * Method: void openCreateParameter(EvalParameter ep)
	 * </p>
	 * 
	 * <p>
	 * Description: Opens a dialog window that allows the user to create a new
	 * evaluation parameter.
	 * </p>
	 * 
	 * @param ep the evaluation parameter object where the post will be created
	 * 
	 */
	protected static void openCreateParameter() {
		Stage dialog = new Stage();
		dialog.setTitle("Create Evaluation Parameter");

		TextArea parameterTitle = new TextArea();
		parameterTitle.setPromptText("...");
		parameterTitle.setWrapText(true);
		parameterTitle.setPrefRowCount(1);

		TextArea parameterDescription = new TextArea();
		parameterDescription.setPromptText("...");
		parameterDescription.setWrapText(true);
		parameterDescription.setPrefRowCount(4);

		Button createBtn = new Button("Create");
		createBtn.setOnAction(e -> {
			String title = parameterTitle.getText().trim();
			String description = parameterDescription.getText().trim();
			if (ControllerCriteriaManagement.createParameterLogic(title, description)) {
				Alert success = new Alert(Alert.AlertType.INFORMATION);
				success.setHeaderText("Success");
				success.setContentText("Evaluation parameter created successfully.");
				success.showAndWait();
				dialog.close();
			}
		});

		Button closeBtn = new Button("Cancel");
		closeBtn.setOnAction(e -> dialog.close());

		VBox layout = new VBox(10, parameterTitle, parameterDescription, new Separator(),
				new HBox(10, createBtn, closeBtn));
		layout.setPadding(new Insets(15));
		layout.setAlignment(Pos.CENTER_LEFT);

		Scene scene = new Scene(layout, 600, 200);
		dialog.setScene(scene);
		dialog.showAndWait();
	}

	/********************************************************************************************
	 * 
	 * Helper methods used to minimizes the number of lines of code needed above
	 * 
	 */

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l  The Label object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b  The Button object to be initialized
	 * @param ff The font to be used
	 * @param f  The size of the font to be used
	 * @param w  The width of the Button
	 * @param p  The alignment (e.g. left, centered, or right)
	 * @param x  The location from the left edge (x axis)
	 * @param y  The location from the top (y axis)
	 */
	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
