package guiStudentHome;

/**
 * <p>
 * Title: ControllerStudentHome Class
 * </p>
 * 
 * <p>
 * Description: This class is part of the MVC structure for the Student Home
 * page. It handles searching posts, updating user information, logging out, and
 * quitting the application.
 * </p>
 * 
 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
 * Walden.
 */
public class ControllerStudentHome {

	/*********************************************************************************************
	 * 
	 * User Interface Actions for this page
	 * 
	 **********************************************************************************************/

	/**
	 * <p>
	 * Method: performSearch(String content)
	 * </p>
	 * 
	 * <p>
	 * Description: Validates the search input entered by the user. If the length of
	 * the search term is longer than 200 characters, it clears the field and
	 * displays an error message.
	 * </p>
	 * 
	 * Class and method functionality summarized by ChatGPT, Javadoc edited by Shawn
	 * Walden.
	 * 
	 * @param content the search keywords entered by the user
	 * @return true if the search content is valid; false otherwise
	 */
	protected static boolean performSearch(String content) {
		if (content.length() > 200) {
			ViewStudentHome.searchContent.clear();
			ViewStudentHome.alertSearchError.setContentText("Search keywords cannot exceed 200 characters.");
			ViewStudentHome.alertSearchError.showAndWait();
			return false;
		}
		return true;
	}

	/**
	 * <p>
	 * Method: performUpdate()
	 * </p>
	 * 
	 * <p>
	 * Description: Displays a page where a user can update their personal
	 * information.
	 * </p>
	 */
	protected static void performUpdate() {
		guiUserUpdate.ViewUserUpdate.displayUserUpdate(ViewStudentHome.theStage, ViewStudentHome.theUser);
	}

	/**
	 * <p>
	 * Method: performLogout()
	 * </p>
	 * 
	 * <p>
	 * Description: Logs the user out of the application and displays the login page
	 * </p>
	 */
	protected static void performLogout() {
		guiUserLogin.ViewUserLogin.displayUserLogin(ViewStudentHome.theStage);
	}

	/**
	 * <p>
	 * Method: performQuit()
	 * </p>
	 * 
	 * <p>
	 * Description: Exits the application.
	 * </p>
	 */
	protected static void performQuit() {
		System.exit(0);
	}
}
