package guiStudentHome;

/*******
 * <p>
 * Title: ModelStudentHome Class.
 * </p>
 * 
 * <p>
 * Description: The Student Home Page Model. This class is not used because
 * there is no business logic in this package.
 * </p>
 */
public class ModelStudentHome {

}
