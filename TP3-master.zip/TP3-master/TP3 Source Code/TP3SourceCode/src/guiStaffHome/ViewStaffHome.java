package guiStaffHome;

import database.Database;
import entityClasses.User;
import guiPendingRequests.ViewPendingRequests;
import guiInactiveRequests.ViewInactiveRequests;
import guiUserUpdate.ViewUserUpdate;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Line;
import javafx.stage.Stage;
import java.util.Scanner;

/*******
 * <p>
 * Title: ViewStaffHome Class.
 * </p>
 * 
 * <p>
 * Description: The Java/FX-based Staff Home Page. The page is a stub for some
 * role needed for the application. The widgets on this page are likely the
 * minimum number and kind for other role pages that may be needed.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2025
 * </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 1.00 2025-08-20 Initial version
 * 
 */

public class ViewStaffHome {

	/*-*******************************************************************************************
	
	Attributes
	
	 */

	// Scanner
	Scanner scnr = new Scanner(System.in);

	// These are the application values required by the user interface

	private static double width = applicationMain.DiscussionsMain.WINDOW_WIDTH;
	private static double height = applicationMain.DiscussionsMain.WINDOW_HEIGHT;

	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	// These are the widget attributes for the GUI. There are 3 areas for this GUI.

	// GUI Area 1: It informs the user about the purpose of this page, whose account
	// is being used,
	// and a button to allow this user to update the account settings
	protected static Label label_PageTitle = new Label();
	protected static Label label_UserDetails = new Label();
	protected static Button button_UpdateThisUser = new Button("Account Update");

	// This is a separator and it is used to partition the GUI for various tasks
	protected static Line line_Separator1 = new Line(20, 95, width - 20, 95);

	// GUI Area 2: This contains the create thread, list thread, and criteria
	// management buttons
	protected static Button button_CreateThread = new Button("Create Thread");
	protected static Stage createThreadStage = new Stage();

	protected static TextField threadTitle;
	protected static TextArea threadContent;

	// This alert is used if the user has an input error during thread creation
	protected static Alert alertCreateThreadError = new Alert(AlertType.ERROR);

	// This alert is used if the user successfully creates a thread
	protected static Alert alertCreateThreadSuccess = new Alert(AlertType.INFORMATION);

	protected static Button button_ListThreads = new Button("View Threads");
	
	protected static Button button_CriteriaManagement = new Button("Manage Criteria");
	
	protected static Button button_createRequest = new Button("Create Request");
	protected static Stage createRequestStage = new Stage();
	protected static TextField requestTitle;
	protected static TextArea requestDescription;
	protected static Alert alertCreateRequestSuccess = new Alert(AlertType.INFORMATION);
	protected static Alert alertCreateRequestError = new Alert(AlertType.ERROR);
	
	protected static Button button_pendingRequests = new Button("Pending Requests");
	protected static Button button_inactiveRequests = new Button("Inactive Requests");

	// This is a separator and it is used to partition the GUI for various tasks
	protected static Line line_Separator2 = new Line(20, 525, width - 20, 525);

	// GUI Area 3: This is last of the GUI areas. It is used for quitting the
	// application and for logging out.
	protected static Button button_Logout = new Button("Logout");
	protected static Button button_Quit = new Button("Quit");

	// These attributes are used to configure the page and populate it with this
	// user's information
	private static ViewStaffHome theView; // Used to determine if instantiation of the class is needed

	protected static Stage theStage; // The Stage that JavaFX has established for us
	protected static Pane theRootPane; // The Pane that holds all the GUI widgets
	protected static User theUser; // The current logged in User

	private static Scene theViewStaffHomeScene; // The shared Scene each invocation populates
	protected static final int theRole = 2; // Admin: 1; Staff: 2; Student: 3

	/*-*******************************************************************************************
	
	Constructors
	
	 */

	/**********
	 * <p>
	 * Method: displayStaffHome(Stage ps, User user)
	 * </p>
	 * 
	 * <p>
	 * Description: This method is the single entry point from outside this package
	 * to cause the Staff Home page to be displayed.
	 * 
	 * It first sets up every shared attributes so we don't have to pass parameters.
	 * 
	 * It then checks to see if the page has been setup. If not, it instantiates the
	 * class, initializes all the static aspects of the GIUI widgets (e.g., location
	 * on the page, font, size, and any methods to be performed).
	 * 
	 * After the instantiation, the code then populates the elements that change
	 * based on the user and the system's current state. It then sets the Scene onto
	 * the stage, and makes it visible to the user.
	 * 
	 * @param ps   specifies the JavaFX Stage to be used for this GUI and it's
	 *             methods
	 * 
	 * @param user specifies the User for this GUI and it's methods
	 * 
	 */
	public static void displayStaffHome(Stage ps, User user) {

		// Establish the references to the GUI and the current user
		theStage = ps;
		theUser = user;

		// If not yet established, populate the static aspects of the GUI
		if (theView == null) {
			theView = new ViewStaffHome();
		}

		// Populate the dynamic aspects of the GUI with the data from the user and the
		// current state of the system.
		theDatabase.getUserAccountDetails(user.getUserName());
		applicationMain.DiscussionsMain.activeHomePage = theRole;

		label_UserDetails.setText("User: " + theUser.getUserName());

		// Set the title for the window, display the page, and wait for the Admin to do something
		theStage.setTitle("CSE 360 TP3");
		theStage.setScene(theViewStaffHomeScene);
		theStage.show();
	}

	/**********
	 * <p>
	 * Method: ViewStaffHome()
	 * </p>
	 * 
	 * <p>
	 * Description: This method initializes all the elements of the graphical user
	 * interface. This method determines the location, size, font, color, and change
	 * and event handlers for each GUI object.
	 * </p>
	 * 
	 * This is a singleton and is only performed once. Subsequent uses fill in the
	 * changeable fields using the displayStaffHome method.
	 * </p>
	 * 
	 */
	private ViewStaffHome() {

		// Create the Pane for the list of widgets and the Scene for the window
		theRootPane = new Pane();
		theViewStaffHomeScene = new Scene(theRootPane, width, height); // Create the scene

		// Add the 'guiNewAccount.css" style sheet to the scene (which is located in the
		// css folder).
		theViewStaffHomeScene.getStylesheets().add(getClass().getResource("/css/guiStaffHome.css").toExternalForm());

		// Set the title for the window
		// Populate the window with the title and other common widgets and set their
		// static state

		// GUI Area 1
		label_PageTitle.setText("Staff Home Page");
		setupLabelUI(label_PageTitle, width, Pos.CENTER, 0, 5);
		label_PageTitle.getStyleClass().add("title");

		label_UserDetails.setText("User: " + theUser.getUserName());
		setupLabelUI(label_UserDetails, width, Pos.BASELINE_LEFT, 20, 55);
		label_UserDetails.getStyleClass().add("user");

		setupButtonUI(button_UpdateThisUser, 200, Pos.CENTER, 580, 45);
		button_UpdateThisUser.setOnAction((event) -> {
			ViewUserUpdate.displayUserUpdate(theStage, theUser);
		});
		button_UpdateThisUser.getStyleClass().add("account-update-button");

		// GUI Area 2
		setupButtonUI(button_CreateThread, 200, Pos.CENTER, 580, 110);
		button_CreateThread.setOnAction((event) -> {
			createThreadStage.setTitle("Create Thread");

			threadTitle = new TextField();
			threadContent = new TextArea();
			threadContent.setPromptText("Thread content...");
			threadContent.setWrapText(true);
			threadContent.setPrefRowCount(10);

			Button createBtn = new Button("Create Thread");
			createBtn.setOnAction(e -> {
				String title = threadTitle.getText().trim();
				String content = threadContent.getText().trim();
				ControllerStaffHome.doCreateThread(title, content, theUser.getUserName());
			});

			Button cancelBtn = new Button("Cancel");
			cancelBtn.setOnAction(e -> createThreadStage.close());

			VBox layout = new VBox(10, new Label("Title:"), threadTitle, new Label("Content:"), threadContent, new Separator(), new HBox(10, createBtn, cancelBtn));
			layout.setPadding(new Insets(15));
			layout.setAlignment(Pos.CENTER_LEFT);

			Scene scene = new Scene(layout, 600, 350);
			createThreadStage.setScene(scene);
			createThreadStage.showAndWait();
		});
		button_CreateThread.getStyleClass().add("create-thread-button");

		setupButtonUI(button_ListThreads, 200, Pos.CENTER, 580, 160);
		button_ListThreads.setOnAction((event) -> {
			guiListThreads.ViewListThreads.displayListThreads(theStage, theUser);
		});
		button_ListThreads.getStyleClass().add("list-threads-button");
		
		// GUI Area 2
		setupButtonUI(button_CriteriaManagement, 200, Pos.CENTER, 580, 210);
		button_CriteriaManagement.setOnAction((event) -> {
			guiCriteriaManagement.ViewCriteriaManagement.displayCriteriaManagement(theStage, theUser);
		});
		button_CriteriaManagement.getStyleClass().add("criteria-management-button");
		
		setupButtonUI(button_createRequest, 200, Pos.CENTER, 580, 310);
		button_createRequest.setOnAction((event) -> {
			createRequestStage.setTitle("Create Request");
			
			requestTitle = new TextField();
			requestDescription = new TextArea();
			requestDescription.setPromptText("Request description...");
			requestDescription.setWrapText(true);
			requestDescription.setPrefRowCount(10);
			
			Button createBtn = new Button("Create Request");
			createBtn.setOnAction(e -> {
				String title2 = requestTitle.getText().trim();
				String description2 = requestDescription.getText().trim();
				ControllerStaffHome.doCreateRequest(theUser.getUserName(), title2, description2);
			});
			
			Button cancelBtn = new Button("Cancel");
			cancelBtn.setOnAction(e -> {
				createRequestStage.close();
			});
			
			VBox layout = new VBox(10, new Label("Title:"), requestTitle, new Label("Description:"), requestDescription, new Separator(), new HBox(10, createBtn, cancelBtn));
			layout.setPadding(new Insets(15));
			layout.setAlignment(Pos.CENTER_LEFT);
			
			Scene scene = new Scene(layout,600, 350);
			createRequestStage.setScene(scene);
			createRequestStage.showAndWait();
		});
		button_createRequest.getStyleClass().add("create-request-button");
		
		setupButtonUI(button_pendingRequests, 200, Pos.CENTER, 580, 360);
		button_pendingRequests.setOnAction((event) -> {
			ViewPendingRequests.displayPendingRequests(theStage, theUser);
		});
		button_pendingRequests.getStyleClass().add("pending-requests-button");
		
		setupButtonUI(button_inactiveRequests, 200, Pos.CENTER, 580, 410);
		button_inactiveRequests.setOnAction((event) -> {
			ViewInactiveRequests.displayActiveRequests(theStage, theUser);
		});
		button_inactiveRequests.getStyleClass().add("inactive-requests-button");

		// GUI Area 3
		setupButtonUI(button_Logout, 250, Pos.CENTER, 20, 540);
		button_Logout.setOnAction((event) -> {
			ControllerStaffHome.performLogout();
		});
		button_Logout.getStyleClass().add("bottom-button");

		setupButtonUI(button_Quit, 250, Pos.CENTER, 300, 540);
		button_Quit.setOnAction((event) -> {
			ControllerStaffHome.performQuit();
		});
		button_Quit.getStyleClass().add("bottom-button");

		line_Separator1.getStyleClass().add("line");
		line_Separator2.getStyleClass().add("line");

		// Place all of the widget items into the Root Pane's list of children
		theRootPane.getChildren().addAll(label_PageTitle, label_UserDetails, button_UpdateThisUser, line_Separator1,
				button_CreateThread, button_CriteriaManagement, button_ListThreads, line_Separator2, button_Logout, 
				button_Quit, button_createRequest, button_pendingRequests, button_inactiveRequests);
	}

	/**********
	 * Private local method to initialize the standard fields for a label
	 * 
	 * @param l The Label object to be initialized
	 * @param w The width of the Button
	 * @param p The alignment (e.g. left, centered, or right)
	 * @param x The location from the left edge (x axis)
	 * @param y The location from the top (y axis)
	 */
	private static void setupLabelUI(Label l, double w, Pos p, double x, double y) {
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	/**********
	 * Private local method to initialize the standard fields for a button
	 * 
	 * @param b The Button object to be initialized
	 * @param w The width of the Button
	 * @param p The alignment (e.g. left, centered, or right)
	 * @param x The location from the left edge (x axis)
	 * @param y The location from the top (y axis)
	 */
	private static void setupButtonUI(Button b, double w, Pos p, double x, double y) {
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}
}
