package guiStaffHome;

import java.util.UUID;

public class ControllerStaffHome {

	/*********************************************************************************************

	User Interface Actions for this page
	
	This controller is not a class that gets instantiated.  Rather, it is a collection of protected
	static methods that can be called by the View (which is a singleton instantiated object) and 
	the Model is often just a stub, or will be a singleton instantiated object.
	
	*/
	
	/**********
	 * <p> Method: threadInputValidation(String title, String content, String username) </p>
	 * 
	 * <p> Description: This is the input validation part for the doCreateThread() method. It
	 * returns a string based on if the title or body is empty, or if the title or body exceed
	 * the character limits. If the thread creation is not invalid, it returns null.
	 * </p>
	 * 
	 * @param title is the title of the thread
	 * 
	 * @param content is the contents/description of the thread
	 * 
	 * @param username is the username of the staff user creating a thread
	 * 
	 * @return a string object representing the error (or lack of) after validating thread creation.
	 */
	public static String threadInputValidation(String title, String content, String username) {
		if (title.isEmpty()) {
        	return "Thread title cannot be empty.";
        } else if (content.isEmpty()) {
        	return "Thread body cannot be empty.";
        } else if (title.length() > 200) {
        	return "Thread title cannot exceed 200 characters.";
        } else if (content.length() > 10000) {
        	return "Thread body cannot exceed 10,000 characters.";
        } else {
        	return null;
        }
	}
	
	/**
	 * 
	 * <p> Method: requestInputValidation(String title, String description) </p>
	 * 
	 * <p> Description: This is the input validation part for the doCreateRequest method. It
	 * returns a string based on if the title or description is empty, or if the title or description
	 * exceed the character limits. If the request passes all input validation checks, the method returns null.</p>
	 * 
	 * @param title The title of the request.
	 * 
	 * @param description The description of the request.
	 * 
	 * @return a string object representing the error (or lack of) after validating request creation.
	 */
	public static String requestInputValidation(String title, String description) {
		if (title.isEmpty()) {
			return "Request title cannot be empty.";
		} else if (description.isEmpty()) {
			return "Request description cannot be empty.";
		} else if (title.length() > 200) {
			return "Request title cannot exceed 200 characters.";
		} else if (description.length() > 1000) {
			return "Request description cannot exceed 1000 characters.";
		} else {
			return null;
		}
	}
	
	/**********
	 * <p> Method: doCreateThread(String title, String content, String username) </p>
	 * 
	 * <p> Description: This method processes the title and content inputs and 
	 * calls the createThreadDB method in the model class to update the database 
	 * with the new thread.
	 * </p>
	 * 
	 * @param title is the title of the thread
	 * 
	 * @param content is the contents/description of the thread
	 * 
	 * @param username is the username of the staff user creating a thread
	 * 
	 */
	protected static void doCreateThread(String title, String content, String username) {
		String error = threadInputValidation(title, content, username);
		
		// If there was no error in the input received, continue with thread creation.
		if (error == null) {
        	ModelStaffHome.createThreadDB(title, content, username);
        	ViewStaffHome.threadTitle.clear();
        	ViewStaffHome.threadContent.clear();
        	ViewStaffHome.alertCreateThreadSuccess.setContentText("Thread created.");
        	ViewStaffHome.alertCreateThreadSuccess.showAndWait();
        	ViewStaffHome.createThreadStage.close();
		} else {
        	ViewStaffHome.threadTitle.clear();
        	ViewStaffHome.threadContent.clear();
        	ViewStaffHome.alertCreateThreadError.setContentText(error);
        	ViewStaffHome.alertCreateThreadError.showAndWait();
		}
	}
	
	/**
	 * <p> Method: doCreateRequest(String author, String title, String description) </p>
	 * 
	 * <p> Description: This method processes the title and description inputs and directly
	 * interacts with the database through the ModelStaffHome class, calling the createRequestDB
	 * method to update the database with the new request. </p>
	 * 
	 * @param author 	  the user who creates the request.
	 * @param title 	  the title of the request.
	 * @param description the description of the request.
	 */
	protected static void doCreateRequest(String author, String title, String description) {
		String error = requestInputValidation(title, description);
		
		// If the input passes input validation checks, continue with request creation.
		if (error == null) {
			UUID id = UUID.randomUUID();
			
			ModelStaffHome.createRequestDB(author, title, description, id.toString());
			ViewStaffHome.requestTitle.clear();
			ViewStaffHome.requestDescription.clear();
	    	ViewStaffHome.alertCreateRequestSuccess.setContentText("Request created.");
	    	ViewStaffHome.alertCreateRequestSuccess.showAndWait();
	    	ViewStaffHome.createRequestStage.close();
	    // Otherwise, present an error.
		} else {
        	ViewStaffHome.requestTitle.clear();
        	ViewStaffHome.requestDescription.clear();
        	ViewStaffHome.alertCreateRequestError.setContentText(error);
        	ViewStaffHome.alertCreateRequestError.showAndWait();
		}
	}

 	/**********
	 * <p> Method: performLogout() </p>
	 * 
	 * <p> Description: This method logs out the current user and proceeds to the normal login
	 * page where existing users can log in or potential new users with a invitation code can
	 * start the process of setting up an account. </p>
	 * 
	 */
	protected static void performLogout() {
		guiUserLogin.ViewUserLogin.displayUserLogin(ViewStaffHome.theStage);
	}
	
	/**********
	 * <p> Method: performQuit() </p>
	 * 
	 * <p> Description: This method terminates the execution of the program.  It leaves the
	 * database in a state where the normal login page will be displayed when the application is
	 * restarted.</p>
	 * 
	 */	
	protected static void performQuit() {
		System.exit(0);
	}
}
