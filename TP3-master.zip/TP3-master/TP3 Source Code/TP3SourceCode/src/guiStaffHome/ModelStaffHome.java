package guiStaffHome;

import java.sql.SQLException;

import database.Database;

/*******
 * <p>
 * Title: ModelStaffHome Class.
 * </p>
 * 
 * <p>
 * Description: The Staff Home Page Model. This class is not used as there is no
 * data manipulated by this MVC beyond accepting role information and saving it
 * in the database.
 * </p>
 * 
 * <p>
 * Copyright: Lynn Robert Carter © 2025
 * </p>
 * 
 * @author Lynn Robert Carter
 * 
 * @version 1.00 2025-08-15 Initial version
 * 
 */
public class ModelStaffHome {
	// Reference for the in-memory database so this package has access
	private static Database theDatabase = applicationMain.DiscussionsMain.database;

	/**********
	 * <p>
	 * Method: createThreadDB(String title, String content, String username)
	 * </p>
	 * 
	 * <p>
	 * Description: This method calls the database's createThread method and creates
	 * a new thread in the database.
	 * </p>
	 * 
	 * @param title    is the title of the thread
	 * 
	 * @param content  is the contents/description of the thread
	 * 
	 * @param username is the username of the staff user creating a thread
	 * 
	 */
	protected static void createThreadDB(String title, String content, String username) {
		try {
			theDatabase.createThread(username, title, content);
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
	}
	
	/**********
	 * <p>
	 * Method: createRequestDB(String author, String title, String description, String uuid)
	 * </p>
	 * 
	 * <p>
	 * Description: This method calls the database's createRequest method and creates a new
	 * request in the database.
	 * 
	 * @param author 	  the user that created the request
	 * @param title 	  the title of the request
	 * @param description the description of the request
	 * @param uuid 		  the unique identifier of the request
	 */
	protected static void createRequestDB(String author, String title, String description, String uuid) {
		try {
			theDatabase.createRequest(author, title, description, uuid);
		} catch (SQLException exc) {
			exc.printStackTrace();
		}
	}
}
